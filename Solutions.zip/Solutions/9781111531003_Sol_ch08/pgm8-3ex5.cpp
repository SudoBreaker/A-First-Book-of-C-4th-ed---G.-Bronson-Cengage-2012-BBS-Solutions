// File: pgm8-3ex5.cpp
// Description: 8.3 Exercise 5
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;


int main()
{
	char message[] = "This is a test.";
	char mess2[15];
	int i;
	char* mPt = message;
	char* m2Pt = mess2;

	for (i = 0; i < 15; i++)
	{
		*m2Pt = *mPt++;
		m2Pt++;
	}
	 
	cout << "The mess2 array contains the following values: " << endl;

	for (int i = 0; i < 15; i++)
		cout << mess2[i];
	cout << endl;

    cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
}    

