// File: pgm8-3ex1.cpp
// Description: 8.3 Exercise 1
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;


int main()
{
 
	const int NUMPTS = 5;
	int nums[NUMPTS] = {16, 54, 7, 43, -5};
	int total = 0, *nPt;

	for(nPt = nums; nPt < nums + NUMPTS; nPt++)
		total += *nPt;
	cout << "The total of the array elements is " << total << endl;

	
    cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
}    

