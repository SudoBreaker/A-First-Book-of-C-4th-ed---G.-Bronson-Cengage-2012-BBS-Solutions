// File: pgm8-4ex8.cpp
// Description: 8.4 Exercise 8
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

const int NUMELS = 10; 

int main()
 {
   void extend(double *, double *, double *);  // function prototype

   double price[NUMELS] =  {10.62, 14.89, 13.21, 16.55, 18.62, 9.47,
                             6.58, 18.32, 12.15, 3.98};
   double quantity[NUMELS] = {4, 8.5, 6, 7.35, 9, 15.3, 3, 5.4, 
                              2.9, 4.8};
   double amount[NUMELS];
   int i = 0;
   
   extend(price, quantity, amount);

   cout << "The elements of the amount array are:\n";
   for (i = 0;  i < NUMELS; ++i)
     cout << setiosflags(ios::fixed) 
		  << setiosflags(ios::showpoint) 
		  << setw(6) << setprecision(2) 
		  << *(amount + i) << endl;
 
   cin.ignore();   // needed for MS C++ Express 2010 programs
 
   return 0;
}
 
void extend(double *prc, double *qnty, double *amt) 
{
  int i = 0;

  while(i < NUMELS)
  {
    *amt++ = (*prc++) * (*qnty++);
     ++i;
  }

  return;
}   
