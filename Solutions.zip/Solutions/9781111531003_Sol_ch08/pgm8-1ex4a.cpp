// File: pgm8-1ex4a.cpp
// Description: 8.1 Exercise 4a
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
	int num, count;
	long date;
	float slope;
	double yield;

	cout << "The address of the variable num is "
		 << &num << endl;
	cout << "The address of the variable count is "
		 << &count << endl;
	cout << "The address of the variable date is "
		 << &date << endl;
	cout << "The address of the variable slope is "
		 << &slope << endl;
	cout << "The address of the variable yield is "
		 << &yield << endl;
	
    cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
}    

