// File: pgm8-4ex11.cpp
// Description: 8.4 Exercise 11
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

void capit(char *, char *);     // function prototype

int main()
{
  char let1, let2;

  cout << "Enter a character: ";
  cin >> let1;
  cout << "Enter a second character: ";
  cin >> let2;

  capit(&let1, &let2);
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
 
  return 0;
}

void capit(char *c1, char *c2)   // copy string2 to string1  
{
  char orig1, orig2;

  orig1 = *c1;
  orig2 = *c2;

  if( (*c1 >= 'a') && (*c1 <= 'z') )
		*c1 = (*c1 - 'a' + 'A');

  if( (*c2 >= 'a') && (*c2 <= 'z') )
		*c2 = (*c2 - 'a' + 'A');

  cout << "The four letters are: ";
  cout << orig1 << "  " << orig2 << "  " << c1 << "  " << c2 << endl;
	
  return;
}
