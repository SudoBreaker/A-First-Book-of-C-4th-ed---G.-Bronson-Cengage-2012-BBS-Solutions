// File: pgm8-4ex10.cpp
// Description: 8.4 Exercise 10
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

void trimrear(char *);   // function prototype

int main()
{
	char message[] = "This is the string       ";
	

	cout << "The initial string is |" << message << '|' << endl;

	trimrear(message);

	cout << "The front trimmed string is |" << message << '|' << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
}    

void trimrear(char *strng)
{
  char * strng2;
	  
  strng2 = strng;   // store the starting address
    
	
  while(*strng != '\0') ++strng;  // move to the end of the string  
	
  --strng;                         // move to char before '\0'
	
  while(*strng == ' ') --strng;    // move over any tailing blanks
      
  *(++strng) = '\0';               // terminate the string
  strng = strng2;                  // reset the starting address

  return;
}
