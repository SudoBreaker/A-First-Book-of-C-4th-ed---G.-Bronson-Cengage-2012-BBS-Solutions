// File: pgm8-4ex9.cpp
// Description: 8.4 Exercise 9
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs
 
#include <iostream>
using namespace std;

void trimfrnt(char *);   // function prototype

int main()
{
	char message[] = "     This is the string";
	

	cout << "The initial string is |" << message << '|' << endl;

	trimfrnt(message);

	cout << "The front trimmed string is |" << message << '|' << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
}    

void trimfrnt(char *strng)
{
  char * strng2;
	
  strng2 = strng;   // store the starting address
    
  while(*strng2 == ' ') ++strng2; // move over any leading blanks
  while(*strng++ = *strng2++) ;   // copy remaining chars up to and
		                      // including the '\0'
	
  return;
}
