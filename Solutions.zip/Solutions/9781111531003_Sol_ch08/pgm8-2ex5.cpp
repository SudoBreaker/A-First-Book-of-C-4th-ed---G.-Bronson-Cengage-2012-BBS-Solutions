// File: pgm8-2ex5.cpp
// Description: 8.2 Exercise 5
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  
	double rates[] = {12.9, 18.6, 11.4, 13.7, 9.5, 15.2,  17.6};
	int i;

	cout << "The elements in the array are:\n";
	for(i = 0; i <= 6; ++i)
		cout << *(rates + i) << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
}    

