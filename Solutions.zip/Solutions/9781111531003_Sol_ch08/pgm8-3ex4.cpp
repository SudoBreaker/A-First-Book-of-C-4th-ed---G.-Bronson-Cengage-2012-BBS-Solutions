// File: pgm8-3ex4.cpp
// Description: 8.3 Exercise 4
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;


int main()
{
	int miles[] = {15,22,16,18,27,23,20};
	int dist[7];
	int i;
	int* mPt = miles;
	int* dPt = dist;

	for (i = 0; i < 7; i++)
	{
		*dPt = *mPt++;
		dPt++;
	}
	 
	cout << "The dist array contains the following values: " << endl;

	for (int i = 0; i < 7; i++)
		cout << dist[i] << "  ";
	cout << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
}    

