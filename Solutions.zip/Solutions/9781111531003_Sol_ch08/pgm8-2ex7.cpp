// File: pgm8-2ex7.cpp
// Description: 8.2 Exercise 7
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const int MAXNUMS = 8;
  int i, grade[MAXNUMS], total = 0;
  double avg;

  for (i = 0; i < MAXNUMS; i++)     // Enter the numbers
  {
    cout << "Enter a grade: ";
    cin  >> *(grade + i);
  }

  cout << "\nThe average of the grades ";

  for (i = 0; i < MAXNUMS; i++)     // Display and total the numbers
  {
     cout << "  " << *(grade + i);
     total =  total + *(grade + i);
  }

  avg = total / MAXNUMS;

  cout << " is " << avg << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
 
  return 0;
}

