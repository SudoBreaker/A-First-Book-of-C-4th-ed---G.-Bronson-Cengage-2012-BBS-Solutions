// File: pgm8-2ex6b.cpp
// Description: 8.2 Exercise 6b
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  const int MAXPRICES = 9;
  double prices[MAXPRICES];
  int i;

  prices[0] = 10.95;
  prices[1] = 16.32;
  prices[2] = 12.15;
  prices[3] = 8.22;
  prices[4] = 15.98;
  prices[5] = 26.22;
  prices[6] = 13.54;
  prices[7] = 6.45;
  prices[8] = 17.59;

  for (i = 0; i < MAXPRICES; i+=3)    // Display the prices in 3 columns
    cout << setiosflags(ios::showpoint) << setiosflags (ios::fixed)
         << setprecision(2) <<setw(5) << *(prices + i) << "     " 
	     << setw(5) << *(prices + i + 1) << "     " 
	     << setw(5) << *(prices + i + 2) << endl;

  cin.ignore();  // needed for MS C++ Express 2010 programs
 
  return 0;
}
