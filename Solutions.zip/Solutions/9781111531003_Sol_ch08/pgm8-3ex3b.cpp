// File: pgm8-3ex3b.cpp
// Description: 8.3 Exercise 3b
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;


int main()
{
	char strng[] = "Hooray for All of Us";
	char *messPt;

	messPt = strng;
	cout << "\nThe elements in the array are: ";
	cout << *messPt;          // another way to do this would be to
                              // remove this statement, and use the
	while(*messPt++ != '\0')  // while statement while(*messPt != '\0'),
		cout << *messPt;      // and then update this statement to 
                              // cout << *messPt++;
	cout << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
}    

