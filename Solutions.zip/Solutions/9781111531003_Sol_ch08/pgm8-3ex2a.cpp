// File: pgm8-3ex2a.cpp
// Description: 8.3 Exercise 2a
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;


int main()
{
  
	double rates[13] = {6.25, 6.50, 6.8, 7.2, 7.35, 7.5,
				   7.65, 7.8, 8.2, 8.4, 8.6, 8.8, 9.0};
	double *dispPt;
	int count;

	dispPt = rates; // move the address into the pointer 
                    // dispPt = &rates[0]; is also correct 
	
	cout << "The elements in the array are:\n";
	for( count = 0; count < 13; ++count)
		cout << *dispPt++ << "  ";

	cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
}    

