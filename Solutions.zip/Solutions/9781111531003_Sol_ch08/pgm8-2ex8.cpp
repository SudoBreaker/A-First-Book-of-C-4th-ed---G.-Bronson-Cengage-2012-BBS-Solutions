// File: pgm8-2ex8.cpp
// Description: 8.2 Exercise 8
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
   int numgrades, i;

   cout << "Enter the number of grades to be processed: ";
   cin >> numgrades;

   int *grade = new int[numgrades]; // create the array

   if(grade == NULL)   // checks to see if NULL is returned
   {
	   cout << "Sufficient storage is not avialable!" << endl;
	   exit(0);
   }

   for(i = 0; i < numgrades; i++)
   {
	   cout << " Enter a grade: ";
	   cin >> grade[i];
   }

   cout << "\nAn array was created for " << numgrades << " integers\n";

   cout << " The values stored in the array are:";
   for (i = 0; i < numgrades; i++)
	   cout << "\n " << grade[i];

   delete []grade;  // return the storage to the heap
   cout << endl;
  
   cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
 
   return 0;
}

