// File: pgm8-3ex3a.cpp
// Description: 8.3 Exercise 3a
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;


int main()
{
	char strng[] = "Hooray for All of Us";
	char *messPt;

	cout << "\nThe elements in the array are: ";
	for(messPt = strng; *messPt; messPt++)
		cout << *messPt;
	cout << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
}    

