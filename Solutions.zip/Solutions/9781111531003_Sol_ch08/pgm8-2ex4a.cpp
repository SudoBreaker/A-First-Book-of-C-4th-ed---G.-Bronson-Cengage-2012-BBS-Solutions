// File: pgm8-2ex4a.cpp
// Description: 8.2 Exercise 4a
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  
	char samtest[] = "This is a sample";
	int i;

	cout << "The elements in the array are:\n";
	for(i = 0; i <= 15; ++i)
		cout << *(samtest + i) << endl;

    cin.ignore();  // needed for MS C++ Express 2010 programs
 
    return 0;
}    

