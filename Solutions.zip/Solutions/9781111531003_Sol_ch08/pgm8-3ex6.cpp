// File: pgm8-3ex6.cpp
// Description: 8.3 Exercise 6
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{

  const int NUMELS = 10;
  
  double miles[NUMELS] = {240.5, 300.0, 189.6, 310.6, 280.7, 216.9, 
                          199.4, 160.3, 177.4, 192.3};
  double gallons[NUMELS] = {10.3, 15.6, 8.7, 14, 16.3, 15.7, 14.9, 
                            10.7, 8.3, 8.4};
  double mpg[NUMELS];
  int i;

  cout << "The elements in the mpg array are:\n";
  for (i = 0; i < NUMELS; ++i)
  {
    *(mpg+i) = *(miles + i) / *(gallons + i);
    cout << setiosflags(ios::fixed)
		 << setiosflags(ios::showpoint)
		 << setw(5) << setprecision(2)
		 << *(mpg + i) << endl;
  }
  
  cin.ignore();   // needed for MS C++ Express 2010 programs
 
  return 0;
}
