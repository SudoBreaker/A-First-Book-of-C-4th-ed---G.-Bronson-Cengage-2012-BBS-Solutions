// File: pgm8-4ex7b.cpp
// Description: 8.4 Exercise 7b
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

const int ARRAYSIZE = 16;

int main()
{
  void display(char *);

  char *message = "Vacation is near";   

  display(message);

  cin.ignore();   // needed for MS C++ Express 2010 programs
 
  return 0;
}

void display(char *strng)
{
	int i;

	for (i = 0; i < ARRAYSIZE; i++, strng++)
		cout << *strng;

      return;
}
