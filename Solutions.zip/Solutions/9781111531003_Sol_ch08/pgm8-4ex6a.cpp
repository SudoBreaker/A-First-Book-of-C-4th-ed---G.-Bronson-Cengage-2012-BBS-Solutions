// File: pgm8-4ex6b.cpp
// Description: 8.4 Exercise 6b
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

const int ARRAY_SIZE = 9;

int main ()
{
	void show(double *);
	double rates[ARRAY_SIZE] = {6.5,7.2,7.5,8.3,8.6,9.4,9.6,9.8,10.0};

	show(rates);

	cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
} 

void show (double *rates)
{
	int i;

	for (i = 0; i < ARRAY_SIZE; i++)
	  cout << *(rates + i) << endl;

	return;
}

