// File: pgm8-1ex4b.cpp
// Description: 8.1 Exercise 4b
// Programmer: G. Bronson
// Date: 9/2/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
	int num, count;
	long date;
	float slope;
	double yield;

	cout << "Storage amounts: " << endl;
	cout << "int - " << sizeof(int) << endl;
	cout << "long - " << sizeof(long) << endl;
	cout << "float - " << sizeof(float) << endl;
	cout << "double - " << sizeof(double) << endl;
	cout << endl;

	cout << "The address of the variable num is "
		 << &num << endl;
	cout << "The address of the variable count is "
		 << &count << endl;
	cout << "The address of the variable date is "
		 << &date << endl;
	cout << "The address of the variable slope is "
		 << &slope << endl;
	cout << "The address of the variable yield is "
		 << &yield << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs
 
    return 0;
}    

