// File: pgm4-4ex3.cpp
// Description: 4.3 Exercise 3
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int code;

  cout << "Enter the disk drive code: ";
  cin  >> code;

  switch (code)
  {
    case 1:
	    cout << "The disk drive has a capacity of 2GB\n";
	    break;
    case 2:
            cout << "The disk drive has a capacity of 4GB\n";
            break;
    case 3:
            cout << "The disk drive has a capacity of 16GB\n";
            break;
    case 4:
            cout << "The disk drive has a capacity of 32GB\n";
            break;
  }

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
