// File: pgm4-4ex6.cpp
// Description: 4.4 Exercise 6
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	char opselect;
  	double fnum, snum;
  	cout << "Please type in two numbers: ";
  	cin >> fnum >> snum;
  	cout << "Enter a select code: ";
  	cout << "\n        A   for addition";
 	cout << "\n        M   for multiplication";
  	cout << "\n        D   for division : ";
  	cin >> opselect;

	switch (opselect)
 	{
		case 'a': case 'A':
			cout << "The sum of the numbers entered is " 
				<< fnum + snum << endl;
			break;
		case 'm': case 'M':
			cout << "The product of the numbers entered is " 
				<< fnum * snum << endl;
			break;
		case 'd':  case 'D':
			cout << "The first number divided by the second is " 
				<< fnum / snum << endl;
			break;
		default:
			cout << "Invalid entry." << endl;
			break;
 	}   

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
