// File: pgm4-3ex7c.cpp
// Description: 4.3 Exercise 7c
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int opselect;
  double fnum, snum;

  cout << "Please type in two numbers: ";
  cin >> fnum >> snum;
  cout << "Enter a select code: \n";
  cout << "   1 for addition " << endl;
  cout << "   2 for multiplication" << endl;
  cout << "   3 for division: ";
  cin >> opselect;

  switch(opselect)
  {
  case 1:
	  cout << "The sum of the numbers entered is " 
             << fnum + snum << endl;
	  break;
  case 2:
	  cout << "The product of the numbers is "
             << fnum * snum << endl;
	  break;
  case 3:
	  if(snum == 0)
		  cout << "Division by zero is not permitted!\n";
	  else
		  cout << "The first number divided by the second is " 
                   << fnum / snum << endl;
	  break;
  }
   
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}            


