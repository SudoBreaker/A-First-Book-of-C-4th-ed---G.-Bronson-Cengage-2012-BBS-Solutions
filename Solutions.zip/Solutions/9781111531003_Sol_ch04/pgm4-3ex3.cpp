// File: pgm4-3ex3.cpp
// Description: 4.3 Exercise 3
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  double grade;

  cout << "Enter the grade: ";
  cin  >> grade;

  if (grade >= 90)
    cout << "Your grade is an A";
  else if (grade < 90 && grade >= 80)
    cout << "Your grade is a B";
  else if (grade < 80 && grade >= 70)
    cout << "Your grade is a C";
  else if (grade < 70 && grade >= 60)
    cout << "Your grade is a D";
  else if (grade < 60)
	cout << "Your grade is an F";
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
