// File: pgm4-2ex4.cpp
// Description: 4.2 Exercise 4
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs
   
#include <iostream> 	 
using namespace std;

int main()
{
	double grade;

	cout << "Enter a grade:  ";
	cin >> grade;

	if (grade >= 70.0)
		cout << "\n A passing grade\n";
	else
		cout << "\nA failing grade\n";

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
