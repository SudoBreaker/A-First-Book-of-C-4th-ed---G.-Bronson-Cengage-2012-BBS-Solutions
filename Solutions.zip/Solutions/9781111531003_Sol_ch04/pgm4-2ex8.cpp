// File: pgm4-2ex8.cpp
// Description: 4.2 Exercise 8
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	double num;

	cout << "Enter a number\n";
	cin >> num;	
	if (num < 0) 
		cout << "The square root of "
                 << num << " cannot be displayed\n";
	else 
                cout << "The square root of " 
                     << num << " is " << sqrt(num) << "\n";
	if (num == 0) 
		cout << "The reciprocal of " 
                << num << " cannot be displayed\n";
	else 
		cout << "The reciprocal of " 
                << num << " is " << 1.0/num << "\n";

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
