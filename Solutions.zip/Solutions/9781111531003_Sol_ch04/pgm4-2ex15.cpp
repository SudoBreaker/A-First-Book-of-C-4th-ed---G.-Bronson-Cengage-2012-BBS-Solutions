// File: pgm4-2ex15.cpp
// Description: 4.2 Exercise 15
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs
    
#include <iostream> 	 
using namespace std;

int main()
{
	char ch;
	int position;

	cout << "\nEnter a letter:  ";
	cin >> ch;

	if (ch >= 'a' && ch <= 'z')
	{
           cout << "The entered character is a lowercase letter.\n";
		position = ch - 'a' + 1;
		cout << "The character's position is  " 
                << position<< endl;
	}
	else if (ch >= 'A' && ch <= 'Z')
	{
           cout << "The entered character is an uppercse letter.\n";
		position = ch - 'A' + 1;
		cout << "The character's position is  " 
                << position << endl;
      }
      else
            cout << "The entered character is not a letter.\n";

		
	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}

