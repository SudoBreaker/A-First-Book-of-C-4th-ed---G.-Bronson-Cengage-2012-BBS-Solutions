// File: pgm4-4ex5.cpp
// Description: 4.4 Exercise 5
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	double fahr, celsius, temp;

	char letter;
	cout << "\nEnter a temperature followed by a space\n" 
			<< "and an 'f' for Fahrenheit or a 'c' for Celsius.\n";
	cin >> temp >> letter;

	switch (letter)
	{
		case  'f': case 'F': // just in case a capital f was entered
			celsius = (5.0/9.0)* (temp - 32.0);
			cout << temp << " degrees Fahrenheit = "
				<< celsius << " degrees Celsius\n";
			break;
		case 'c': case 'C': // just in case a capital C was entered
			fahr = (9.0/5.0)* (temp + 32.0);
			cout << temp << " degrees Celsius = "
				<< fahr << " degrees Fahrenheit\n";
			break;
		default:
			cout << "\nThe data entered is invalid.\n";
			break;
	} 

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
