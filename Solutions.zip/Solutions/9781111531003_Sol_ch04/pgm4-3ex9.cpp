// File: pgm4-3ex9.cpp
// Description: 4.3 Exercise 9
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  double temp;
  char letter;

  cout << "Enter the temperature followed by a letter indicating c for Celsius or f for Fahrenheit: ";
  cin  >> temp >> letter;

  if (letter == 'f' || letter == 'F')
  {
	  temp = (5.0 / 9.0) * (temp - 32.0);
	  cout << "The temperature is " << temp << " c" << endl;
  }
  else if (letter == 'c' || letter == 'C')
  {
    temp = (9.0 / 5.0) * temp + 32.0;
    cout << "The temperature is " << temp << " f" << endl;
  }
  else 
    cout << "Incorrect data has been entered";
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;	
}
