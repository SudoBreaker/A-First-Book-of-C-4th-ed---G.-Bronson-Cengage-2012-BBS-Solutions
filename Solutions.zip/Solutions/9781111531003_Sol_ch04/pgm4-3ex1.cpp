// File: pgm4-3ex1.cpp
// Description: 4.3 Exercise 1
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  double angle;

  cout << "Enter an angle: ";
  cin  >> angle;

  if (angle < 90)
    cout << "The angle is acute";
  else if (angle > 90)
    cout << "The angle is obtuse";
  else if (angle == 90)
    cout << "The angle is a right angle";
   
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
