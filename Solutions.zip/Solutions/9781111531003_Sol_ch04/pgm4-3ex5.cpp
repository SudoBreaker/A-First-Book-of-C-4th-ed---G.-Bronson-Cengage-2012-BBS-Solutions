// File: pgm4-3ex5.cpp
// Description: 4.3 Exercise 5
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
	int num;

	cout << "Enter a Reynolds number: ";
	cin >> num;	
	
	if (num < 2000)
		cout << "This correspnds to  a laminar (smooth) flow\n";
	else if (num <= 3000)
		cout << "This corresponds to transitional flow\n";
	else
		cout << "This corresponds to turbulent flow\n";
	
	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
