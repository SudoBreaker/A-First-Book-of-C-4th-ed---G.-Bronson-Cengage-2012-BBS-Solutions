// File: pgm4-3ex2.cpp
// Description: 4.3 Exercise 2
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  double credits;

  cout << "Enter the number of credits: ";
  cin  >> credits;

  if (credits < 32)
    cout << "The student's grade level is Freshman";
  else if (credits >= 32 && credits <= 63)
    cout << "The student's grade level is Sophomore";
  else if (credits >= 64 && credits <=95)
    cout << "The student's grade level is Junior";
  else if (credits >= 96)
    cout << "The student's grade level is Senior";
   
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
