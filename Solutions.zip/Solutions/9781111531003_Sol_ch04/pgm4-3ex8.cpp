// File: pgm4-3ex8.cpp
// Description: 4.3 Exercise 8
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int angle;
  
  cout << "Please enter an angle: ";
  cin >> angle;

  if(angle > 0 && angle < 90)
  {
	  cout << "The angle is in quadrant I" << endl;
  }
  else if(angle > 90 && angle < 180)
  {
	  cout << "The angle is in quadrant II" << endl;
  }
  else if(angle > 180 && angle < 270)
  {
	  cout << "The angle is in quadrant III" << endl;
  }
  else if(angle > 270 && angle < 360)
  {
	  cout << "The angle is in quadrant IV" << endl;
  }
  else if(angle == 0 || angle == 90 || angle == 180
		|| angle == 270)
  {
	  cout << "The angle is on an axis";
  }
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}            


