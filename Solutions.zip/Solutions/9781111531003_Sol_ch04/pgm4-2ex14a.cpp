// File: pgm4-2ex14a.cpp
// Description: 4.2 Exercise 14a
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs
     
#include <iostream> 	 
using namespace std;

int main()
{
	char ch;
	int position;

	cout << "\nEnter a lowercase letter:  ";
	cin >> ch;

	if (ch >= 'a' && ch <= 'z')
	  cout << "\nThe entered character is a lowercase letter.\n";
	else
	  cout << "\nThe entered character is not a lowercase letter.\n";


	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
