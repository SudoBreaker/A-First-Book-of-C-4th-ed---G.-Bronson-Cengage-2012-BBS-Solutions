// File: pgm4-2ex9.cpp
// Description: 4.2 Exercise 9
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int year;

  cout << "Please enter a year: ";
  cin >> year;


  if ( (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0) )
      cout << year << " is a leap year" << endl;  // is a leap year
  else
      cout << year << " is not a leap year" << endl;  // not a leap year


  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}            


