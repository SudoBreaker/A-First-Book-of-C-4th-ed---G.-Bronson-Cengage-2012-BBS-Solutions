// File: pgm4-2ex6a.cpp
// Description: 4.2 Exercise 6a
// Programmer: C. Carvalho
// Date: 1/15/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	char status;
	cout << "\nEnter your happiness status ( u for upbeat ): ";
	cin >> status;
	if (status == 'u')
		cout << "\nI feel great today!\n";
	else
		cout << "\nI feel down today #$*!\n";

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
  
    return 0;
}
