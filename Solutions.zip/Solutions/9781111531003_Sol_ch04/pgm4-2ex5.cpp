// File: pgm4-2ex5.cpp
// Description: 4.2 Exercise 5
// Programmer: G. Bronson
// Date: 8/24/210
     
#include "stdafx.h"  // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	double numYears = 0;

	cout << "\nEnter number of years:  ";
	cin >> numYears;

	if (numYears >=5)

		cout << "\nThe interest is paid at 4.5 percent." << endl;
	else 
		cout << "\nThe interest is paid at 3.0 percent." << endl;

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;

}
