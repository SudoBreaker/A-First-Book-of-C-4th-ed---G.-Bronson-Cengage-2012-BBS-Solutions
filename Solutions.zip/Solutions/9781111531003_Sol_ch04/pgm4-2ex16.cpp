// File: pgm4-2ex16.cpp
// Description: 4.2 Exercise 16
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int num1, num2;

  cout << "Please enter the first integer: ";
  cin  >> num1;
  cout << "Please enter the second integer: ";
  cin  >> num2;

  if (num1 > num2)
    cout << "The first number is greater";
  else
    cout << "The first number is smaller";
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
