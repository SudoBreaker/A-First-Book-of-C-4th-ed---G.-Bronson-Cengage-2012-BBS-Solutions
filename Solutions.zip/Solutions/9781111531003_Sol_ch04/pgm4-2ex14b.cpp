// File: pgm4-2ex14b.cpp
// Description: 4.2 Exercise 14b
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	char ch;
	
	cout << "\nEnter a letter:  ";
	cin >> ch;

	if (ch >= 'a' && ch <= 'z')
	
           cout << "The entered character is a lowercase letter.\n";
				
	else if (ch >= 'A' && ch <= 'Z')
           cout << "The entered character is an uppercase letter.\n";
      else
            cout << "The entered character is not a letter.\n";

		
	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}


void Date::addSixMonths(Date& temp) //method to add six months using a reference argument
{ 

  day = temp.day;
  month = temp.month;
  year = temp.year;

  month += 6;  // add 6 months to the date
 
  //adjust the date's month and year
  if(month > 12) // adjust the month and year
  {
    month -= 12;
    ++year;  //add 1 to the year
  }
  
  return;
}     

int main()
{
  Date oldDate(4,3,2011);
  Date newDate;
  
  cout << "\nThe date stored in oldDate is ";
  oldDate.showDate();
  cout << endl;

  
  newDate.addSixMonths(oldDate); // add six months
  cout << "\nThe date stored in newDate six months later is ";
  newDate.showDate();
  cout << endl;
  cout << "\nThe date stored in oldDate is ";
  oldDate.showDate();
  cout << endl;
cin.ignore();
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}// File: pgm16-1ex6b.cpp
// Description: 16.1 Exercise 6b
// Programmer: G. Bronson
// Date: 9/5/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs


#include <iostream>
#include <iomanip>
using namespace std;

class Time
{
  friend istream& operator>>(istream&, Time&);

  // data declaration section
  private:
    int hours;
    int minutes;
    int seconds;

   // method declarations
   public:
     Time(int = 7, int = 4, int = 30); // constructor with default arguments
     void showTime(); // accessor
};

// methods implementation section
Time::Time(int hh, int mm, int ss)
{
  hours = hh;
  minutes = mm;
  seconds = ss;
}

void Time::showTime()
{
  cout << setfill('0')
	  << setw(2) << hours << ':'
	  << setw(2) << minutes << ':'
       << setw(2) << seconds << endl;
}

// overloaded extraction operator function
istream& operator>>(istream& in, Time& sometime)
{
  in >> sometime.hours;  
  in.ignore(1);         
  in >> sometime.minutes;   
  in.ignore(1);          
  in >> sometime.seconds;    
  in.ignore(1);

  return in;
}

int main()
{
  Time someTime;

  cout << "Enter the current hours:minutes:seconds ";
  cin >> someTime;

  cout << "The Time entered is: ";
  someTime.showTime();

       
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}            
