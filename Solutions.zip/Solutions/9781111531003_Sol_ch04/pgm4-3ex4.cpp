// File: pgm4-3ex4.cpp
// Description: 4.3 Exercise 4
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	double rate;
	int years;
	cout << "Enter time on deposit: ";
	cin >> years;
	if (years >= 5) 
		rate = .04;
	else if (years >= 4 && years < 5)
		rate = .035;
	else if (years >= 3 && years < 4)
		rate = .03;
	else if (years >= 2 && years < 3)
		rate = .025;
	else if (years >= 1 && years < 2)
		rate = .02;
	else rate = .015;
	cout << "\nThe interest rate is  " << rate << '\n';

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
