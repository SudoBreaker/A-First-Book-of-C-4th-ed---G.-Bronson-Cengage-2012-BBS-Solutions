// File: pgm4-2ex10.cpp
// Description: 4.2 Exercise 10
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	double hours;

	cout << "Enter hours:  ";
	cin >> hours;

	if (hours <= 40)
		cout << "\nSalary is:  $" << hours * 12.00 << endl; 
	else 
		cout << "\nSalary is:  $" 
                 << 480.00 + ((hours - 40) * 18.00) << endl;

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
