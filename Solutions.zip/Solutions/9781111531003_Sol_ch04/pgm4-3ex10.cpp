// File: pgm4-3ex10.cpp
// Description: 4.3 Exercise 10
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int year;
  double weight;
  
  cout << "Please enter a year: ";
  cin >> year;
  cout << "Please enter a weight: ";
  cin >> weight;

  if(year <= 1990)
  {
	  if(weight < 2700)
		cout << "The weight class is 1 and the fee is $26.50\n";
	  else if(weight >= 2700 && weight <= 3800)
		cout << "The weight class is 2 and the fee is $35.50\n";                 
	  else
		cout << "The weight class is 3 and the fee is $56.50\n"; 
  }
  else if(year > 1991 && year <= 1999)
  {
	  if(weight < 2700)
		cout << "The weight class is 4 and the fee is $35.00\n";                 
	  else if(weight >= 2700 && weight <= 3800)
		cout << "The weight class is 5 and the fee is $42.50\n"; 
	  else 
		  cout << "The weight class is 6 and the fee is $62.50\n"; 
  }
  else 
  {
	  if(weight < 3500)
		cout << "The weight class is 7 and the fee is $49.50\n";                 
        else 
		cout << "The weight class is 8 and the fee is $62.50\n"; 
  }
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}            


