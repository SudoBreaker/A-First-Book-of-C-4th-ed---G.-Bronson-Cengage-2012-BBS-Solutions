// File: pgm4-2ex7.cpp
// Description: 4.2 Exercise7
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	int num;

	cout << "Enter a number: ";
	cin >> num;	
	
	if ((num % 2) == 1)    // can be replaced by if (num % 2) 
		cout << "The entered number ia an odd number\n";
	else 
		cout << "The entered number is an even number\n";

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}