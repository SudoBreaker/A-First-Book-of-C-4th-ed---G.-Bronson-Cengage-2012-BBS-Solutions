// File: pgm4-3ex6.cpp
// Description: 4.3 Exercise 6
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  double tolerance;

  cout << "Enter the tolerance reading: ";
  cin  >> tolerance;

  if (tolerance < 0.001)
    cout << "The specification is: Space Exploration";
  else if (tolerance >= 0.001 && tolerance < 0.01)
    cout << "The specification is: Military Grade";
  else if (tolerance >= 0.01 && tolerance < 0.1)
    cout << "The specification is: Commercial Grade";
  else if (tolerance >= 0.1)
    cout << "The specification is: Toy Grade";
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
