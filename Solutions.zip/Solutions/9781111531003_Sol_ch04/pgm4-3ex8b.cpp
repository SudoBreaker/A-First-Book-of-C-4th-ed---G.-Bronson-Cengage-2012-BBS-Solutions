// File: pgm4-3ex8b.cpp
// Description: 4.3 Exercise 8b
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int angle;
  
  cout << "Please enter an angle: ";
  cin >> angle;

  if (angle == 0)
	  cout << "This is the positive x axis\n";
  else if (angle < 90)
	  cout << "The angle is in quadrant I\n";
  else if(angle == 90)
	  cout << "This is the positive y axis\n";
  else if(angle < 180)
	  cout << "The angle is in quadrant II\n";
  else if (angle == 180)
	  cout << "This is the negative x axis\n";
  else if(angle < 270)
	  cout << "The angle is in quadrant III\n";
  else if(angle== 270)
	  cout << "The angle is on the negative y axis\n";
  else 
	  cout << "The angle is in quadrant IV\n";
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}  