// File: pgm4-4ex4.cpp
// Description: 4.4 Exercise 4
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	char marcode;
	cout << "\nEnter a marital code:  ";
	cin >> marcode;

	switch (marcode)
	{
	case 'M':
		cout << "Individual is married";
		break;
	case 'S':
		cout << "Individual is single";
		break;
	case 'D':
		cout << "Individual is divorced";
		break;
	case 'W':
		cout << "Individual is widowed";
		break;
	default:
		cout << "An invalid code was entered.\n";
	}

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
