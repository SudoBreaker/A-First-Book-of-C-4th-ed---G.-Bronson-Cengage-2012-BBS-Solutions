// File: pgm4-2ex11.cpp
// Description: 4.2 Exercise 11
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	char status;

	cout << "\nEnter the status: ";
	cin >> status;

	if (status == 's')
		cout << "\nThe senior person's salary is $800.00\n";
	else
		cout << "\nThe junior person's salary is $500.00\n";

    cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
