// File: pgm4-2ex6.cpp
// Description: 4.2 Exercise 6
// Programmer: G.Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs


#include <iostream>
using namespace std;

int main()
{
   char code;

   cout << "Enter a code: ";
   cin >> code;

   if(code == 'g')
	   cout << "PROCEED WITH TAKEOFF";
   else
	   cout << "ABORT TAKEOFF";
   
   cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
