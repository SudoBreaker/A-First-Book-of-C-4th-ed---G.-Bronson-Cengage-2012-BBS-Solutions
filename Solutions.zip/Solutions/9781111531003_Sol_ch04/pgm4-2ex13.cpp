// File: pgm4-2ex13.cpp
// Description: 4.2 Exercise 13
// Programmer: G. Bronson
// Date: 8/24/2020

#include "stdafx.h"   // needed for MS C++ Express 2010 programs
     
#include <iostream> 	 
using namespace std;

int main()
{
	int month, day;

	cout << "\nEnter a month (use a 1 for Jan, 2 for Feb, etc.):  ";
	cin >> month;
	cout << "\nEnter a day of the month:  ";
	cin >> day;

	if (month > 12 || month < 1)
		cout << "\nAn incorrect month was entered.\n";
	if (day < 1 || day > 31)
		cout << "\nAn incorrect day was entered.\n";

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
