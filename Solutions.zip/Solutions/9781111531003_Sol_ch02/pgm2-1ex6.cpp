// File: pgm2-1ex6.cpp
// Description: 2.1 Exercise 6
// Programmer: G. Bronson
// Date: 8/20/2010

#include "stdafx.h"     // needed for MS C++ Express users
#include "conio.h"      // needed for MS C++ Express users
using namespace System  // needed for MS C++ Express users#include <iostream>
using namespace std;
int main()
{
  cout << "\nData Type    Bytes";
  cout << "\n---------    -----";
  cout << "\nfloat          " << sizeof(float);
  cout << "\ndouble         " << sizeof(double);
  cout << "\nlong double    " << sizeof(long double);
  cout<< '\n';

  cin.ignore();  // needed for MS C++ Express users

  return 0;
}
