// File: pgm2-3ex10.cpp
// Description: 2.3 Exercise 10
// Programmer: G. Bronson
// Date: 8/20/2010

#include "stdafx.h"     // needed for MS C++ Express users
#include "conio.h"      // needed for MS C++ Express users
using namespace System  // needed for MS C++ Express users


#include <iostream>
using namespace std;

int main()
{
	int num1 = 16;
	int num2 = 18;
	int average, total;
	
	total = num1 + num2;
	average = total / 2.0;
	
	cout << "total = " << total << endl;
	cout << "average = " << average << endl;

	cin.ignore();  // needed for MS C++ Express users

	return 0;
}
