// File: pgm2-1ex3.cpp
// Description: 2.1 Exercise 3
// Programmer: G. Bronson
// Date: 8/20/2010

#include "stdafx.h"     // needed for MS C++ Express users
#include "conio.h"      // needed for MS C++ Express users
using namespace System  // needed for MS C++ Express users

#include <iostream>
using namespace std;

int main()
{  
	cout << "\nData Type       Bytes" << "\n---------       -----" 
             << "\nchar               " << sizeof(char)	   
             << "\nbool               " << sizeof(bool)
             << "\nshort int          " << sizeof(short int)	   
             << "\nunsigned short int " << sizeof(unsigned short int) 
             << "\nint                " << sizeof(int)
             << "\nunsigned int       " << sizeof(unsigned int)
             << "\nlong int           " << sizeof(long int)
             << "\nunsigned long int  " << sizeof(unsigned long int)
             << '\n';
  
	cin.ignore();  // needed for MS C++ Express users

	return 0;
}
