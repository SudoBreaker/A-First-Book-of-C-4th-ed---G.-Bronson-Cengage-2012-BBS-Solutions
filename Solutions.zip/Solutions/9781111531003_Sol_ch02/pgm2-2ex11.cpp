// File: pgm2-2ex11.cpp
// Description: 2.2 Exercise 11
// Programmer: G. Bronson
// Date: 8/20/2010

#include "stdafx.h"     // needed for MS C++ Express users
#include "conio.h"      // needed for MS C++ Express users
using namespace System  // needed for MS C++ Express users


#include <iostream>
using namespace std;

int main()
{  
	cout << "The result of 15 / 4 is " << (15 / 4);
	cout << "\nThe result of 15 % 4 is " << (15 % 4);
	cout << "\nThe result of 5 * 3 - (6 * 4) is " << (5 * 3 - (6 * 4)); 
 
	cin.ignore();  // needed for MS C++ Express users   
	return 0;
}
