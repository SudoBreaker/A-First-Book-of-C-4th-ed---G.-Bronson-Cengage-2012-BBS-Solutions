
// File: pgm2-3ex13.cpp
// Description: 2.3 Exercise 13
// Programmer: G. Bronson
// Date: 8/20/2010

#include "stdafx.h"     // needed for MS C++ Express users
#include "conio.h"      // needed for MS C++ Express users
using namespace System  // needed for MS C++ Express users

#include <iostream>
using namespace std;

int main()
{
  double firstnum = 105.62;
  double secnum = 89.352;
  double thirdnum = 98.67;
  double total, average;

  total = firstnum + secnum + thirdnum;
  average = total / 2.0;

  cout << "For the numbers " << firstnum << "  "
	   << secnum << "  " << thirdnum << endl;
  cout << "The total is " << total << endl;
  cout << "The average is " << average << endl;

  cin.ignore(); // needed for MS C++ Express users

  return 0;
}
