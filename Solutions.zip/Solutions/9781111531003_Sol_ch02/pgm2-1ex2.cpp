// File: pgm2-1ex2.cpp
// Description: 2.1 Exercise 2
// Programmer: G. Bronson
// Date: 8/21/2010

#include "stdafx.h"     // needed for MS C++ Express users
#include "conio.h"      // needed for MS C++ Express users
using namespace System  // needed for MS C++ Express users

#include <iostream>
using namespace std;

int main()
{
  cout << "\nData Type  Bytes"
       << "\n---------  -----"
       << "\nint          " << sizeof(int)
       << "\nchar         " << sizeof(char)
       << "\nbool         " << sizeof(bool) 
       << '\n';

  cin.ignore();  // needed for MS C++ Express users
   	  
  return 0;
}

