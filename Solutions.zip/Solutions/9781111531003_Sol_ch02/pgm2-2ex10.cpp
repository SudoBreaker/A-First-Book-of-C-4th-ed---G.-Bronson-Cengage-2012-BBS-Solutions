// File: pgm2-2ex10.cpp
// Description: 2.2 Exercise 10
// Programmer: G. Bronson
// Date: 8/20/2010

#include "stdafx.h"     // needed for MS C++ Express users
#include "conio.h"      // needed for MS C++ Express users
using namespace System  // needed for MS C++ Express users

#include <iostream>
using namespace std;

int main()
{  
	cout << "The result of 3.0 * 5.0 is " << (3.0 * 5.0);  
	cout << "\nThe result of 7.1 * 8.3 - 2.2 is " << (7.1 * 8.3 - 2.2);
	cout << "\nThe result of 3.2 / (6.1 * 5) is " << (3.2 / (6.1 * 5)); 
 
	cin.ignore(); 	// needed for MS C++ Express users  
	return 0;
}
