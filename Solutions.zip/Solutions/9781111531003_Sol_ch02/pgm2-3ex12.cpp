// File: pgm2-3ex12.cpp
// Description: 2.3 Exercise 12
// Programmer: G. Bronson
// Date: 8/20/2010

#include "stdafx.h"     // needed for MS C++ Express users
#include "conio.h"      // needed for MS C++ Express users
using namespace System  // needed for MS C++ Express users

#include <iostream>
using namespace std;

int main()
{

  int num1 = 15;
  int num2 = 18;
  int total;
  double average;

  total = num1 + num2;
  average = total / 2;
  cout << "The average of " << num1
       << " and " << num2 << " is " 
       << average << endl;

  cin.ignore();    // needed for MS C++ Express users 

  return 0;
}
