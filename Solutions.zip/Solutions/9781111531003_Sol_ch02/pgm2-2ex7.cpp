// File: pgm2-2ex7.cpp
// Description: 2.2 Exercise 7
// Programmer: G. Bronson
// Date: 8/20/2010

#include "stdafx.h"     // needed for MS C++ Express users
#include "conio.h"      // needed for MS C++ Express users
using namespace System  // needed for MS C++ Express users

#include <iostream>
using namespace std;

int main()
{  
	cout << "15.0 plus 2.0 equals "       << (15.0 + 2.0) << endl
           << "15.0 minus 2.0 equals "      << (15.0 - 2.0) << endl
           << "15.0 times 2.0 equals "      << (15.0 * 2.0) << endl
           << "15.0 divided by 2.0 equals " << (15.0 / 2.0) << endl; 
 
	cin.ignore();  // needed for MS C++ Express users  

	return 0;
}
