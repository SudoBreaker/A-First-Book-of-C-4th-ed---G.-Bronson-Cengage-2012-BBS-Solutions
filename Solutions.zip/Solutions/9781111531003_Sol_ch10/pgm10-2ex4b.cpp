// File: pgm10-2ex4b.cpp
// Description: 10.2 Exercise 4b
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Complex
{
  private:
    double real;
    double imaginary;
  public:
    Complex(double = 0, double = 0);       // constructor
    void setvals(double, double);  // assignment member function
    void showdata();     // display member function
};

// class implementation section
Complex::Complex(double re, double im)
{
  real = re;
  imaginary = im;
}
void Complex::setvals(double re, double im)
{
  real = re;
  imaginary = im;
}
void Complex::showdata()
{
  double c;
  char sign = '+';

  c = imaginary;
  if (c < 0)
  {
    sign = '-';
    c = -c;
  }
  cout << "The complex number is "
       << setiosflags(ios::fixed)
       << real << ' ' << sign << ' ' << c << "i\n";

}

 
int main()
{
  Complex a, b, c(4.2, 3.6);  // declare 3 objects

  b.setvals( 3.62,  8.45);    // assign values to b's data members
  a.showdata();               // display object a's values
  b.showdata();               // display object b's values
  c.showdata();               // display object c's values

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
