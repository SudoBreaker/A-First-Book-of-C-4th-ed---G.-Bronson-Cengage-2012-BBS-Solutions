// File: pgm10-2ex4c.cpp
// Description: 10.2 Exercise 4c
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Circle
{
  private:
    int xcenter;
    int ycenter;
    double radius;
  public:
    Circle(int = 1, int = 1, double = 1.0);        // constructor
    void setvals(int, int, double);  // member function to assign a time
    void showdata();            // member function to display a time
};

// class implementation section
Circle::Circle(int xx, int yy, double rr)
{
  xcenter = xx;
  ycenter = yy;
  radius = rr;
}
void Circle::setvals(int xx, int yy, double rr)
{
  xcenter = xx;
  ycenter = yy;
  radius = rr;
}

 
void Circle::showdata()
{
  cout << "The center of the circle is at "
       << '(' << setfill('0') << xcenter << ','
       << setfill('0') << ycenter << ')'
       << " and the radius is " << radius << endl;
}

int main()
{
  Circle a, b, c(10,12,5.8);  // declare 3 objects

  b.setvals(2,4,3.3);   // assign values to b's data members

  a.showdata();         // display object a's values
  b.showdata();         // display object b's values
  c.showdata();         // display object c's values    

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
