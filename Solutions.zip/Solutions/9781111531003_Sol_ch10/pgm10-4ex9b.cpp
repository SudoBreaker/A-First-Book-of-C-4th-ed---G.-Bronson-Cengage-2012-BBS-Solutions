// File: pgm10-4ex9b.cpp
// Description: 10.4 Exercise 9b
// Programmer: G. Bronson
// Employee: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

//  class declaration section
class Food
{
  private: 
	string type;
	string basicType;

  public:
    Food(string, string);  
	void setData(string, string);
	void showData();
};

  // class implementation section
  Food::Food(string t, string bt = "")  
  {
    type = t;
	basicType = bt;
  }
 
  void Food::setData(string t, string bt = "")
  {
    type = t;
	basicType = bt;
  }

  void Food::showData()
  {
        
	  cout << "The food type is: " << type << endl;
	  if(basicType != "")
		  cout << "The basic type is: " << basicType << endl;
  }

  int main()
  {
	  string type, bt;

	  cout << "Please enter a type for food 1: ";
	  getline(cin, type);
	  cout << "Please enter a type for food 1 (ENTER for none): ";
	  getline(cin, bt);
	  Food f1(type, bt);

	  cout << "\nPlease enter a type for food 2: ";
	  getline(cin, type);
	  cout << "Please enter a type for food 2 (ENTER for none): ";
	  getline(cin, bt);
	  Food f2(type, bt);

	  cout << "\nPlease enter a type for food 3: ";
	  getline(cin, type);
	  cout << "Please enter a type for food 3 (ENTER for none): ";
	  getline(cin, bt);
	  Food f3(type, bt);

	  cout << "\nPlease enter a type for food 4: ";
	  getline(cin, type);
	  cout << "Please enter a type for food 4 (ENTER for none): ";
	  getline(cin, bt);
	  Food f4(type, bt);


	  cout << "\nData for food 1:" << endl;
	  f1.showData();
	  cout << "\nData for food 2:" << endl;
	  f2.showData();
	  cout << "\nData for food 3:" << endl;
	  f3.showData();
	  cout << "\nData for food 4:" << endl;
	  f4.showData();	     

	  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

      return 0;
}

