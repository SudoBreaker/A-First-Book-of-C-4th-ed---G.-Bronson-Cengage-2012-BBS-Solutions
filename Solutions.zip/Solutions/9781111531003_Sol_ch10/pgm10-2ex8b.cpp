// File: pgm10-2ex8b.cpp
// Description: 10.2 Exercise 8b
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

// class declaration section
class Date
{
  private:
     int month;
     int day;
     int year;
   public:
     Date(int = 7, int = 4, int = 2012);         // constructor
     void setdate(int, int, int); // member function to assign a date
     void showdate();         // member function to display a date
     int dayOfWeek();          // the additional member function
};

// class implementation section
Date::Date(int mm, int dd, int yy)
{
  month = mm;
  day = dd;
  year = yy;
}
void Date::setdate(int mm, int dd, int yy)
{
  month = mm;
  day = dd;
  year = yy;
}
void Date::showdate(void)
{
  cout << "The date is ";
  cout << setfill('0')
	   << setw(2) << month << '/' 
	   << setw(2) << day << '/' 
	   << setw(2) << year % 100;
}
int Date::dayOfWeek()
{
	int T, mm, dd, yy, cc, dayOfWeek;

	mm = month;
	yy = year;
	dd = day;

	if(mm < 3)
	{
		mm = mm + 12;
		yy = yy - 1;
	}

	cc = (int)(yy/100);
	yy = yy % 100;
	T = dd + (int)(26 * (mm + 1)/10) + yy;
	T = T + (int)(yy/4) + (int)(cc/4) - 2 * cc;
	dayOfWeek = T % 7;
	if(dayOfWeek < 0) dayOfWeek = dayOfWeek + 7;
	return dayOfWeek;	
}

int main()
{
   Date a, b, c(4,1,2000);  // declare 3 objects

   b.setdate(12,25,2009);  // assign values to b's data members

   string days[] = {"Saturday", "Sunday", "Monday", "Tuesday", 
					"Wednesday", "Thursday", "Friday"};
 
   a.showdate();
   cout << endl;
   cout << "The day of the week is " << days[a.dayOfWeek()] << endl;
   b.showdate();
   cout << endl;
   cout << "The day of the week is " << days[b.dayOfWeek()] << endl;
   c.showdate();
   cout << endl;
   cout << "The day of the week is " << days[c.dayOfWeek()] << endl;      

   cin.ignore();   // needed for MS C++ Express 2010 programs
 
   return 0;
}
