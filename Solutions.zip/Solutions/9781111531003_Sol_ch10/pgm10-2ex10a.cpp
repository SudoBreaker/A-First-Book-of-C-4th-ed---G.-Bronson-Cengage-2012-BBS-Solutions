// File: pgm10-2ex10a.cpp
// Description: 10.2 Exercise 10a
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>  // needed for formatting
using namespace std;

// class declaration section
{
  private: 
	int month;
    int day;
    int year;
  public:
    Date(int = 7, int = 4, int = 2012);
    void setDate(int, int, int);  
    void showDate(); 
	bool isLeapYear();   // using this is optional
	void nextDay();
};

  // class implemetation section
  Date::Date(int mm, int dd, int yyyy)  // this is an overloaded constructor
  {
    month = mm;
    day = dd;
    year = yyyy;
  }
 
  void Date::setDate(int mm, int dd, int yyyy)
  {
    month = mm;
    day = dd;
    year = yyyy;
	return;
  }

  void Date::showDate()
  {
        
    cout << "The date is " << setfill('0')
		 << setw(2) << month << '/'
		 << setw(2) << day << '/'
		 << setw(2) << year % 100; // extract the last 2 year digits
    cout << endl; 
  }

  bool Date::isLeapYear()
  {
    if ( (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0) )
      return true;  // is a leap year
    else
      return false;  // is not a leap year
  }

  void Date::nextDay()
  {
	day += 1;
	
	if(month == 9 || month == 4 || month == 6 || month == 11)
	{
		if(day == 31)
		{
			month += 1;
			day = 1;
		}
	}
	else if(month == 2)
	{
		if(isLeapYear())
		{
			if(day == 30)
			{
				month += 1;
				day = 1;
			}
		}
		else
		{
			if(day == 29)
			{
				month += 1;
				day = 1;
			}
		}
	}
	else
	{
		if(day == 32)
		{
			month += 1;
			day = 1;
		}
	}

	//change the year if necessary
	if(month == 13)
	{
		month = 1;
		day = 1;
		year += 1;
	}
		
  }


  int main()
  {
    Date a, b, c(4, 1, 2000), d(2, 28, 2012);

	b.setDate(12, 31, 2009);

	a.showDate();
	b.showDate();
	c.showDate();
	d.showDate();
	cout << endl;

	a.nextDay();
	b.nextDay();
	c.nextDay();
	d.nextDay();

	a.showDate();
	b.showDate();
	c.showDate();
	d.showDate();     

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}

