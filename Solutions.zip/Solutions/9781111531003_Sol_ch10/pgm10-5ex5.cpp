// File: pgm10-5ex5.cpp
// Description: 10.5 Exercise 5
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <math.h>
using namespace std;

//  class declaration section
class Complex
{
  // friends list
  friend Complex addComplex(Complex&, Complex&);
 
  private:
    double real;
    double imag;
 
  public:
    Complex(double = 0, double = 0);  // constructor
    void display();

};

// class implementation section

Complex::Complex(double rl, double im)
{
  real = rl;
  imag = im;
}

void Complex::display()
{
  char sign = '+';

  if(imag < 0) sign = '-';
  cout << real << sign << fabs(imag) << 'i';

  return;
}

// friend implementations

Complex addComplex(Complex &a, Complex &b)
{
	Complex temp;

	temp.real = a.real + b.real;
	temp.imag = a.imag + b.imag;
  
	return temp;
}

int main()
{
  Complex a(3.2, 5.6), b(1.1,  8.4), c;
  double re, im;

  cout << "\nThe first complex number is ";
  a.display();
  cout << "\nThe second complex number is ";
  b.display();

  c = addComplex(a, b);

  cout << "\n\nThe sum of these two complex numbers is ";
  c.display();
  cout << endl;       

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

