// File: pgm10-3ex3.cpp
// Description: 10.3 Exercise 3
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Date
{
  private:
     long yyyymmdd;
   public:
     Date(int = 7, int = 4, int = 2012);         // constructor
	 Date(long);
     void showdate();         // member function to display a date
};

// class implementation section
Date::Date(int mm, int dd, int yyyy)
{
  yyyymmdd = yyyy * 10000L + mm * 100L + dd;
}

Date::Date(long ymd)
{
	yyyymmdd = ymd;
}

void Date::showdate(void)
{
  int year, month, day;

  year = (int)(yyyymmdd/10000.0);
  month = (int)((yyyymmdd - year * 10000.0)/100.0);
  day = (int)(yyyymmdd - year * 10000.0 - month * 100.0);

  cout << "The date is ";
  cout << setfill('0')
	   << setw(2) << month << '/' 
	   << setw(2) << day << '/' 
	   << setw(2) << year % 100;

}

int main()
{
   Date a, b(4,1,1998), c(20090515L);

   a.showdate();
   cout << endl;

   b.showdate();
   cout << endl;

   c.showdate();
   cout << endl << endl;

   cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
