// File: pgm10-2ex7b.cpp
// Description: 10.2 Exercise 7b
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Date
{
  private:
     int month;
     int day;
     int year;
   public:
     Date(int = 7, int = 4, int = 2012);         // constructor
     void setdate(int, int, int); // member function to copy a date
     void showdate();         // member function to display a date
     int leapyr();          // the additional member function
};

// class implementation section
Date::Date(int mm, int dd, int yy)
{
  month = mm;
  day = dd;
  year = yy;
}
void Date::setdate(int mm, int dd, int yy)
{
  month = mm;
  day = dd;
  year = yy;
}
void Date::showdate(void)
{
  cout << "The date is ";
  cout << setfill('0')
	   << setw(2) << month << '/' 
	   << setw(2) << day << '/' 
	   << setw(2) << year % 100;
}
int Date::leapyr()
{
	int fullyr;

	fullyr = year;
	if( (fullyr % 4 == 0 && fullyr % 100 != 0) || (fullyr % 400 == 0))
		return 1;  // is a leap year
	else
	    return 0;  // is not a leap year
}

int main()
{
   Date a, b, c(4,1,2000);  // declare 3 objects

   b.setdate(12,25,2009);  // assign values to b's data members
 
   a.showdate();
   cout << endl;
   if(a.leapyr() == 1)
	   cout << "The year is a leap year" << endl;
   else
	   cout << "The year is not a leap year" << endl;

   b.showdate();
   cout << endl;
   if(b.leapyr() == 1)
	   cout << "The year is a leap year" << endl;
   else
	   cout << "The year is not a leap year" << endl;

   c.showdate();
   cout << endl;
   if(c.leapyr() == 1)
	   cout << "The year is a leap year" << endl;
   else
	   cout << "The year is not a leap year" << endl;   

   cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
