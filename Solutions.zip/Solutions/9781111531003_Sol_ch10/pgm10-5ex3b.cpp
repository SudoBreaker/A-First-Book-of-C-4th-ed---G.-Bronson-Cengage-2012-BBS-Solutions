// File: pgm10-5ex3b.cpp
// Description: 10.5 Exercise 3b
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <math.h>
using namespace std;

//  class declaration section
class Complex
{
  // friends list
  friend double addreal(Complex&, Complex&);
  friend double addimag(Complex&, Complex&);
   
  private:
    double real;
    double imag;
 
  public:
    Complex(double = 0, double = 0);  // constructor
    void display();

};

// class implementation section

Complex::Complex(double rl, double im)
{
  real = rl;
  imag = im;
}

void Complex::display()
{
  char sign = '+';

  if(imag < 0) sign = '-';
  cout << real << sign << fabs(imag) << 'i';

  return;
}

// friend implementations

double addreal(Complex &a, Complex &b)
{
  return(a.real + b.real);
}

double addimag(Complex &a, Complex &b)
{
  return(a.imag + b.imag);
}

int main()
{
  Complex a(3.2, 5.6), b(1.1, -8.4);

  cout << "\nThe first complex number is ";
  a.display();
  cout << "\nThe second complex number is ";
  b.display();

  Complex c(addreal(a,b), addimag(a,b));  // new statement
  cout << "\n\nThe sum of these two complex numbers is ";
  c.display();
  cout << endl;    

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

