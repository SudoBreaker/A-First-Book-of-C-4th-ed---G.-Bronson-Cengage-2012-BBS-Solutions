// File: pgm10-5ex2b.cpp
// Description: 10.5 Exercise 2b
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

// class declaration section
class Circle
{
  private:
    int xCenter;
    int yCenter;
    double radius;
    static double scaleFactor;

  public:
    Circle(int = 2, int = 2, double = 1);      // constructor
    void display();               // access function
};

// static member definition
double Circle::scaleFactor = 1.25;

// class implementation section
Circle::Circle(int x, int y, double r)
{
  xCenter = x;
  yCenter = y;
  radius = r;
}
void Circle::display()
{
  cout << "The values of the object are:\n"
       << "  xCenter = " << xCenter << endl
       << "  yCenter = " << yCenter << endl
       << "  radius = " << radius << endl
       << "  and the static scale factor is "
       << scaleFactor << endl;
  return;
}

int main()
{
 
  Circle c1, c2(3,8,2.6);

  c1.display();
  c2.display();    

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

