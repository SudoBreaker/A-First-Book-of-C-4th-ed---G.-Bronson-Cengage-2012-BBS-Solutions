// File: pgm10-2ex4d.cpp
// Description: 10.2 Exercise 4d
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class System
{
	private:
		char computer[30];
		char printer[30];
		char screen[30];
		double compPrice;
		double printPrice;
		double scrnPrice;

	public:
		System(char[], char[], char[], double = 1000.0, double = 300.00,
		double = 200.00);	// constructor
		void showdata();
};

 
// class implementation section
System::System(char comp[30], char prnt[30], char scrn[30], double cp, double pp, double sp)
{
	strcpy(computer, comp);
	strcpy(printer, prnt);
	strcpy(screen, scrn);

	compPrice = cp;
	printPrice = pp;
	scrnPrice = sp;

	// Check for negative prices

	if (compPrice < 0)
		compPrice = -compPrice;

	if (printPrice < 0)
		printPrice = -printPrice;

	if (scrnPrice < 0)
		scrnPrice = -scrnPrice;
}

void System::showdata()
{
	cout << "System configuration:" << endl << endl;
	cout << "Computer type: " << computer << endl;
	cout << "Cost: $" << compPrice << endl << endl;
	cout << "Printer type: " << printer << endl;
	cout << "Cost: $" << printPrice << endl << endl;
	cout << "Monitor type: " << screen << endl;
	cout << "Cost: $" << scrnPrice << endl << endl;
}

int main()
{
	System a("ACME 2500","ACME Laser","LCD display",
	          2999.99,799.99,1299.99);

	a.showdata();

    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
