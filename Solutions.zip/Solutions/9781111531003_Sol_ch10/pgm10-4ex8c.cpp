// File: pgm10-4ex8c.cpp
// Description: 10.4 Exercise 8c
// Programmer: G. Bronson
// Employee: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

//  class declaration section
class Employee
{
  private: 
	int idNum;
	double payRate;
	double maxHours;

  public:
    Employee(int = 0, double = 0, double = 0);  
	void setData(int id, double pay, double hrs);
	void deleteEmp();
	void showData();
	int getId();
};

  // class implementation section
  Employee::Employee(int id, double pay, double hrs)  
  {
    idNum = id;
	payRate = pay;
	maxHours = hrs;
  }

  int Employee::getId()
  {
    return idNum;
  }
 
  void Employee::setData(int id, double pay, double hrs)
  {
    idNum = id;
	payRate = pay;
	maxHours = hrs;
  }

  void Employee::deleteEmp()
  {
    idNum = 0;
	payRate = 0;
	maxHours = 0;
  }

  void Employee::showData()
  {
        
	  cout << "The ID number is: "
		   << idNum << endl;
	  cout << "The maximum hours worked is: "
		   << maxHours << endl;
	  cout << "The pay rate is: "
		   << payRate << endl;
  }

  int main()
  {
	  int id, oldId, choice, count = 0, index, i;
	  double pay, hrs;
	  Employee *emps = new Employee[100];  // any max number will work

	  do{
		  cout << "\n1. Add an employee" << endl;
		  cout << "2. Modify employee data" << endl;
		  cout << "3. Delete an employee" << endl;
		  cout << "4. Exit this menu" << endl;
		  cin >> choice;

		  if(choice != 4)
		  {
			  if(choice == 1)
			  {
				  cout << "Please enter an id number for the new employee: ";
				  cin >> id;
				  cout << "Please enter the max hours for the new employee: ";
				  cin >> hrs;
				  cout << "Please enter the pay rate for the new employee: ";
				  cin >> pay;
				  emps[count].setData(id, pay, hrs);
				  count++;
			  }
			  else if(choice == 2)
			  {
				  if(emps[0].getId() == 0)
					  cout << "You must add an employee first" << endl;
				  else
				  {
					  cout << "Please enter the old id number: ";
					  cin >> oldId;
					  for(i = 0; i < count; i++)
					  {
						  if(emps[i].getId() == oldId)
							  index = i;
						  else
							  index = -1;
					  }
					  if(index == -1)
						  cout << "Employee with that ID doesn't exist!" << endl;
					  else
					  {
						  cout << "Please enter a new id number: ";
						  cin >> id;
						  cout << "Please enter new max hours: ";
						  cin >> hrs;
						  cout << "Please enter a new pay rate: ";
						  cin >> pay;
						  emps[index].setData(id, hrs, pay);
					  }
				  }
			  }
			  else if(choice == 3)
			  {
				  if(emps[0].getId() == 0)
					  cout << "You must add an employee first" << endl;
				  else
				  {
					  cout << "Please enter the id number: ";
					  cin >> oldId;
					  for(i = 0; i < count; i++)
					  {
						  if(emps[i].getId() == oldId)
							  index = i;
						  else
							  index = -1;
					  }
					  if(index == -1)
						  cout << "Employee with that ID doesn't exist!" << endl;
					  else
					  {
						emps[index].deleteEmp();
						cout << "Employee was deleted" << endl;
					  }
				  }
			  }
		  }
	  }while(choice != 4);

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}

