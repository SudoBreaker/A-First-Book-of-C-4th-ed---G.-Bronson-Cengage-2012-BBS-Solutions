// File: pgm10-4ex9c.cpp
// Description: 10.4 Exercise 9c
// Programmer: G. Bronson
// Employee: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

//  class declaration section
class Food
{
  private: 
	string type;
	string basicType;

  public:
    Food(string, string);  
	void setData(string, string);
	void showData();
	void deleteFood();
	string getType();
};

  // class implementation section
  Food::Food(string t = "", string bt = "")  
  {
    type = t;
	basicType = bt;
  }

  string Food::getType()
  {
	  return type;
  }
 
  void Food::setData(string t, string bt = "")
  {
    type = t;
	basicType = bt;
  }

  void Food::deleteFood()
  {
    type = "";
	basicType = "";
  }

  void Food::showData()
  {
        
	  cout << "The food type is: " << type << endl;
	  if(basicType != "")
		  cout << "The basic type is: " << basicType << endl;
  }

 
int main()
  {
	  int choice, count = 0, index, i;
	  string type, bt, oldType;
	  Food *fds = new Food[100];  // any max number will work

	  do{
		  cout << "\n1. Add a food item" << endl;
		  cout << "2. Modify a food item" << endl;
		  cout << "3. Delete a food item" << endl;
		  cout << "4. Exit this menu" << endl;
		  cin >> choice;
		   

		  if(choice != 4)
		  {
			  if(choice == 1)
			  {
				  cout << "\nPlease enter a type for new food: ";
				  getline(cin, type);
				  cout << "Please enter a new basic type (ENTER for none): ";
				  getline(cin, bt);
				  fds[count].setData(type, bt);
				  count++;
			  }
			  else if(choice == 2)
			  {
				  if(count == 0)
					  cout << "You must add a food first" << endl;
				  else
				  {
					  cout << "Please enter the old type: ";
					  getline(cin, oldType);
					  for(i = 0; i < count; i++)
					  {
						  if(fds[i].getType() == oldType)
							  index = i;
						  else
							  index = -1;
					  }
					  if(index == -1)
						  cout << "Food w/that type doesn't exist!" << endl;
					  else
					  {
						  cout << "\nPlease enter a new type: ";
						  getline(cin, type);
						  cout << "Please enter a new basic type (ENTER for none): ";
						  getline(cin, bt);
						  fds[index].setData(type, bt);
					  }
				  }
			  }
			  else if(choice == 3)
			  {
				  if(count == 0)
					  cout << "You must add a food first" << endl;
				  else
				  {
					  cout << "Please enter the old type: ";
					  getline(cin, oldType);
					  for(i = 0; i < count; i++)
					  {
						  if(fds[i].getType() == oldType)
							  index = i;
						  else
							  index = -1;
					  }
					  if(index == -1)
						  cout << "Food w/that type doesn't exist!" << endl;
					  else
					  {
						fds[index].deleteFood();
						cout << "Food was deleted" << endl;
					  }
				  }
			  }
		  }
	  }while(choice != 4);

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}


