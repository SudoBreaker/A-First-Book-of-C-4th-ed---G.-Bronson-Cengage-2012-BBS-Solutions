// File: pgm10-4ex3.cpp
// Description: 10.4 Exercise 3
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

//  class declaration section
class RoomType
{
  private: 
    double length;  // declare length as a double variable
    double width;   // declare width as a double variable 

  public:
    RoomType(double = 0.0, double = 0.0); // the constructor's declaration statement 
    void showRoomValues();  
    void setNewRoomValues(double, double);  
    double calculateRoomArea(); 
};

// class implementation section
RoomType::RoomType(double l, double w)  // this is a constructor
{
  length = l;
  width = w;
  cout << "Created a new room object using the default constructor.\n\n";
} 

void RoomType::showRoomValues()   // this is an accessor
{
  cout << "  length = " << length 
       << "\n   width = " << width << endl;
}

void RoomType::setNewRoomValues(double l, double w)   // this is a mutator 
{  
  length = l;
  width = w;
}

double RoomType::calculateRoomArea()  // this performs a calculation
{    
  return(length * width);  
}

int main()
{
  RoomType hall(12.4, 3.5);
  RoomType kitchen(14, 14);
  RoomType livingRoom(12.4, 20);
  RoomType diningRoom(14, 10.5);

  double hallArea, kitArea, livingArea, diningArea;

  hallArea = hall.calculateRoomArea();     // in order to save these values I had to modify
  kitArea = kitchen.calculateRoomArea();   // the calculateArea function to return a value - this is optional
  livingArea = livingRoom.calculateRoomArea();
  diningArea = diningRoom.calculateRoomArea();

  cout << "The floor area of the hall is: " << hallArea << endl;
  cout << "The floor area of the kitchen is: " << kitArea << endl;
  cout << "The floor area of the living room is: " << livingArea << endl;
  cout << "The floor area of the dining room is: " << diningArea << endl;

  cout << "\nThe total area is: " << hallArea + kitArea + livingArea + diningArea << endl;  

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
