// File: pgm10-3ex4b.cpp
// Description: 10.3 Exercise 4b
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
#include <math.h>
using namespace std;

const double CONVERT = 3.1416/180.0; // conversion from angle to radian measure

// class declaration section
class XY_Coord
{
   private:
    double xval;
    double yval;
  public:
    XY_Coord(double = 0.0, double = 0.0); // constructor
    void input(double, double);  // input data member values
    void showdata(); // display data member values
	void ConvToCartesian(XY_Coord&, double, double);
};

// class implementation section
XY_Coord::XY_Coord(double x, double y)
{
  xval = x;
  yval = y;
}

void XY_Coord::input(double newxval, double newyval)
{
  xval = newxval;
  yval = newyval;
  return;
}

void XY_Coord::showdata()
{
  cout << "(" << xval << ", " << yval << ")" << endl;
  return;
}


void XY_Coord::ConvToCartesian(XY_Coord& a, double dist, double angle)
{
  a.xval = dist * cos(CONVERT * angle);
  a.yval = dist * sin(CONVERT * angle);

  return;
}

int main()
{
  XY_Coord a;  // declare one object
  double r, theta;

  cout << "Point a is initially located at ";
  a.showdata();      // display object a's values
  cout << "Enter a new distance and angle for point a: ";
  cin >> r >> theta;
  ConvToCartesian(a, r, theta);
  cout << "Point a is now located at ";
  a.showdata();      

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

