// File: pgm10-3ex5b.cpp
// Description: 10.3 Exercise 5b
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

// class declaration section
class Student
  private: 
    int studentID;  // declare studentID as an int variable
    double grades[5];
	int totGrades; 
  public:  
	Student(int = 0, double[5] = 0, int = 0); // the constructor's declaration statement
    void showData();  
	void setStudentID(int);
	void setGrade(double);
	void showAverage();
};

// class implementation section
Student::Student(int id, double g[], int tot)  // this is a constructor
{
  int i;

  studentID = id;

  for(i = 0; i < tot; i++)
	grades[i] = g[i];
  totGrades = tot;
  
} 

void Student::setStudentID(int id)
{
	studentID = id;
}

void Student::setGrade(double gd)
{
	grades[totGrades] = gd;
	totGrades++;
}

void Student::showAverage()
{
	double avg = 0;
	int i;

	for(i = 0; i < totGrades; i++)
		avg = avg + grades[i];

	avg = avg/totGrades;

	cout << studentID << ":  " << avg << endl;
}



void Student::showData()   // this is an accessor
{
  int i;

  cout << "  studentID = " << studentID 
	  << "\n  Grades: " << endl;
  for(i = 0; i < 5; i++)
	  cout << "\t    " << grades[i] << endl;
  cout << "total grades = " << totGrades << endl;
  
}

int main()
{
  Student student1;  // declare a variable of type Student
  Student student2;  // declare a second variable of type Student

  cout << "The values for the student1 object are:\n";
  student1.showData();       // use a class method on this object

  cout << "The values for the student2 object are:\n";
  student2.showData();       // use a class method on this object

  student1.setGrade(98.2);
  student1.setGrade(92);
  student1.setGrade(87);
  student1.setStudentID(1234);

  cout << "T\nhe new values for student1 are:\n";
  student1.showData();

  cout << "Average: \n";
  student1.showAverage();

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}


