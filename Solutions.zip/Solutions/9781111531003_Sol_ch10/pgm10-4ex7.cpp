// File: pgm10-4ex7.cpp
// Description: 10.4 Exercise 7
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

//  class declaration section
class Light
{
  private:
	string color;

  public:
	Light(); // default constructor
	void change();
};
  // class implementation section
  Light::Light()  // this is the default constructor
  {
	  color = "red";
  }

  void Light::change()
  {
    if(color == "red")
	{
		color = "green";
		cout << "The color changed to green" << endl;
	}
	else if(color == "yellow")
	{
		color = "red";
		cout << "The color changed to red" << endl;
	}
	else
	{
		color = "yellow";
		cout << "The color changed to yellow" << endl;
	}
  }

int main()
{
  Light a;  // declare 1 object of type Light

  a.change();
  a.change();
  a.change();
  a.change();
         
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}


