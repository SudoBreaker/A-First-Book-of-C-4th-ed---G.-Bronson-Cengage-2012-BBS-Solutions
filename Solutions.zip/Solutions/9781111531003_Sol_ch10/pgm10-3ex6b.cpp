// File: pgm10-3ex6b.cpp
// Description: 10.3 Exercise 6b
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

//  class declaration section
class Time
{
  private: 
    int seconds;  // declare seconds as an int variable
    int minutes;   // declare minutes as an int variable
	int hours;   // declare minutes as an int variable 
  public:  
    Time(int = 0, int = 0, int = 0);   // default constructor
    Time(long);             // another constructor
    void showdata();    // member function to display a Time
	void detick();
};

// class implementation section
Time::Time(int hh, int mm, int ss)  
{
  hours = hh;
  minutes = mm;
  seconds = ss;
}
Time::Time(long hms)
{
  hours = int (hms/3600);
  minutes = int ((hms - hours * 3600L)/60);
  seconds = hms - hours * 3600L - minutes * 60;
  while (hours > 12) hours  = 12; // put in the range 0 to 12
}
void Time::showdata(void)
{
  cout << "The time is "
       << setw(2) << setfill('0') << hours << ':'
       << setw(2) << setfill('0') << minutes << ':'
       << setw(2) << setfill('0') << seconds << endl;
}

void Time::detick()
{
	seconds-=1;

	if(seconds < 0)
	{
		minutes -= 1;
		seconds = 59;
	}

	if(minutes < 0)
	{
		hours -= 1;
		minutes = 59;
	}
}



int main()
{
  Time t1(12, 58, 00), t2(180312L);  // declare a variable of type Time

  t1.showdata();
  t2.showdata();
  cout << endl;

  t1.detick();
  t2.detick();

  t1.showdata();
  t2.showdata();
  cout << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}


