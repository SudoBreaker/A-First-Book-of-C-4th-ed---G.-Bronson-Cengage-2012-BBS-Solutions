// File: pgm10-4ex6.cpp
// Description: 10.4 Exercise 6
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <ctime>
using namespace std;

// class declaration section
class Elevator
{
  private:
	int elNum;
    int currentFloor; 
    int highestFloor;
  public:
    Elevator(int = 1, int = 1, int = 15);   // constructor
    void request(int);
};

// class implementation section
Elevator::Elevator(int idnum, int cfloor, int maxfloor)
{
  elNum = idnum;
  currentFloor = cfloor;
  highestFloor = maxfloor;
  cout << "\nA new elevator object is created with the following atrributes:"
       << "\nElevator number: " << elNum
	   << "\nStarting Floor: " << cfloor
	   << "\nHighest floor: " << highestFloor << endl;
}
void Elevator::request(int newfloor)
{

 if (newfloor < 1 || newfloor > highestFloor || newfloor == currentFloor)
    ;  // do nothing
  else if (newfloor > currentFloor) // move elevator up
  {
    cout << "\nElevator " << elNum 
         << " starting at floor " << currentFloor << endl;
    while (newfloor > currentFloor)
    {
      currentFloor++; // add one to current floor
      cout << " Going Up - now at floor " << currentFloor << endl;
    }
    cout << "Elevator " << elNum 
         << " stopping at floor " << currentFloor << endl;
  }
  else // move elevator down
  {
    cout << "\nElevator " << elNum 
         << " starting at floor " << currentFloor << endl;
    while (newfloor < currentFloor)
    {
      currentFloor--;   // subtract one from current floor
      cout << " Going Down - now at floor " << currentFloor << endl;
    }
    cout << "Elevator "<< elNum 
         << " Stopping at floor " << currentFloor << endl;
  }
  return;
}

int main()
{
  Elevator a;
  int count = 1;
  int randValue;
  int priorRequest = 1;

  srand(time(NULL));
  while(count < 6)   
  {
	randValue = 1 + rand() % 15;  //generate random number
	if (randValue != priorRequest)
	{
	  a.request(randValue);   //a valid request has been made
	  count++;
    } 
	else
	  continue;
  }

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
