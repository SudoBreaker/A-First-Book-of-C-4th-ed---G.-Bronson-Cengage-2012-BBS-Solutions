// File: pgm10-2ex4a.cpp
// Description: 10.2 Exercise 4a
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Time
{
  private:
    int hours;
    int mins;
 
    int secs;
  public:
    Time(int = 0, int = 0, int = 0);         // constructor
    void settime(int, int, int); // member function to assign a time
    void showdata();         // member function to display a time
};

// class implementation section
Time::Time(int hh, int mm, int ss)
{
  hours = hh;
  mins = mm;
  secs = ss;
}
void Time::settime(int hh, int mm, int ss)
{
  hours = hh;
  mins = mm;
  secs = ss;
}
void Time::showdata()
{
  cout << "The time is "
       << setw(2) << setfill('0') << hours << ':'
       << setw(2) << setfill('0') << mins << ':'
       << setw(2) << setfill('0') << secs << endl;
}

int main()
{
  Time a, b, c(8,20,10);  // declare 3 objects

  b.settime(1,8,3);  // assign values to b's data members
  a.showdata();      // display object a's values
  b.showdata();      // display object b's values
  c.showdata();      // display object c's values     

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
