// File: pgm10-5ex6b.cpp
// Description: 13.3 Exercise 6b
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

const double CONVERT = 3.1416/180.0; // conversion from angle to radian measure

// class declaration section
class Coord
{
 
  // friends list
  friend void convPol(Coord&, double, double);
  private:
    double xval;
    double yval;
  public:
    Coord(double = 0.0, double = 0.0); // constructor
    void input(double, double);  // input data member values
    void showdata(); // display data member values
};

// class implementation section
Coord::Coord(double x, double y)
{
  xval = x;
  yval = y;
}

void Coord::input(double newxval, double newyval)
{
  xval = newxval;
  yval = newyval;
  return;
}

void Coord::showdata()
{
  cout << "(" << xval << ", " << yval << ")" << endl;
  return;
}

// friend implementation
void convPol(Coord& a, double dist, double angle)
{
  a.xval = dist * cos(CONVERT * angle);
  a.yval = dist * sin(CONVERT * angle);

  return;
}

int main()
{
  Coord a;  // declare one object
  double r, theta;

  cout << "Point a is initially located at ";
  a.showdata();      // display object a's values
  cout << "Enter a new distance and angle for point a: ";
  cin >> r >> theta;
  convPol(a, r, theta);
  cout << "Point a is now located at ";
  a.showdata();  

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

