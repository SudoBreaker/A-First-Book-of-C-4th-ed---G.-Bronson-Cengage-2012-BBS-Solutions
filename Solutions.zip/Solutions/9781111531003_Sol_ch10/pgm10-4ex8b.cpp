// File: pgm10-4ex8b.cpp
// Description: 10.4 Exercise 8b
// Programmer: G. Bronson
// Employee: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

//  class declaration section
class Employee
{
  private: 
	int idNum;
	double payRate;
	double maxHours;

  public:
    Employee(int, double, double);  
	void setData(int id, double pay, double hrs);
	void showData();
};

  //  class implementation section
  Employee::Employee(int id, double pay, double hrs)  
  {
    idNum = id;
	payRate = pay;
	maxHours = hrs;
  }
 
  void Employee::setData(int id, double pay, double hrs)
  {
    idNum = id;
	payRate = pay;
	maxHours = hrs;
  }

  void Employee::showData()
  {
        
	  cout << "The ID number is: "
		   << idNum << endl;
	  cout << "The maximum hours worked is: "
		   << maxHours << endl;
	  cout << "The pay rate is: "
		   << payRate << endl;
  }

  int main()
  {
	  int id;
	  double pay, hrs;

	  cout << "Please enter an id number for employee 1: ";
      cin >> id;
	  cout << "Please enter the max hours for employee 1: ";
	  cin >> hrs;
	  cout << "Please enter the pay rate for employee 1: ";
	  cin >> pay;

	  Employee emp1(id, pay, hrs);

	  cout << "Please enter an id number for employee 2: ";
      cin >> id;
	  cout << "Please enter the max hours for employee 2: ";
	  cin >> hrs;
	  cout << "Please enter the pay rate for employee 2: ";
	  cin >> pay;

	  Employee emp2(id, pay, hrs);

	  cout << "Please enter an id number for employee 3: ";
      cin >> id;
	  cout << "Please enter the max hours for employee 3: ";
	  cin >> hrs;
	  cout << "Please enter the pay rate for employee 3: ";
	  cin >> pay;

	  Employee emp3(id, pay, hrs);

	  cout << "\nData for employee 1:" << endl;
	  emp1.showData();
	  cout << "\nData for employee 2:" << endl;
	  emp2.showData();
	  cout << "\nData for employee 3:" << endl;
	  emp3.showData();

	  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

      return 0;
}

