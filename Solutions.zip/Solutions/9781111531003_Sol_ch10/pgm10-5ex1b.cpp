// File: pgm10-5ex1b.cpp
// Description: 10.5 Exercise 1b
// Programmer: G. Bronson
// Date: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 
using namespace std;

//  class declaration section
class Employee
{
  private:
    static double taxRate;
	static int numemps;
    int idNum;

  public:
    Employee(int = 0);    // constructor
    void display();      // access function
    static void dispRate();  // static function
};

// static member definition
double Employee::taxRate = 0.25;
int Employee::numemps = 0;

// class implementation section
Employee::Employee(int num)
{
  idNum = num;
  numemps++;
}

void Employee::display()
{
  cout << "Employee number " << idNum
       << " has a tax rate of " << taxRate << endl;
}

void Employee::dispRate()
{
  cout << "The static tax rate is " << taxRate << endl;
  cout << "The number of employees is " << numemps << endl;
}

int main()
{
  Employee::dispRate();   // call the static functions
  Employee emp1(11122), emp2(11133);

  emp1.display();
  emp2.display();

  Employee::dispRate();  

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

