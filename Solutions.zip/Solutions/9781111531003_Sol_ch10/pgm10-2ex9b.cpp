// File: pgm10ex9b.cpp
// Description: 10.2 Exercise 9b
// Programmer: G. Bronson
// Rectangle: 9/6/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

// class declaration section
Class Rectangle
{
    private: 
	double length;
	double width;
  public:
    Rectangle(double = 0, double = 0);
	double perimeter();
	double area();
	void setData(double len, double wid);
	void showData();
};

// class implementation section
  Rectangle::Rectangle(double len, double wid) 
  {
    length = len;
	width = wid;
  }
 
  void Rectangle::setData(double len, double wid)
  {
    length = len;
	width = wid;
  }

  void Rectangle::showData()
  {
        
    cout << "\nThe Rectangle is "
		 << length << " by "
		 << width  << endl; 
	cout << "with a perimeter of: " << perimeter() << endl;
	cout << "and area of: " << area() << endl;
  }

  double Rectangle::perimeter()
  {
    return (2*length) + (2*width);
  }

  double Rectangle::area()
  {
    return (length * width);
  }

  int main()
  {
	double length, width;
	Rectangle rec;

	rec.showData();

	cout << "\nPlease enter the length: ";
	cin >> length;
	cout << "Please enter the width: ";
	cin >> width;

	rec.setData(length, width);

	rec.showData();	      

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}

