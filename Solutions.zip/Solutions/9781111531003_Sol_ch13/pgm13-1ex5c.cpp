// File: pgm13-1ex5c.cpp
// Description: 13.1 Exercise 5c
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

class MailingList
{
  private:
     string title;
     string firstName;
     string lastName;
     string address1;
     string address2;
     string city;
     string state;
     string zipCode;

   public:
     MailingList(string t, string f, string l, string a1, string a2, string c, string s, string zip)
     {
	    title = t;
	    firstName = f;
	    lastName = l;
	    address1 = a1;
	    address2 = a2;
	    city = c;
	    state = s;
	    zipCode = zip;
     }
     string getTitle() { return title; }
     string getFirstName() { return firstName; }
     string getLastName() { return lastName; }
     string getAddress1() { return address1; }
     string getAddress2() { return address2; }
     string getCity() { return city; }
     string getState() { return state; }
     string getZipCode() { return zipCode; }
};



int main()
{
  MailingList someList("Dr.", "Kay", "Kingsley", "Apt. 2B","614 Freeman Street", "", "Indianapolis", "IN", "07030");

  cout << "Title: " << someList.getTitle() << endl;
  cout << "Last Name: " << someList.getLastName() << endl;
  cout << "First Name: " << someList.getFirstName() << endl;
  cout << "Street Address 1: " << someList.getAddress2() << endl;
  cout << "Street Address 2: " << someList.getAddress1() << endl;
  cout << "City: " << someList.getCity() << endl;
  cout << "State: " << someList.getState() << endl;
  cout << "Zip Code: " << someList.getZipCode() << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs     
  
  return 0;
}            


