// File: pgm13-1ex5d.cpp
// Description: 13.1 Exercise 5d
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

class Stock
{
  private:
     string name;
     double price;
     int monthOfPurchase;
     int dayOfPurchase;
     int yearOfPurchase; 

   public:
     Stock(string n, double pr, int month, int day, int year)
     {
	name = n;
  	price = pr;
	monthOfPurchase = month;
	dayOfPurchase = day;
	yearOfPurchase = year;
     }
     string getName() { return name; }
     double getPrice() { return price; }
     int getMonthOfPurchase() { return monthOfPurchase; }
     int getDayOfPurchase() { return dayOfPurchase; }
     int getYearOfPurchase() { return yearOfPurchase; }
};

int main()
{
  Stock someStock("IBM", 134.5, 10, 1, 2010);

  cout << "Stock: " << someStock.getName() << endl;
  cout << "Price Purchased: " << someStock.getPrice() << endl;
  cout << "Date Purchased: " << someStock.getMonthOfPurchase()
	   << "/" << someStock.getDayOfPurchase() << "/"
	   << someStock.getYearOfPurchase() % 100 << endl;

   cin.ignore();   // needed for MS C++ Express 2010 programs      
  
  return 0;
}            


