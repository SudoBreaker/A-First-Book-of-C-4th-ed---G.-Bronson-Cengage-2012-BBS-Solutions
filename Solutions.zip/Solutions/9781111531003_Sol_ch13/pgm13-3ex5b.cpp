// File: pgm13-3ex5b.cpp
// Description: 13.3 Exercise 5b
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <deque>
#include <string>
#include <cctype>
using namespace std;

int main() 
{
	const int MAXNUMS = 100;

	int num, count = 0;
    deque<int> stack1, stack2, stack3;

    cout << "Enter up to " << MAXNUMS << " integers, one per line" << endl;
	cout << " To stop, enter 999" << endl;
	while(count <= MAXNUMS)
    {
	  cout << "Enter an integer (or 999 to stop): " ;
	  cin >> num;
      if (num == 999) break; 
      stack1.push_front(num);
	  count++;
    }

   // pop nums from the stack to the new stack
	cout << "\nThe numbers in stack1 are: " << endl;
    while(!stack1.empty())
    {
      num = stack1.front();  // retrieve the num
	  stack2.push_front(num);
	  stack1.pop_front();  // pop num from the stack
	  cout << num << "  ";
    }

	// pop nums from second stack to third
	while(!stack2.empty())
    {
      num = stack2.front();  // retrieve the num
	  stack3.push_front(num);
	  stack2.pop_front();  // pop num from the stack
    }

	// from thrid back to one
	while(!stack3.empty())
    {
      num = stack3.front();  // retrieve the num
	  stack1.push_front(num);
	  stack3.pop_front();  // pop num from the stack
    }

	cout << "\n\nAfter the reverse, the numbers in stack1 are: " << endl;
    while(!stack1.empty())
    {
      num = stack1.front();  // retrieve the num
	  stack1.pop_front();  // pop num from the stack
	  cout << num << "  ";
    }

	cin.ignore();   // needed for MS C++ Express 2010 programs    
  
	return 0;
}


