// File: pgm16-1ex6b.cpp
// Description: 16.1 Exercise 6b
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

class Time
{
  friend istream& operator>>(istream&, Time&);

  // data declaration section
  private:
    int hours;
    int minutes;
    int seconds;

   // method declarations
   public:
     Time(int = 7, int = 4, int = 30); // constructor with default arguments
     void showTime(); // accessor
};

// methods implementation section
Time::Time(int hh, int mm, int ss)
{
  hours = hh;
  minutes = mm;
  seconds = ss;
}

void Time::showTime()
{
  cout << setfill('0')
	  << setw(2) << hours << ':'
	  << setw(2) << minutes << ':'
       << setw(2) << seconds << endl;
}

// overloaded extraction operator function
istream& operator>>(istream& in, Time& sometime)
{
  in >> sometime.hours;  
  in.ignore(1);         
  in >> sometime.minutes;   
  in.ignore(1);          
  in >> sometime.seconds;    
  in.ignore(1);

  return in;
}

int main()
{
  Time someTime;

  cout << "Enter the current hours:minutes:seconds ";
  cin >> someTime;

  cout << "The Time entered is: ";
  someTime.showTime();

  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs    
  
  return 0;
}            


