// File: pgm13-3ex3.cpp
// Description: 13.3 Exercise 3
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <deque>
#include <string>
#include <cctype>
using namespace std;

int main() 
{
	int num;
    deque<int> stack;

    cout << "Enter as many integers as you wish, one per line" << endl;
	cout << " To stop, enter 999" << endl;
	while(true)
    {
	  cout << "Enter an integer (or 999 to stop): " ;
	  cin >> num;
      if (num == 999) break; 
      stack.push_front(num);
    }

    cout << "\nThe numbers in the stack are:\n"; 
     // pop nums from the stack
    while(!stack.empty())
    {
      num = stack.front();  // retrieve the num
	  stack.pop_front();  // pop num from the stack
      cout << num << endl;
    }

	cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs     
  
	return 0;
}


