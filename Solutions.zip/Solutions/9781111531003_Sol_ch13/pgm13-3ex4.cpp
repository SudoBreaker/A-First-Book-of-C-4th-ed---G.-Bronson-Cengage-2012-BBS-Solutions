// File: pgm13-3ex4.cpp
// Description: 13.3 Exercise 4
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <deque>
#include <string>
#include <cctype>
using namespace std;

int main() 
{
	int num, carry = 0, sum = 0;
    deque<int> digits1, digits2, digits3;

    digits1.push_front(9);
	digits1.push_front(8);
	digits1.push_front(5);
	digits1.push_front(2);

	digits2.push_front(3);
	digits2.push_front(1);
	digits2.push_front(5);
	digits2.push_front(7);

	while(!digits1.empty() && !digits2.empty())
	{
		sum = digits1.front() + digits2.front() + carry;

		if(sum < 10)
		{
			digits3.push_front(sum);
			carry = 0;
		}
		else
		{
			digits3.push_front(sum%10);
			carry = 1;
		}
		sum = 0;
		digits1.pop_front();
		digits2.pop_front();
	}


    cout << "\nThe numbers in the digits3 stack are:\n"; 
    while(!digits3.empty())
    {
      num = digits3.front();
	  digits3.pop_front();  
      cout << num << endl;
    }

	cin.ignore();   // needed for MS C++ Express 2010 programs	    
  
	return 0;
}


