// File: pgm13-2ex1.cpp
// Description: 13.2 Exercise 1
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs
#include <iostream>
#include <list>
#include <algorithm>
#include <string>
using namespace std;

int main()
{
  list<string> names, addnames;
  string n;

  // add names to the original list 
  names.push_front("Dolan, Edith");
  names.push_back("Lanfrank, John");
   
  // create a new list
  addnames.push_front("Acme, Sam");
  addnames.push_front("Zemann, Frank");

  names.sort();
  addnames.sort();

  // merge the second list into the first
  names.merge(addnames);
  cout << "The first list size is: " <<  names.size() << endl;
  cout << "This list contains the names:\n";

  while (!names.empty())
  {
    cout << names.front() << endl;
    names.pop_front();  // remove the object
  }
   
  cin.ignore();   // needed for MS C++ Express 2010 programs
	  
  return 0;
}

