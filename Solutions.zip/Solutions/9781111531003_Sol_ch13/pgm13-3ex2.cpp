// File: pgm13-3ex2.cpp
// Description: 13.3 Exercise 2
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <deque>
#include <string>
#include <cctype>
using namespace std;

int main()
{
  string name;
  deque<string> stack;

  cout << "Enter as many names as you want, one per line" << endl;
  cout << "To stop enter a single x" << endl;
  while(true)
  {
    cout << "Enter a name (or x to stop): " ;
    getline(cin, name);
    if (tolower(name.at(0)) == 'x') break;
    stack.push_front(name);
  }

    cout << "\nThe names in the stack are:\n";
 
    // pop names from the stack
    while(!stack.empty())
    {
      name = stack.front();  // retrieve the name
      stack.pop_front();  // pop name from the stack
      cout << name << endl;
    }

    cin.ignore();   // needed for MS C++ Express 2010 programs
		
	return 0;
  }   

