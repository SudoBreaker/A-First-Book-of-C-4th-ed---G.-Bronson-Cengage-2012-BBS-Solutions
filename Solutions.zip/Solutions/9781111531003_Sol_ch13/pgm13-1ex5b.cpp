// File: pgm13-1ex5b.cpp
// Description: 13.1 Exercise 5b
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

class Student
{
  private:
     string firstName;
     string lastName;
     int birthMonth;
     int birthDay;
     int birthYear;
     int creditsCompleted;
     double gpa; 

   public:
     Student(string f, string l, int month, int day, int year, int cred, double g)
     {
	firstName = f;
	lastName = l;
	birthMonth = month;
	birthDay = day;
	birthYear = year;	
    creditsCompleted = cred;
	gpa = g;
     }
     string getFirstName() { return firstName; }
     string getLastName() { return lastName; }
     int getBirthMonth() { return birthMonth; }
     int getBirthDay() { return birthDay; }
     int getBirthYear() { return birthYear; }
     int getCreditsCompleted() { return creditsCompleted; }
     double getGPA() { return gpa; }
};

int main()
{
  Student someStudent("Rhona", "Karp", 8, 4, 1960, 96, 3.89);

  cout << "Name: " << someStudent.getFirstName() << " "
	   << someStudent.getLastName() << endl;
  cout << "Date of Birth: " << someStudent.getBirthMonth() << "/" 
	   << someStudent.getBirthDay() << "/" 
	   << someStudent.getBirthYear() % 100 << endl;
  cout << "Number of Credits Completed: " 
	   << someStudent.getCreditsCompleted() << endl;
  cout << "Grade Point Average: "
	   << someStudent.getGPA() << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs     
  
  return 0;
}            


