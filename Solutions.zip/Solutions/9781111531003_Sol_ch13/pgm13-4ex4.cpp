// File: pgm13-4ex4.cpp
// Description: 13.4 Exercise 4
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <deque>
#include <cctype>
using namespace std;

void newbubbl(char ch[], int chElements)
{
	int i;
	char temp;
	int outord = 1;

	while (outord && (chElements > 0))
	{
		outord = 0;

		for (i = 0; i < (chElements - 1); i++)
		{
			if (ch[i] > ch[i+1])
			{
				temp = ch[i+1];
				ch[i+1] = ch[i];
				ch[i] = temp;
				outord = 1;
			}
		}
		chElements--;
	}

	return;
}

int main() 
{
	const int MAXCHARS = 20;
    int i = 0;
	char chararray[MAXCHARS], ch;
    deque<double> queue;

    cout << "Enter up to " << MAXCHARS << " characters, "
		 << "one per line" << endl;
    cout << " To stop enter !" << endl;
    
    // push names on the queue
    while(i <= MAXCHARS)
    {
	  cout << "Enter a character (or ! to stop): " ;
	  cin >> ch;
      if (ch == '!') break; 
	  chararray[i] = ch;
	  i++;
      queue.push_front(ch);
    }

    cout << "\nThe characters in the queue are:\n"; 
    while(!queue.empty())
    {
      ch = queue.back();  // retrieve the name
      queue.pop_back();  // pop name from the queue
      cout << ch << "  ";
    }

	newbubbl(chararray, i);

	i = 0;
	while(chararray[i])
	{
		queue.push_front(chararray[i]);
		i++;
	}

	cout << "\n\nThe characters in the queue after sorting are: " << endl; 
    while(!queue.empty())
    {
      ch = queue.back();  
      queue.pop_back();  
      cout << ch << "  ";
    }

	cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs    
  
	return 0;
}


