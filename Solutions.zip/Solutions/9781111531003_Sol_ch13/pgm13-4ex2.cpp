// File: pgm13-4ex2.cpp
// Description: 13.4 Exercise 2
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <deque>
#include <string>
#include <cctype>
using namespace std;

int main()
{
  string name;
  deque<string> queue;

  cout << "Enter as many names as you want, one per line" << endl;
  cout << " To stop enter a single x" << endl;
   
  // push names on the queue
  while(true)
  {
     cout << "Enter a name (or x to stop): " ;
     getline(cin, name);
     if (tolower(name.at(0)) == 'x') break;
     queue.push_front(name);
  }

  cout << "\nThe names in the queue are:\n";

  // pop names from the queue
  while(!queue.empty())
  {
    name = queue.back();  // retrieve the name
    queue.pop_back();  // pop a name from the queue
    cout << name << endl;
  }

  cin.ignore();   // needed for MS C++ Express 2010 programs
	  
  return 0;
}

