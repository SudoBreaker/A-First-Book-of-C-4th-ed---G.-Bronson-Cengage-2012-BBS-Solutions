// File: pgm13-4ex6.cpp
// Description: 13.4 Exercise 6
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <deque>
#include <string>
#include <cctype>
using namespace std;

int main() 
{
    string name, found;
    deque<string> queue;
	int choice, size, i;
    
	do{
		cout << "\n\nEnter a choice: " << endl;
		cout << "  1. Add a name " << endl;
		cout << "  2. Remove a name " << endl;
		cout << "  3. List the contents " << endl;
		cout << "  4. Quit " << endl;
		cin >> choice;
		cin.ignore();  // remove the Enter key

		switch(choice)
		{
			case 1:
				cout << "Enter a name to add: " ;
				getline(cin, name);
				queue.push_front(name);
				break;
			case 2:
				cout << "Enter a name to remove: ";
				getline(cin, name);
				//remove it
				size = queue.size();
				for(i = 0; i < size; i++)
				{
				found = queue.back();  // retrieve the name
				queue.pop_back();  // pop name from the queue
				if(name != found)
					queue.push_front(found);  // but put it right back
				//else it is removed and not put back
				}
				break;
			case 3:
				size = queue.size();
				cout << "\n\nThe names in the queue are:\n"; 
				for(i = 0; i < size; i++)
				{
				name = queue.back();  // retrieve the name
				queue.pop_back();  // pop name from the queue
				queue.push_front(name);  // but put it right back
				cout << name << endl;
				}
			case 4:
				break;
		} 

	} while(choice != 4);

	cin.ignore();   // needed for MS C++ Express 2010 programs

	return 0;
}


