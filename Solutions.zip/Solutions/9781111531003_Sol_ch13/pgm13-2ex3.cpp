// File: pgm13-2ex3.cpp
// Description: 13.2 Exercise 3
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <list>
#include <string>
using namespace std;

class NameTele
{
  // data declaration section
  private:
     string name;
     string phoneNum;

  // methods declaration and implementation section
  public: 
    NameTele(string nn, string phone)  // constructor
    {
      name = nn;
      phoneNum = phone;
    } 
    string getName(){return name;}
    string getPhone(){return phoneNum;}
};

 int main() 
  {
    list<NameTele> employee; 
	string name, strng;
	int found = 0;

    // create three objects
    employee.push_front(NameTele("Acme, Sam", "(555) 898-2392"));	 
    employee.push_back(NameTele("Dolan, Edith", "(555) 682-3104"));	 
    employee.push_back(NameTele("Mening, Stephan", "(555) 382-7070"));	 
	employee.push_back(NameTele("Zeman, Harold", "(555) 219-9912"));	
 
    cout << "\nEnter a name (last, first): ";
	getline(cin, name);


	while(!employee.empty() && !found)
	{
		if(employee.front().getName() == name)
		{
			cout << "\nFound. The number is "
					<< employee.front().getPhone() << endl;
			found = 1;
		}
		else
			employee.pop_front();
	}

	if(!found)
		cout << "\nThe name is not in the current phone list" << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs   
  
	return 0;
}


