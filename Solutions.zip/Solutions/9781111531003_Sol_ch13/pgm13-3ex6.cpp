// File: pgm13-3ex6.cpp
// Description: 13.3 Exercise 6
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <deque>
#include <string>
#include <cctype>
using namespace std;


void newbubbl(char num[], int numElements)
{
	int i;
	char temp;
	int outord = 1;

	while (outord && (numElements > 0))
	{
		outord = 0;

		for (i = 0; i < (numElements - 1); i++)
		{
			if (num[i] > num[i+1])
			{
				temp = num[i+1];
				num[i+1] = num[i];
				num[i] = temp;
				outord = 1;
			}
		}
		
		numElements--;
	}

	return;
}



int main() 
{
	const int MAXCHARS = 50;

	char ch, front, back, charray[MAXCHARS];
	int count = 0, outord = 1, i = 0;
    deque<char> stack, stack2, stack3;

    cout << "Enter up to " << MAXCHARS << " characters, one per line" << endl;
	cout << " To stop, enter *" << endl;
	while(count <= MAXCHARS)
    {
	  cout << "Enter a character (or * to stop): " ;
	  cin >> ch;
	  if (ch == '*') break; 
      stack.push_front(ch);
	  count++;
    }

	cout << "\nThe characters in the stack are: " << endl;
    while(!stack.empty())
    {
      ch = stack.front();  // retrieve the num
	  stack.pop_front();   // pop num from the stack
	  charray[i] = ch;     // load elements into an array
	  i++;
	  cout << ch << "  ";
    }
	charray[i] = '\0';

	newbubbl(charray, i);  // sort the array

	i = 0;
	while(charray[i])
	{
		stack.push_back(charray[i]);
		i++;
	}

	cout << "\nThe characters in the stack after sort are: " << endl;
    while(!stack.empty())
    {
      ch = stack.front();  // retrieve the num
	  stack.pop_front();  // pop num from the stack
	  cout << ch << "  ";
    }

	cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs   
  
	return 0;
}


