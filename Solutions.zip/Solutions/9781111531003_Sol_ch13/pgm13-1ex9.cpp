// File: pgm13-1ex9.cpp
// Description: 13.1 Exercise 9
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class Stock
{
  friend istream& operator>>(istream&, Stock&);

  // data declaration section
  private:
    string name;
	double earnings;
	double ratio;

   // method declarations
   public:
     Stock(string n = "XXX", double = 0.0, double = 0.0); 
     void showStock(); // accessor
	 double getPrice();
};

// methods implementation section
Stock::Stock(string n, double e, double r)
{
  name = n;
  earnings = e;
  ratio = r;
}

void Stock::showStock()
{
   cout << name << ": " << earnings << ", " << ratio << endl;
   return;
}

double Stock::getPrice()
{
   return earnings * ratio;
}

// overloaded extraction operator function
istream& operator>>(istream& in, Stock& somestock)
{
  in >> somestock.name;   
  in >> somestock.earnings;     
  in >> somestock.ratio;    
   
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return in;
}

int main()
{
  Stock someStock;
  double price;
  int i;

  for(i = 0; i < 5; i ++)
  {
	cout << endl;
	cout << "Enter the stock name, earnings, and ratio: ";
	cin >> someStock;

	cout << "The Stock entered is: ";
	someStock.showStock();

	cout << fixed << setprecision(2);
	price =  someStock.getPrice();
	cout << "The anticipated price is: $" << price << endl;
  }
 
  cin.ignore(); cin.ignore()  //  needed for MS C++ Express 2010 programs
       
  
  return 0;
}            


