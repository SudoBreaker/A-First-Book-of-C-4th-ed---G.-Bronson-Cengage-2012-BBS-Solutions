// File: pgm13-1ex6a.cpp
// Description: 13.1 Exercise 6a
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

class Date
{
  friend istream& operator>>(istream&, Date&);

  // data declaration section
  private:
    int month;
    int day;
    int year;

   // method declarations
   public:
     Date(int = 7, int = 4, int = 2007); // constructor with default arguments
     void showDate(); // accessor
};

// methods implementation section
Date::Date(int mm, int dd, int yyyy)
{
  month = mm;
  day = dd;
  year = yyyy;
}

void Date::showDate()
{
  cout << setfill('0')
	 << setw(2) << month << '/'
       << setw(2) << day << '/'
       << setw(2) << year % 100 << endl;
}

// overloaded extraction operator function
istream& operator>>(istream& in, Date& somedate)
{
  in >> somedate.month;   // accept the month part
  in.ignore(1);           // ignore 1 character, the /
  in >> somedate.day;     // get the day part
  in.ignore(1);           // ignore 1 character, the /
  in >> somedate.year;    // get the year part
  in.ignore(1);

  return in;
}

int main()
{
  Date someDate;

  cout << "Enter the current month/day/year: ";
  cin >> someDate;

  cout << "The Date entered is: ";
  someDate.showDate();

  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs    
  
  return 0;
}            


