// File: pgm13-1ex5a.cpp
// Description: 13.1 Exercise 5a
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

class Student
{
   private:
     int idNumber;
     int creditsCompleted;
     double gpa;

   public:
     Student(int num, int cred, double g)
     {
	    idNumber = num;	
        creditsCompleted = cred;
	    gpa = g;
     }
     int getIdNumber() { return idNumber; }
     int getCreditsCompleted() { return creditsCompleted; }
     double getGPA() { return gpa; }
};

int main()
{
  Student someStudent(4672, 68, 3.01);

  cout << "Identification number: " << someStudent.getIdNumber() << endl;
  cout << "Number of Credits Completed: "
	   << someStudent.getCreditsCompleted() << endl;
  cout << "Grade Point Average: "
	   << someStudent.getGPA() << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs     
  
  return 0;
}            


