// File: pgm13-4ex7.cpp
// Description: 13.4 Exercise 7
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <deque>
#include <string>
#include <fstream>
#include <cstdlib>   // needed for exit()
#include <cctype>
using namespace std;

int main() 
{
    string name;
    deque<string> queue;
	ifstream inFile;

	inFile.open("order.txt");
	if (inFile.fail())  // check for a successful open
	{
		cout << "\nThe file was not successfully opened"
	    << "\n Please check that the file currently exists." 
         << endl;
		exit(1);
	}

	// read and display the file's contents
	inFile >> name;
	while (inFile.good()) // check next character
	{
		queue.push_front(name);
		inFile >> name;
	}

    cout << "\nThe passengers will board the bus in this order:\n"; 

    // pop names from the queue
    while(!queue.empty())
    {
      name = queue.back();  // retrieve the name
      queue.pop_back();  // pop name from the queue
      cout << name << endl;
    }

	inFile.close();

	cin.ignore();   // needed for MS C++ Express 2010 programs

	return 0;

}


