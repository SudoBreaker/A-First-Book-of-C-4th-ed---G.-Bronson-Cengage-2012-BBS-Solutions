// File: pgm13-1ex5e.cpp
// Description: 13.1 Exercise 5e
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

class Inventory
{
  private:
     int partNumber;
     string description;
     int numberOfParts;
     int reorderValue;

   public:
     Inventory(int num, string desc, int parts, int value)
     {
	   partNumber = num;
	   description = desc;
	   numberOfParts = parts;
	   reorderValue = value;
     }
     int getPartNumber() { return partNumber; }
     string getDescription() { return description; }
     int getNumberOfParts() { return numberOfParts; }
     int getReorderValue() { return reorderValue; }
};


int main()
{
  Inventory someInventory(16879, "Battery", 10, 3);

  cout << "Part Number: " << someInventory.getPartNumber() << endl;
  cout << "Description: " << someInventory.getDescription() << endl;
  cout << "Number in Stock: " << someInventory.getNumberOfParts() << endl;
  cout << "Reorder Number: " << someInventory.getReorderValue() << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs    
  
  return 0;
}            


