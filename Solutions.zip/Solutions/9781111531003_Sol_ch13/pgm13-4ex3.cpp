// File: pgm13-4ex3.cpp
// Description: 13.4 Exercise 3
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <deque>
#include <cctype>
using namespace std;

int main() 
{
    int num;
    deque<int> queue;

    cout << "Enter as many integers as you wish, one per line" << endl;
    cout << " To stop enter 999" << endl;
    
    // push names on the queue
    while(true)
    {
	  cout << "Enter an integer (or 999 to stop): " ;
	  cin >> num;
      if (num == 999) break; 
      queue.push_front(num);
    }

    cout << "\nThe numbers in the queue are:\n"; 

    // pop names from the queue
    while(!queue.empty())
    {
      num = queue.back();  // retrieve the name
      queue.pop_back();  // pop name from the queue
      cout << num << "  ";
    }

	cin.ignore();   // needed for MS C++ Express 2010 programs     
  
	return 0;
}


