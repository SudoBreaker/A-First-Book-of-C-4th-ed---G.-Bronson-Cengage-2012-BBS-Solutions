// File: pgm13-2ex4.cpp
// Description: 13.2 Exercise 4
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <list>
using namespace std;

int main()
{
  int intValue;
  double sum = 0.0;
  double average;

  // create an array of integer values
  int nums[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};   

   // instantiate a list of ints using a
   // constructor that initializes the list with values from the array
   list<int> x(nums, nums + 10);
    
   cout <<"\nThe list x initially has a size of " << x.size() 
		<< "," << "\n  and contains the elements: " ;
     
   while (!x.empty())
   {
     cout << x.front() << "  ";
     x.pop_front();
   }  			
   cout << endl;

   cin.ignore();   // needed for MS C++ Express 2010 programs

   return 0;
}


