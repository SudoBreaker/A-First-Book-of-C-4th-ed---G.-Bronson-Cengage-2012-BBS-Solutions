// File: pgm13-2ex2.cpp
// Description: 13.2 Exercise 2
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <list>
#include <string>
using namespace std;

class NameTele
{
  // data declarations section
  private:
    string name;
    string phoneNum;
    
  // methods declarations and implementations section
  public:

    NameTele(string nn, string phone)  // constructor
    {
      name = nn;
      phoneNum = phone;
    }

    string getName(){return name;}      // inline method definition
    string getPhone(){return phoneNum;} // inline method definition
  };

  int main()
  {      
    list<NameTele> employee;  // instantiate a list and initialize the 
     				          // list using the objects in the array

    employee.push_front(NameTele("Acme, Sam", "(555) 891-2392")); 
    employee.push_back(NameTele("Dolan, Edith", "(555) 682-3104"));
    employee.push_back(NameTele("Mening, Stephen", "(555) 382-7070"));
    employee.push_back(NameTele("Zemann, Harold", "(555) 219-9913")); 
	   
    // retrieve all list objects
    // use accessor methods to extract the name and pay rate
    cout <<"The size of the list is " << employee.size() << endl;
    cout <<"\n     Name              Telephone";
    cout <<"\n--------------       --------------\n";

    while (!employee.empty())
    {
      cout << employee.front().getName()
           << "\t     " << employee.front().getPhone() << endl;
      employee.pop_front();  // remove the object
   }

   cin.ignore();   // needed for MS C++ Express 2010 programs
	   
   return 0;
 }

