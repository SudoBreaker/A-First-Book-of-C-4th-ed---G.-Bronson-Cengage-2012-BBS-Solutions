// File: pgm13-2ex5.cpp
// Description: 13.2 Exercise 5
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

class NameTele
{
  // data declaration section
  private:
     string name;
     string phoneNum;
     NameTele *link;

  // methods declaration and implementation section
  public:
    NameTele(string nn, string phone)  // constructor
    {
      name = nn;
      phoneNum = phone;
      link = NULL;
    }
    string getName(){return name;}    // inline method definitions
    string getPhone(){return phoneNum;}
    NameTele *getLink(){return link;}
    void setLink(NameTele *ll){link = ll;}
};

int main()
{
   NameTele head = NameTele("xx", "xx");  // create an empty object  

   // create three objects
   NameTele t1 = NameTele("Acme, Sam", "(555) 898 2392");
   NameTele t2 = NameTele("Dolan, Edith", "(555) 682 3104");
   NameTele t3 = NameTele("Lanfrank, John", "(555) 718 4581");

   // link all of the objects
   head.setLink(&t1);  // have the head link point to the first object;
   t1.setLink(&t2);
   t2.setLink(&t3);
 
   // retrieve each object using the link from the prior object
   cout << head.getLink()->getName() << endl
        << t1.getLink()->getName() << endl
        << t2.getLink()->getName() << endl;   

   cin.ignore();   // needed for MS C++ Express 2010 programs
	   
   return 0;
 }
