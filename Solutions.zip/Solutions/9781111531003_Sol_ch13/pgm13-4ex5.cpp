// File: pgm13-4ex5.cpp
// Description: 13.4 Exercise 5
// Programmer: G. Bronson
// Date: 9/19/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <deque>
#include <cctype>
using namespace std;

class Employee
{
  // data declaration section
  private:
     int idNumber;
	 double payRate;
     
  // methods declaration and implementation section
  public: 
    Employee(int id, double rate)  // constructor
    {
      idNumber = id;
	  payRate = rate;
    } 
    int getIdNumber(){return idNumber;}
    double getPayRate(){return payRate;}
  };

  int main()
  {
                           
    deque<Employee> someEmployees;
    
    someEmployees.push_front( Employee(123, 34.54));  
    someEmployees.push_front( Employee(234, 12.42));        
    someEmployees.push_front( Employee(345, 15.67)); 
    someEmployees.push_front( Employee(567, 19.87));  
	    
    // retrieve all queue objects 
    // use accessor methods to extract the id and pay rate
	cout <<"The size of the queue is " << someEmployees.size() << endl;               
    cout <<"\nID Num       Pay Rate";
    cout <<"\n-------      --------\n";

    while (!someEmployees.empty())
    {
      cout << someEmployees.back().getIdNumber() 
	     << "\t     $" << someEmployees.back().getPayRate() << endl;
      someEmployees.pop_back();  // remove the object
   }

	cin.ignore();   // needed for MS C++ Express 2010 programs    
  
	return 0;
}


