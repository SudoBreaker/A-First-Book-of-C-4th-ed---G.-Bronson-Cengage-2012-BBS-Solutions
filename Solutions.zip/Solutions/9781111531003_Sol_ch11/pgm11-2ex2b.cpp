// File: pgm11-2ex2b.cpp
// Description: 11.2 Exercise 2b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Date
{
  private:
    int month;
    int day;
    int year;
  public:
    Date(int = 7, int = 4, int = 2012);    // constructor
    Date operator=(const Date &);  // assignment operator prototype
    void showDate();        // member method to display a date
};

// class implementation section

Date::Date(int mm, int dd, int yyyyy)
{
  this->month = mm;
  this->day = dd;
  this->year = yyyyy;
}

void Date::showDate(void)
{
  cout << "The date is ";
  cout << setfill('0')
       << setw(2) << this->month << '/' 
       << setw(2) << this->day << '/' 
       << setw(2) << this->year % 100;  // extract the last 2 year digits
  cout << endl;

  return;
}

//The new assignment operator returns an object of type Date 
Date Date::operator=(const Date& newdate)
{
  this->day = newdate.day;        // assign the day
  this->month = newdate.month;    // assign the month
  this->year = newdate.year;      // assign the year

  return *this;
}

int main()
{
  Date a(4,1,1999), b(14,18,2012), c(1,1,2014); // declare three objects
             
  cout << "Before assignment a's date value is ";
  a.showDate();
  cout << "\nBefore assignment b's date value is ";
  b.showDate();
  cout << "\nBefore assignment c's date value is ";
  c.showDate();

  a = b = c;    // multiple assignment

  cout << "\n\nAfter assignment a's date value is ";
  a.showDate();
  cout << "\nAfter assignment b's date value is ";
  b.showDate();
  cout << "\nAfter assignment c's date value is ";
  c.showDate();
  cout << endl;
 
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}