// File: pgm11-2ex6b.cpp
// Description: 11.2 Exercise 6b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Date
{
  private:
    int month;
    int day;
    int year;
  public:
    Date(int = 7, int = 4, int = 2012);     // constructor
    void showDate();      // method to display a date
    void swap(Date *);    // method to swap two dates
	void addSixMonths(Date *); //method to add six months

};

// class implementation section
Date::Date(int mm, int dd, int yyyy)
{
  month = mm;
  day = dd;
  year = yyyy;
}

void Date::showDate()
{
  cout << setfill('0')
       << setw(2) << month << '/'
       << setw(2) << day << '/'
       << setw(2) << year % 100;
  return;
}

void Date::swap(Date *temp) // method to swap two dates 
{
  int tempstore;

  // swap the day member
  tempstore = temp->day;
  temp->day = day;
  day = tempstore;

  // swap the month member
  tempstore = temp->month;
  temp->month = month;
  month = tempstore;

  // swap the year member
  tempstore = temp->year;
  temp->year = year;
  year = tempstore;

  return;
}

void Date::addSixMonths(Date *pt) //method to add six months
{ 
  pt->month = pt->month + 6;  // add 6 months to the date
 
  //adjust the "pointed to" date's month and year
  if(pt->month > 12) // adjust the month and year
  {
    pt->month = pt->month - 12;
    pt->year++;  //add 1 to the year
  }
  
  day = pt->day;
  month=pt->month;
  year = pt->year;

  return;
}     

int main()
{
  Date oldDate(4,3,2011);
  Date newDate;
  
  cout << "\nThe date stored in oldDate is ";
  oldDate.showDate();
  cout << endl;

  newDate.addSixMonths(&oldDate); // add six months
  cout << "\nThe date stored in newDate six months later is ";
  newDate.showDate();
  cout << endl;

  newDate.addSixMonths(&oldDate);  // add another six months
  cout << "\nThe date stored in newDate six months later is ";
  newDate.showDate();  
  cout << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
