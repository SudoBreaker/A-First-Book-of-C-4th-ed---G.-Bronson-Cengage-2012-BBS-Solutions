// File: pgm11-1ex8b.cpp
// Description: 11.1 Exercise 8b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include<iostream>
#include<string>
using namespace std;

// class declaration section
class String
{
private:
	char *S;
public:
	String(char * = "\0");
	void display();
	String& operator + (const String &);
};

// class implementation section
String::String(char * s1)
{
	S = new char[strlen(s1)+1];
	strcpy(S,s1);
}
void String::display()
{
	cout<<endl<<S<<endl;
	return;
}
String& String:: operator+(const String &s1)
{
	String temp;
	if(s1.S != NULL)
	{
		temp.S = new char [strlen(S) + strlen(s1.S) + 1];
		strcpy(temp.S,S);
		strcat(temp.S,s1.S);
	}
	return temp;
}

int main()
{
	String s1 = "Gooby ", s2 = "Keenan", s3;
	cout<<"The strings are: ";
	s1.display ();
	s2.display ();
	s3.display ();
	s3 = s1 + s2;
	cout<<"\nAfter concatenation the strings are: ";
	s1.display ();
	s2.display ();
	s3.display ();

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}