// File: pgm11-1ex3.cpp
// Description: 11.3 Exercise 3
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <iomanip>
using namespace std;

// class declaration section
class Date
{
  private:
    int month, day, year;

  public:
    Date(int = 7, int = 4, int = 2012);    // constructor
    operator long();        // conversion operator function
    void showDate();
};

// class implementation section

// constructor
Date::Date(int mm, int dd, int yyyy)
{
  month = mm;
  day = dd;
  year = yyyy;
}

// conversion operator function converting from Date to long
Date::operator long()   // must return a long
{
  int mp, yp, t;
  long julian;

  if(month <= 2)
  { 
	  mp = 0;
	  yp = year -1;
  }
  else
  {
	  mp = int(0.4 * month + 2.3);
	  yp = year;
  }

  t = int(yp/4) - int(yp/100) + int(yp/400);
  julian = 365L * year + 31L * (month-1) + day + t - mp;

  return julian;
}

void Date::showDate()
{
  cout << setfill('0')
       << setw(2) << month << '/'
       << setw(2) << day << '/'
       << setw(2) << year % 100 << endl;
}

int main()
{
  Date a(1,31,2011), c(3,16,2012);  
  long b, d;          

  b = a; 
  d = c;			// a conversion takes place here

  cout << "a's date is ";
  a.showDate();
  cout << "This date, as a Julian date, is " << b << endl;

  cout << endl;

  cout << "c's date is ";
  c.showDate();
  cout << "This date, as a Julian date, is " << d << endl; 

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

