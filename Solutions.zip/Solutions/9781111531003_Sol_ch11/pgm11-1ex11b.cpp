// File: pgm11-1ex11b.cpp
// Description: 11.1 Exercise 11b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
#include <math.h>
using namespace std;

// class declaration section
class Fractions
{ 
  private:
    int num;
	int denom;
  public:
    Fractions(int = 1, int = 1); // constructor
    void input(int, int);  // input data member values
    void showdata(); // display data member values
	Fractions operator+(Fractions &);  
	Fractions operator-(Fractions &);
	Fractions operator*(Fractions &);
	Fractions operator/(Fractions &);
};

// class implementation section
Fractions::Fractions(int n, int d)
{
  num = n;
  denom = d;
}

void Fractions::input(int newn, int newd)
{
  num = newn;
  denom = newd;
  return;
}

void Fractions::showdata()
{
  cout << num << "/" << denom << endl;
  return;
}

Fractions Fractions::operator+(Fractions &f2)
{
	Fractions newf;

	newf.num = (num * f2.denom) + (f2.num * denom);
	newf.denom = denom * f2.denom;

	return newf;
}

Fractions Fractions::operator-(Fractions &f2)
{
	Fractions newf;

	newf.num = (num * f2.denom) - (f2.num * denom);
	newf.denom = denom * f2.denom;

	return newf;
}

Fractions Fractions::operator*(Fractions &f2)
{
	Fractions newf;

	newf.num = num * f2.num;
	newf.denom = denom * f2.denom;

	return newf;
}

Fractions Fractions::operator/(Fractions &f2)
{
	Fractions newf;

	newf.num = num * f2.denom;
	newf.denom = denom * f2.num;

	return newf;
}

int main()
{
  Fractions a(1,2), b(2,3), c, d, e, f;

  cout << "Fraction a is: ";
  a.showdata();
  cout << endl;

  cout << "Fraction b is: ";
  b.showdata();
  cout << endl;

  c = a + b;
  d = a - b;
  e = a * b;
  f = a/b;

  cout << "a + b = ";
  c.showdata();
  cout << endl;

  cout << "a - b = ";
  d.showdata();
  cout << endl;

  cout << "a * b = ";
  e.showdata();
  cout << endl;

  cout << "a / b = ";
  f.showdata();
  cout << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

