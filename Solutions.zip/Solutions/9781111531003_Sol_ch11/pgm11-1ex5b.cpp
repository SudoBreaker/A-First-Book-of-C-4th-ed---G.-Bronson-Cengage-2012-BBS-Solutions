// File: pgm11-1ex5b.cpp
// Description: 11.1 Exercise 5b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Time
{
  private:
    int hrs;
    int mins;
    int secs;
  public:
    Time(int = 0, int = 0, int = 0);  // default constructor
    void operator=(Time& );    // overloaded assignment operator
    void showdata(void);       // member function to display a time
};

// class implementation section
Time::Time(int hh, int mm, int ss)
{
  hrs = hh;
  mins = mm;
  secs = ss;
}
void Time::operator=(Time& newtime)
{
  hrs = newtime.hrs;
  mins = newtime.mins;
  secs = newtime.secs;
  return;
}
void Time::showdata(void)
{
  cout << "The time is "
       << setw(2) << setfill('0') << hrs << ':'
       << setw(2) << setfill('0') << mins << ':'
       << setw(2) << setfill('0') << secs << endl;
  return;
}

int main()
{
  Time a(8,20,10), b;  // declare 2 objects

  a.showdata();   // display object a's values
  b.showdata();   // display object b's values
  b = a;          // assign a to b
  b.showdata();   // display object b's values

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

