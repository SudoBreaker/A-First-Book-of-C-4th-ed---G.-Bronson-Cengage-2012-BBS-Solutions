// File: pgm11-1ex4.cpp
// Description: 11.3 Exercise 4
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <iomanip>
using namespace std;

// class declaration section
class Time
{
 
  private:
    int hours;
	int minutes;
	int seconds;
  public:
    Time(int = 0, int = 0, int = 0);  // constructor
    Time(long);           // type conversion constructor
	operator long();      // conversion operator function
    void showtime(void);
};

// class implementaton section
Time::Time(int hr, int min, int sec)  // constructor
{
  hours = hr;
  minutes = min;
  seconds = sec;
}
// type conversion constructor from long to Time
Time::Time(long etime)
{
  hours = int(etime/3600);
  minutes = int((etime - hours * 3600)/60);
  seconds = int(etime - hours * 3600 - minutes * 60);

}

// conversion operator function converting from Time to long
Time::operator long()  //must return a long
{
  return (hours * 3600L + minutes * 60 + seconds);
}

// member function to display a Time
void Time::showtime(void)
{
  cout << setiosflags(ios::showpoint) << setfill('0')
       << setw(2) << hours << ':'
       << setw(2) << minutes << ':'
       << setw(2) << seconds << endl;
  return;
}

int main()
{
  Time a(30336L), b;  // initialize object with a long int
  long c, d;

  cout << "Time a is : ";
  a.showtime();

  b = Time(52200L);  // cast a long to a Time
  cout << "Time b is : ";
  b.showtime();
  cout << endl;
 
  // now cast both Times back to longs
  c = long(a);
  d = long(b);
  cout << "The two times, as longs, are: "
       << c << " and " << d << endl;   

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

