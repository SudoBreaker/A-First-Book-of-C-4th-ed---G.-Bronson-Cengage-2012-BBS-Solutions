// File: pgm11-1ex6.cpp
// Description: 11.3 Exercise 6
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <iomanip>
using namespace std;

// forward declaration of class Ltime
class Ltime;

// class declaration section for class Time
class Time
{ 
  private:
    int hours;
	int minutes;
	int seconds;
  public:
    Time(int = 0, int = 0, int = 0);  // constructor
    void showtime(void);
	operator Ltime();
};
// class declaration section for class Ltime
class Ltime
{ 
  private:
    long elsecs;
  public:
    Ltime(long = 0);  // constructor
    void showltime(void);
	operator Time();
};



// class implementation section for class Time
Time::Time(int hr, int min, int sec) // constructor
{
  hours = hr;
  minutes = min;
  seconds = sec;
}

// member function to display a Time
void Time::showtime(void)
{
  cout << setiosflags(ios::showpoint) << setfill('0')
       << setw(2) << hours << ':'
       << setw(2) << minutes << ':'
       << setw(2) << seconds << endl;
  return;
}
Time::operator Ltime()
{
long elapsedSeconds = (hours * 3600L) + (minutes * 60) + seconds;

return Ltime(elapsedSeconds);
}


// class implementation section for class Ltime
Ltime::Ltime(long el)  // constructor
{
  elsecs = el;
}

// member function to display a Time
void Ltime::showltime()
{
  cout << elsecs << endl;

  return;
}

Ltime::operator Time()
{
long temp = elsecs;

int hrs = temp/3600;

temp = temp % 3600;

int min = temp/60;
int sec = temp % 60;

return Time(hrs, min, sec);
}

int main()
{
 
  Time a(5, 32, 33), b(6,4,23);  // initialize object with a long int
  Ltime c, d;

  c = Ltime(a);
  d = Ltime(b);

  cout << "Time a is : ";
  a.showtime();
  cout << "This time as a long int object is: ";
  c.showltime();
  cout << endl;

  cout << "Time b is : ";
  b.showtime();
  cout << "This time as a long int object is: ";
  d.showltime();
  cout << endl;      

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

