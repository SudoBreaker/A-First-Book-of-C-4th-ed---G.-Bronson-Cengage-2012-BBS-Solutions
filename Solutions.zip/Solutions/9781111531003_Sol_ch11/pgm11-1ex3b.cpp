// File: pgm11-1ex3b.cpp
// Description: 11.1 Exercise 3b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <iomanip>
using namespace std;

// class declaration section
class Date
{
  private:
    int month;
    int day;
    int year;

   public:
     Date(int = 7, int = 4, int = 2006); // constructor with default
     Date operator+(int);  // overload the + operator
     void showDate();      // accessor
     
};

// class implementation section
Date::Date(int mm, int dd, int yyyy)
{
  month = mm;
  day = dd;
  year = yyyy;
}

Date Date::operator+(int days)   // return a Date object
{
  Date temp;
 
  temp.day = day + days;   // add the days in
  temp.month = month + int(temp.day/30);  // determine total months
  temp.day = temp.day % 30;            // determine actual day
  temp.year = year + int(temp.month/12);  // determine total years
  temp.month = temp.month % 12;        // determine actual month

  return temp;
}


void Date::showDate()
{
  cout << setfill('0')
       << setw(2) << month << '/'
       << setw(2) << day << '/'
       << setw(2) << year % 100 << endl;
}

int main()
{
  Date a(4,1,1999), b; // declare two objects

  cout << "The initial date is ";
  a.showDate();
  b = a + 284;   // add in 284 days = 9 months and 14 days
  cout << "The new date is ";
  b.showDate();

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

