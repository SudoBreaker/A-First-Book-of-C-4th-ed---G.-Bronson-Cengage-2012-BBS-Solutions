// File: pgm11-3ex5.cpp
// Description: 11.3 Exercise 5
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;
 
// forward declaration of class Julian
class Julian;

// class declaration section for Date
class Date
{
  private:
    int month, day, year;
  public:
    Date(int, int, int);    // constructor
    operator Julian();     // conversion operator Date to Julian
    void showDate(void);
};
// class declaration section for Julian
class Julian
{
  private:
    long yyyymmdd;
  public:
    Julian(long = 0);    // constructor
    void showjulian(void);
};

// class implementation section for Date
Date::Date(int mm = 7, int dd = 4, int yyyy = 2012)  // constructor
{
  month = mm;
  day = dd;
  year = yyyy;
}
// conversion operator function converting from Date to IntDate class
Date::operator Julian()   // must return an IntDate object
{
  int mp, yp, t;
  long julian;

  if(month <= 2)
  { 
	  mp = 0;
	  yp = year -1;
  }
  else
  {
	  mp = int(0.4 * month + 2.3);
	  yp = year;
  }

  t = int(yp/4) - int(yp/100) + int(yp/400);
  julian = 365L * year + 31L * (month-1) + day + t - mp;

  return julian;
}
// member function to display a Date
void Date::showDate()
{
  cout << setfill('0')
       << setw(2) << month << '/'
       << setw(2) << day << '/'
       << setw(2) << year % 100 << endl;
}


// class implementation section for Julian
Julian::Julian(long ymd)  // constructor
{
  yyyymmdd = ymd;
}

// member function to display Julian
void Julian::showjulian()
{
  cout << yyyymmdd << endl;
  return;
}

int main()
{
  Date a(1,31,2011), c(3,16,2012);  // declare and initialize one object of type date
  Julian b, d;          // declare an object of type long

  b = Julian(a); 
  d = Julian(c);			// a conversion takes place here

  cout << "a's date is ";
  a.showDate();
  cout << "This date, as a Julian object, is ";
  b.showjulian();
  cout << endl;

  cout << endl;

  cout << "c's date is ";
  c.showDate();
  cout << "This date, as a Julian object, is ";
  d.showjulian();
  cout << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

