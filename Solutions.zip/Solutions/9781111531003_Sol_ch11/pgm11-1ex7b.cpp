// File: pgm11-1ex7b.cpp
// Description: 11.1 Exercise 7b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Car
{
  private:
    double engineSize;
    char bodyStyle;
    int colorCode;
  public:
    Car(double = 0.0, char = 'X', int = 0);  // default constructor
    void operator=(Car& );      // overloaded assignment operator
    void showdata();        // member function to display a time
};
 
// class implementation section
Car::Car(double eng, char styl, int cd)
{
  engineSize = eng;
  bodyStyle = styl;
  colorCode = cd;
}
void Car::operator=(Car& oldcar)
{
  engineSize = oldcar.engineSize;
  bodyStyle = oldcar.bodyStyle;
  colorCode = oldcar.colorCode;
  return;
}
void Car::showdata()
{
  cout << "\nThe values for this object are \n"
       << "  Engine size: " << engineSize << endl
       << "  Body style:  " << bodyStyle << endl
       << "  Color code:  " << colorCode << endl;
  return;
}

int main()
{
  Car a(250.0, 'S', 52), b;  // declare 2 objects

  a.showdata();   // display object a's values
  b.showdata();   // display object b's values
  b = a;          // assign a to b
  b.showdata();   // display object b's values

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

