// File: pgm11-4ex4b.cpp
// Description: 11.4 Exercise 4b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <math.h>
using namespace std;

class declaration section
class Complex
{
  // friends list
  friend double addreal(Complex&, Complex&);
  friend double addimag(Complex&, Complex&);

  private:
    double real;
    double imag;
  
  public:
    Complex(double = 0, double = 0);  // constructor
    void display();
	Complex operator[](double);

};

// class implementation section

Complex::Complex(double rl, double im)
{
  real = rl;
  imag = im;
}

void Complex::display()
{
  char sign = '+';

  if(imag < 0) sign = '-';
  cout << real << sign << fabs(imag) << 'i';

  return;
}

Complex Complex::operator[](double multiplier)
{
return Complex(real * multiplier, imag * multiplier);
}


// friend implementations

double addreal(Complex &a, Complex &b)
{
  return(a.real + b.real);
}

double addimag(Complex &a, Complex &b)
{
  return(a.imag + b.imag);
}


int main(){
  Complex a(3.0,4.0), b;
	
  cout << "Current value of a: ";
	
  a.display();
  cout << endl;

  b = a[2];

  cout << "Current value of b: ";
  b.display();
  cout << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

