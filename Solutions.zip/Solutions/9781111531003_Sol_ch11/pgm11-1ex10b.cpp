// File: pgm11-1ex10b.cpp
// Description: 11.1 Exercise 10b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <iomanip>
using namespace std;

// class declaration section
class Date
{
   private:
    int month;
    int day;
    int year;

   public:
     Date(int = 7, int = 4, int = 2012); // constructor with default
     Date operator+(int);  // overload the + operator
     void showDate();      // accessor
     
};

// class implementation section
Date::Date(int mm, int dd, int yyyy)
{
  month = mm;
  day = dd;
  year = yyyy;
}

Date Date::operator+(int days)
{
  int daysrem;
  int ds[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
  Date temp;  // a temporary date to store the result

  temp.day = day;
  temp.month = month;
  temp.year = year;

  daysrem = ds[month] - temp.day;
  while (daysrem < days)  
  {
    temp.month++;
    if(temp.month > 12)
	{
		temp.month = 1;
		temp.year++;
	}
	temp.day = 1;
	days -= (daysrem + 1);
	daysrem = ds[month] - temp.day;
  }
  //now the days remining are within the current month
  temp.day = temp.day + days;
  return temp;     // the values in temp are returned
}

void Date::showDate()
{
  cout << setfill('0')
       << setw(2) << month << '/'
       << setw(2) << day << '/'
       << setw(2) << year % 100 << endl;
}

int main()
{
  Date a(4,1,2007), b; // declare two objects

  cout << "The initial date is ";
  a.showDate();
  b = a + 284;   // add in 284 days = 9 months and 14 days
  cout << "The new date is ";
  b.showDate();

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

