// File: pgm11-1ex12b.cpp
// Description: 11.1 Exercise 12b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 
using namespace std;

// class declaraton section
class Date
{
  friend int operator==(Date& , Date& );  // declare the friend function
  private:
     int month;
     int day;
     int year;
   public:
     Date(int = 7, int = 4, int = 2006);     // constructor
     void showdate(void);  // member function to display a Date
};

// class implementation section
Date::Date(int mm, int dd, int yy)
{
  month = mm;
  day = dd;
  year = yy;
}

// friend implementation
int operator==(Date& date1, Date& date2)
{
  if(date1.day == date2.day && date1.month == date2.month && date1.year == date2.year)
    return 1;
  else
    cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

int main()
{
  Date a(4,1,2008), b(12,18,2001), c(4,1,2008); // declare 3 objects

  if (a == b)
    cout << "Dates a and b are the same." << endl;
  else
    cout << "Dates a and b are not the same." << endl;

  if (a == c)
    cout << "Dates a and c are the same." << endl;
 
  else
    cout << "Dates a and c are not the same." << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

