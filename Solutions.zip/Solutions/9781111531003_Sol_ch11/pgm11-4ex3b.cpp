// File: pgm11-4ex3b.cpp
// Description: 11.4 Exercise 3b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

// class declaration section
class Student
{
  private:
     int idNumber;
     int gradeCount;
     double grades[4];
   public:
     Student(int = 0, int = 0, double = 0, double = 0, double = 0, double = 0);     // constructor
     void showStudent(void);     // member function to display a Student
	 string operator[](double);    
};

// class implementation section
Student::Student(int id, int cnt, double g1, double g2, double g3, double g4)
{
  idNumber = id;
  gradeCount = cnt;
  grades[0] = g1;
  grades[1] = g2;
  grades[2] = g3;
  grades[3] = g4;
}

void Student::showStudent()
{
  cout << "Id Number: " << idNumber << endl;
  if(gradeCount == 1)
  {
	  cout << "Grades: " << grades[0] << endl;
	  cout << "Average: " << grades[0] << endl;
  }
  else if(gradeCount == 2)
  {
	  cout << "Grades: " << grades[0] << "\n"
		   << "        " << grades[1] << endl;
	  cout << "Average: " << (grades[0] + grades[1])/2 << endl;
  }
  else if(gradeCount == 3)
  {
	  cout << "Grades: " << grades[0] << "\n"
		   << "        " << grades[1] << "\n"
		   << "        " << grades[2] << endl;
	  cout << "Average: " << (grades[0] + grades[1] + grades[2])/3 << endl;
  }
  else if(gradeCount == 4)
  {
	  cout << "Grades: " << grades[0] << "\n"
		   << "        " << grades[1] << "\n"
		   << "        " << grades[2] << "\n"
		   << "        " << grades[3] << endl;
	  cout << "Average: " << (grades[0] + grades[1] + grades[2] + grades[3])/4 << endl;
  } 
  else if(gradeCount == 0)
	  cout << "No valid grades" << endl;
  return;
}

string Student::operator[](double grade)
{
  if(gradeCount == 4)
	  return "The new grade cannot be accepted";
  else if(gradeCount == 3)
	  grades[3] = grade;
  else if(gradeCount == 2)
	  grades[2] = grade;
  else if(gradeCount == 1)
	  grades[1] = grade;
  else if(gradeCount == 0)
	  grades[0] = grade;

  gradeCount++;

  return "Successfully added grade\n";
}


int main()
{
  Student a(123, 4, 98, 95, 88, 75), b(321, 2, 77, 75, 0, 0), c(42, 0, 0, 0, 0);

  a.showStudent();
  cout << "Adding a grade of 97: " << a[97] << endl;
  a.showStudent();
  cout << endl;

  b.showStudent();
  cout << "Adding a grade of 77: " << b[77] << endl;
  b.showStudent();
  cout << endl;

  c.showStudent();
  cout << "Adding a grade of 84: " << c[84] << endl;
  c.showStudent();
  cout << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

