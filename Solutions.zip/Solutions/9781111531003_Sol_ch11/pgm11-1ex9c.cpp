// File: pgm11-1ex9c.cpp
// Description: 11.1 Exercise 9c
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

// class declaration section
class Date
{
  private:
     int month;
     int day;
     int year;
   public:
     Date(int = 7, int = 4, int = 2012);     // constructor
 
     long operator-(Date& );  // define subtraction of a Date
	 Date operator-(long days);
     void showdate(void);     // member function to display a Date
};

// class implementation section
Date::Date(int mm, int dd, int yy)
{
  month = mm;
  day = dd;
  year = yy;
}

long Date::operator-(Date& secdate)
{
  long days;    // variable used to store the result of this operation

  days = (year-secdate.year)*360L + (month-secdate.month)*30L + long(day-secdate.day);
  return days;
}

Date Date::operator-(long days)
{
  Date temp;  // a temporary Date to store the result

  temp.day = day - days;  // subtract the days
  temp.month = month;
  temp.year = year;
  while (temp.day <= 0)  // adjust the days/months
  {
	  temp.month--;
	  if(temp.month != 2)
		temp.day = temp.day + 30;
	  else
		temp.day = temp.day + 28;
  }

  while (temp.month <= 0)  // adjust the years
  {
	  temp.year--;
	  temp.month = temp.month + 12;
  }
  return temp;     // the values in temp are returned
}


void Date::showdate(void)  // optional
{
  cout << "The Date is " << month << "/" << day << "/" << year << "\n";
  return;
}

int main()
{
  Date a(4,15,2008), b(12,18,2001), c; 
  long num = 45;

  a.showdate();
  b.showdate();

  cout << "The difference in dates is " << (a - b) << " days\n";

  c = a - num;
  c.showdate();

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

