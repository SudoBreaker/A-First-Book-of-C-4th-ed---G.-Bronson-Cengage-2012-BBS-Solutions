// File: pgm11-4ex2b.cpp
// Description: 11.4 Exercise 2b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Date
{
  private:
     int month;
     int day;
     int year;
   public:
     Date(int = 7, int = 4, int = 2012);     // constructor
 
     Date operator()(int, int, int);
     void showdate(void);     // member function to display a Date
};

// class implementation section
Date::Date(int mm, int dd, int yy)
{
  month = mm;
  day = dd;
  year = yy;
}
Date Date::operator()(int mm, int dd, int yy)
{
  Date temp;  // a temporary Date to store the result

  temp.day = day + dd;  // add the days
  temp.month = month + mm;
  temp.year = year + yy;
  while (temp.day > 30)    // now adjust the months
  {
    temp.month++;
    temp.day -= 30;
  }
  while (temp.month > 12)  // adjust the years
  {
    temp.year++;
    temp.month -= 12;
  }
  return temp;     // the values in temp are returned
}

void Date::showdate(void)
{
  cout << month << "/" << day << "/" << year;
  return;
}

int main()
{
  Date a(7,16,2011), b; // declare two objects

  cout << "The initial Date is ";
  a.showdate();
 
  b = a(3,2,1);  // add in 3 months, 2 days, and 1 year
  cout << "\nThe new Date is ";
  b.showdate();
  cout << endl;  

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

