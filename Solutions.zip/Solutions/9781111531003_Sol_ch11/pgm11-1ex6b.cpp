// File: pgm11-1ex6b.cpp
// Description: 11.1 Exercise 6b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Complex
{
  private:
    double real;
	double imag;
  public:
    Complex(double = 0, double = 0);  // default constructor
    void operator=(Complex& );    // overloaded assignment operator
    void showdata();       
};

// class implementation section
Complex::Complex(double rr, double ii)
{
  real = rr;
  imag = ii;
}
void Complex::operator=(Complex& oldnum)
{
  real = oldnum.real;
  imag = oldnum.imag;
  return;
}
void Complex::showdata()
{
  double c;
  char sign = '+';

  c = imag;
  if(c < 0)
  {
	  sign = '-';
	  c = -c;
  }
  cout << "The complex number is "
	   << real << ' ' << sign << ' ' << c << "i" << endl;
  return;
}

int main()
{
  Complex a(4.2, 3.6), b;  // declare 2 objects

  a.showdata();   // display object a's values
  b.showdata();   // display object b's values
  b = a;          // assign a to b
  b.showdata();   // display object b's values

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

