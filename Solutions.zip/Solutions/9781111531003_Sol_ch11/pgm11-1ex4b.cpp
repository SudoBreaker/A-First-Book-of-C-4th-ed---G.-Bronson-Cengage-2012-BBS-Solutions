// File: pgm11-1ex4b.cpp
// Description: 11.1 Exercise 4b
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

// class declaration section
class Cartesian
{
  private:
    double x;
	double y;
  public:
    Cartesian(double = 0.0, double = 0.0);  // default constructor
	void input(double, double);
    void operator=(Cartesian& );    // overloaded assignment operator
    void showdata();       
};

// class implementation section
Cartesian::Cartesian(double xval, double yval)
{
  x = xval;
  y = yval;
}
void Cartesian::operator=(Cartesian& oldnum)
{
  x = oldnum.x;
  y = oldnum.y;
  return;
}
void Cartesian::showdata()
{
	cout << "(" << x << ", " << y << ")" << endl;
	return;
}

void Cartesian::input(double newx, double newy)
{
	x = newx;
	y = newy;
}


int main()
{
  Cartesian a, b(3.0, 2.0);
  double xval, yval;

  cout << "Point a is initially located at ";
  a.showdata();
  cout << "Point b is initially located at ";
  b.showdata();
  cout << "Enter a new x and y value for b: ";
  cin >> xval >> yval;
  b.input(xval, yval);
  cout << "Point b is now located at ";
  b.showdata();
  a=b;
  cout << "Point a is now located at ";
  a.showdata();    

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

