// File: pgm11-1ex2c.cpp
// Description: 11.1 Exercise 2c
// Programmer: G. Bronson
// Date: 9/15/2010

#include  "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 
using namespace std;

// class declaration section
class Date
{
  private:
    int month;
    int day;
    int year;

  public:
    Date(int = 7, int = 4, int = 2012);   // constructor
    bool operator==(Date &);  // declare the operator== function
	int operator>(Date &);
	int operator<(Date &);
};

// class implementation section

Date::Date(int mm, int dd, int yyyy)
{
  month = mm;
  day = dd;
  year = yyyy;
}

bool Date::operator==(Date &date2)
{
  if(day == date2.day && month == date2.month && year == date2.year)
    return true;
  else
    return false;
}

int Date::operator>(Date &date2)
{
	long dt1, dt2;

	dt1 = year * 10000L + month*100 + day;
	dt2 = date2.year*10000L + month*100 + day;

	if(dt1 > dt2)
		return 1;
	else
		
    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}

int Date::operator<(Date &date2)
{
	long dt1, dt2;

	dt1 = year * 10000L + month*100 + day;
	dt2 = date2.year*10000L + month*100 + day;

	if(dt1 < dt2)
		return 1;
	else
		cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

int main()
{
  Date a(4,1,2008), b(12,18,2001), c(4,1,2008); // declare 3 objects

  if (a < b)
    cout << "Date a is less than b." << endl;
  else
    cout << "Date a is either greater than or equal to b." << endl;

  if (a > c)
    cout << "Date a is greater than c." << endl;
  else
    cout << "Date a is either less than or equal to c." << endl;

       

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

