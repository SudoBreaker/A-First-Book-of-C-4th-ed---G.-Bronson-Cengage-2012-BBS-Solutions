// File: pgm9-4ex2.cpp
// Description: 9.4 Exercise 2
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

int main()
{
  int fcheck(ifstream&);

  ifstream inFile;

  if(fcheck(inFile) == 1)
	  cout << "The file exists and has been opened.";
  else
	  cout << "The file cannot be opened - check that it exists.";

  inFile.close();  // to close the open file
       
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}

int fcheck(ifstream& file)
{
  string name;

  cout << "\nEnter a file name: ";
  getline(cin,name);

  file.open(name.c_str());      // open the file

  if (file.fail())
	    cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


  else
	  return 1;
}


