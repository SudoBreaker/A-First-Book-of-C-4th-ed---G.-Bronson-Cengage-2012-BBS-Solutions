// File: pgm9-2ex3a.cpp
// Description: 9.2 Exercise 3a
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <cstdlib>   // needed for exit()
#include <string>
using namespace std;

int main()
{
  string filename = "text.dat";  // put the filename up front
  string line;
  ofstream outFile;
  
  outFile.open(filename.c_str());

  if (outFile.fail())  // check for successful open
  {
    cout << "\nThe file was not successfully opened"
	     << "\n Please check that the file currently exists."
	 << endl;
    exit(1);
  }

  cout << "Enter lines of text, enter a blank line to end" << endl;

  getline(cin,line);
  while (line != "")
  {
    outFile << line << endl;
	getline(cin,line);
  }

  outFile.close(); 
  cout << "End of data input" << endl;
  cout << "The file has been written" << endl;   

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}