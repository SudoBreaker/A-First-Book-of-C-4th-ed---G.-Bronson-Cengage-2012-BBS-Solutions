// File: pgm9-3ex6a.cpp
// Description: 9.3 Exercise 6a
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

int main()
{
  void readBytes(fstream&, long, int);

  string filename;
  long start;
  int num;

  cout << "Enter a filename: ";
  cin >> filename;

  fstream inFile(filename.c_str());

  if (inFile.fail())   // check for successful open
  {
    cout << "\nThe file was not successfully opened"
      << "\n Please check that the file currently exists"
      << endl;
    exit(1);
  }

  cout << "Enter starting position: ";
  cin >> start;
  cout << "Enter the number of characters to read: ";
  cin >> num;

  cout << "\nThe characters are: " << endl;
  readBytes(inFile, start, num);      
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}

void readBytes(fstream& file, long start, int num)
{
	char ch;
	int i;

	file.seekg(start, ios::beg);  // move to the starting char
	for(i = 0; i < num; i++)
	{
		ch = file.get();
		cout << ch;
	}

	return;
}

