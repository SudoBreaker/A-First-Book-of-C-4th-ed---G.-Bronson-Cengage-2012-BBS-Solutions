// File: pgm9-1ex4.cpp
// Description: 9.1 Exercise 4
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <cstdlib>   // needed for exit()
using namespace std;

int main()
{
  ifstream inFile;

  inFile.open("prices.dat");  // open the file with the                                                     // external name prices.dat
  if (inFile.fail())  // check for a successful open
  {
    cout << "\nThe file was not successfully opened"
	     << "\n Please check that the file currently exists." 
         << endl;
    exit(1);
  }

  cout << "\nThe file has been successfully opened for reading"
       << endl;
  
  // statements to read data from the file would be placed here     

  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}  
