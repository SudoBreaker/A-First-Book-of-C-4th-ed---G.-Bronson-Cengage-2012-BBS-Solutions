// File: pgm9-2ex5c.cpp
// Description: 9.2 Exercise 5c
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <cstdlib>   // needed for exit()
#include <string>
using namespace std;

int main()
{
  string filenameIn;  
  string filenameOut;  
  string line;
  ifstream inFile;
  ofstream outFile;

  cout << "Please enter the name of the input file: ";
  cin  >> filenameIn;

  cout << "Please enter the name of the output file: ";
  cin  >> filenameOut;
  
  inFile.open(filenameIn.c_str());
  outFile.open(filenameOut.c_str());

  if (inFile.fail())  // check for successful open
  {
    cout << "\nThe in file was not successfully opened"
	 << "\n Please check that the file currently exists."
	 << endl;
    exit(1);
  }

  if (outFile.fail())
  {
    cout << "The out file was not successfully opened" << endl;
    exit(1);
  }

  // read and copy the file's contents to the outfile
  while (getline(inFile,line))
  {
    outFile << line << endl;
  }

  inFile.close(); 
  outFile.close();

  cout << "The file " << filenameOut 
       << " has been successfully written." << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}