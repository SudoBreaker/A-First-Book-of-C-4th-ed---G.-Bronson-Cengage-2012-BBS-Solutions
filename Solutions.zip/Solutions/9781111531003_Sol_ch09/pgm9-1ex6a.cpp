// File: pgm9-1ex6a.cpp
// Description: 9.1 Exercise 6a
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <cstdlib>   // needed for exit()
#include <string>
using namespace std;

int main()
{
  string filename = "prices.dat"; // place the file name up front
  ifstream inFile;

  inFile.open(filename.c_str());  // open the file

  if (inFile.fail())  // check for successful open
  {
    cout << "\nThe file named " << filename << " was not successfully opened" 
		 << "\n Please check that the file currently exists."
		 << endl;
    exit(1);
  }
  
  cout << "\nThe file has been successfully opened for reading.\n";

  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}  
