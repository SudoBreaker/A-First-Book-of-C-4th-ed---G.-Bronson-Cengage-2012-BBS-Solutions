// File: pgm9-2ex7b.cpp
// Description: 9.2 Exercise 7b
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>   // needed for exit()
#include <string>
using namespace std;

int main()
{
  string filename  = "info.dat";  
  string name, initial, ssn;
  double rate, hours;
  ifstream inFile;

  inFile.open(filename.c_str());

  if (inFile.fail())  // check for successful open
  {
    cout << "\nThe file was not successfully opened"
	     << "\n Please check that the file currently exists."
	     << endl;
    exit(1);
  }

  // read and display the file's contents
  cout << fixed << setprecision(2) << endl;
  cout << "Social" << endl;
  cout << "Security" << endl;
  cout << "Number               Name            Gross Pay" << endl;
  cout << "--------             ----            ---------" << endl;
  inFile >> initial >> name >> ssn >> rate >> hours;
  while (inFile.good()) 
  {
     cout << setw(11) << ssn << "          " 
		  << initial << " " << setw(7) << name << " "
		  << setw(7) << "$" << (rate * hours) << endl;
	 inFile >> initial >> name >> ssn >> rate >> hours;
  }

  //to print the last line
  cout << setw(11) << ssn << "          " 
		  << initial << " " << setw(7) << name << " "
		  << setw(7) << "$" << (rate * hours) << endl;


  inFile.close(); 

  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}