// File: pgm9-3ex4.cpp
// Description: 9.3 Exercise 4
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

int main()
{
  string filename = "test.dat";
  char ch;
  long offset, last;

  ifstream inFile(filename.c_str());

  if (inFile.fail())   // check for successful open
  {
    cout << "\nThe file was not successfully opened"
      << "\n Please check that the file currently exists"
      << endl;
    exit(1);
  }

  inFile.seekg(0L,ios::end);   // move to the end of the file
  last = inFile.tellg();       // save the offset of the last character

  for(offset = 1L; offset <= last; offset+=2)
  {
	inFile.seekg(offset, ios::beg);
	ch = inFile.get();
	cout << ch << " : ";
  }

  inFile.close();
 
  cout << endl;      
  
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}

