// File: pgm9-2ex13.cpp
// Description: 9.2 Exercise 13
// Programmer: G. Bronson
// Date: 9/5/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <iomanip>
using namespace std;


int main()
{
	const int MAXCUSTOMERS = 5;
	int acts[MAXCUSTOMERS];
	char first[MAXCUSTOMERS][10];
	char last[MAXCUSTOMERS][15];
	double balance[MAXCUSTOMERS];

	int account;
	int i;

	ifstream input("bank.dat");

	if (input.fail())
	{
		cout << "ERROR: Cannot open customer record file!" << endl; 
		exit(1);
	}

	// Read in the customer records from the file
	for (i = 0; i < MAXCUSTOMERS; i++)
	{
		input >> acts[i];
		input >> first[i];
		input >> last[i];
		input >> balance[i];
	}

	input.close();
		

	cout << "Please enter an account number: ";
	cin >> account;

	if ((account < 1000) || (account >= (1000 + MAXCUSTOMERS)))
	{
		cout << "ERROR: Invalid account number." << endl;
		exit(2);
	}
	else
	{
		account -= 1000;

		cout << "\nThis account belongs to " << first[account] << " ";
		cout << last[account] << "." << endl;

		cout << "Current balance: $";
		cout << setiosflags(ios::fixed) << setiosflags(ios::showpoint)
			 << setprecision(2);
		cout << balance[account] << endl << endl;
	}

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
  
    return 0;
}

