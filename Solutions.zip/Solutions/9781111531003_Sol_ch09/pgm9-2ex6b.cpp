// File: pgm9-2ex6b.cpp
// Description: 9.2 Exercise 6b
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <cstdlib>   // needed for exit()
#include <string>
using namespace std;

int main()
{
  string filename;  // put the filename up front
  string line;
  ifstream inFile;
  ofstream outFile;
  int count = 0;

  cout << "Enter the input file: ";
  cin >> filename;
  
  inFile.open(filename.c_str());
  outFile.open("LPT1");       // **** you will have to modify this line to accomodate
							  // the location of your printer ****

  if (inFile.fail())  // check for successful open
  {
    cout << "\nThe file was not successfully opened"
	     << "\n Please check that the file currently exists."
	     << endl;
    exit(1);
  }

  if (outFile.fail())  // check for successful open
  {
    cout << "\nThe printer was not successfully opened" << endl;
    exit(1);
  }

  // read and display the file's contents
  while (getline(inFile,line))
  {
    count++;
    outFile << count << ".  " << line << endl;
  }

  inFile.close(); 
  outFile.close();    

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}