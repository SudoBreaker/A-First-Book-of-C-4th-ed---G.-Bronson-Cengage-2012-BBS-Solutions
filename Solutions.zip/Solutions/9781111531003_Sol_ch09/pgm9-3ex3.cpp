// File: pgm9-3ex3.cpp
// Description: 9.3 Exercise 3
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

int main()
{
  string filename = "test.dat";
  char ch;
  long offset, last, pos;

  ifstream inFile(filename.c_str());

  if (inFile.fail())   // check for successful open
  {
    cout << "\nThe file was not successfully opened"
         << "\n Please check that the file currently exists"
         << endl;
    exit(1);
  }

  try
  {
	if(!inFile.seekg(0L,ios::end)) throw "Beyond file boundries!";   // move to the end of the file
	last = inFile.tellg();       // save the offset of the last character

	for(offset = 1L; offset <= last; offset++)
	{
		if(!inFile.seekg(-offset, ios::end)) throw "Beyond file boundries!";
		ch = inFile.get();
		cout << ch << " : ";
	}

  }
  catch(string mes)
  {
	  cout << "Error: " << mes << endl;
	  exit(1);
  }

  inFile.close();
 
  cout << endl;    
  
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}

