// File: pgm9-2ex6a.cpp
// Description: 9.2 Exercise 6a
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <cstdlib>   // needed for exit()
#include <string>
using namespace std;

int main()
{
  string filename;  // put the filename up front
  string line;
  ifstream inFile;
  int count = 0;

  cout << "Enter the input file: ";
  cin >> filename;
  
  inFile.open(filename.c_str());

  if (inFile.fail())  // check for successful open
  {
    cout << "\nThe file was not successfully opened"
	     << "\n Please check that the file currently exists."
	     << endl;
    exit(1);
  }

  // read and display the file's contents
  while (getline(inFile,line))
  {
    count++;
    cout << count << ".  " << line << endl;
  }

  inFile.close(); 

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}