// File: pgm9-3ex2.cpp
// Description: 9.3 Exercise 2
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

int main()
{
  string filename = "test.dat";
  char ch;
  long offset, last;

  ifstream inFile(filename.c_str());

  if (inFile.fail())   // check for successful open
  {
    cout << "\nThe file was not successfully opened"
         << "\n Please check that the file currently exists"
         << endl;
    exit(1);
  }

  inFile.seekg(0L,ios::end);   // move to the end of the file
  last = inFile.tellg();       // save the offset of the last character

  inFile.seekg(0L,ios::beg);   // move to the beginning of the file

  //for(offset = 0L; offset <= last; offset++)   // use this to print the characters in order
  for(offset = (last - 1); offset >= 0; offset--)
  {
    inFile.seekg(offset, ios::beg);
    ch = inFile.get();
    cout << ch << " : ";
  }

  inFile.close();
 
  cout << endl;    
  
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}

