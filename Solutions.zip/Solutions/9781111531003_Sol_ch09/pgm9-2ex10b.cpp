// File: pgm9-2ex10b.cpp
// Description: 9.2 Exercise 10b
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>   // needed for exit()
#include <string>
using namespace std;

int main()
{
  string filename  = "pay.dat"; 
  string name;
  double rate, regPay, overPay, grossPay;
  double regTot = 0, overTot = 0, grossTot = 0;
  int hours;
  ifstream inFile;

  inFile.open(filename.c_str());

  if (inFile.fail())  // check for successful open
  {
    cout << "\nThe file was not successfully opened"
	     << "\n Please check that the file currently exists."
	     << endl;
    exit(1);
  }

  // read and display the file's contents
  cout << fixed << setprecision(2);
  cout << "Name           Pay Rate   Hours   Regular Pay   Overtime Pay  Gross Pay" << endl;
  cout << "----------     --------   -----   -----------   ------------  ---------" << endl;
  inFile >> name >> rate >> hours;
  while (inFile.good()) 
  {
	 if(hours > 40)
	 {
		 regPay = 40 * rate;
		 overPay = (hours - 40) * 1.5 * rate;
	 }
	 else
	 {
		 regPay = hours * rate;
		 overPay = 0;
	 }
	 grossPay = regPay + overPay;
	 regTot = regTot + regPay;
	 overTot = overTot + overPay;
	 grossTot = grossTot + grossPay;
     cout << setw(11) << name << "       "
		  << rate << "       " << setw(2)
		  << hours << "     $"
		  << regPay << "     $" << setw(6)
		  << overPay << "       $"
		  << grossPay << "     " << endl;; 
	 inFile >> name >> rate >> hours;
  }


  cout << "----------     --------   -----   -----------   ------------  ---------" << endl;
  cout << "Totals:                             $" << regTot << "     $" << overTot << "      $"  << grossTot << endl;

  inFile.close();     

  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}