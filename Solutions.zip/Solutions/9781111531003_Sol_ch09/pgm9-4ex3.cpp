// File: pgm9-4ex3.cpp
// Description: 9.4 Exercise 3
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

int main()
{
  void printLine (ifstream&, int);

  string file;
  int line;
  ifstream inFile;
  
  cout << "\nEnter a file name: ";
  getline(cin,file);

  inFile.open(file.c_str());      // open the file
    
  if (inFile.fail())  // check for successful open
  {
    cout << "\nThe in file was not successfully opened"
	 << "\n Please check that the file currently exists."
	 << endl;
    exit(1);
  }

  cout << "Enter a line to print: ";
  cin >> line;

  printLine(inFile, line);

  inFile.close();  // to close the open file
    
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}

void printLine (ifstream& in, int lineToPrint)
{
	string nextLine;
	int i;

	if (lineToPrint > 0)
	{
		// Start by reading in all of the preceding lines
		for (i = 1; i < lineToPrint; i++)
			getline(in, nextLine);

		// Now, we can read in the line that we want
		getline(in, nextLine);
		cout << nextLine << endl;
	}

	return;
}



