// File: pgm9-3ex5.cpp
// Description: 9.3 Exercise 5
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

int main()
{
  long fileChars(string);

  string filename;

  cout << "Enter a filename: ";
  cin >> filename;

  cout << "There are " << fileChars(filename)  
	   << " characters in that file." << endl;      
  
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}

long fileChars(string filename)
{
	long pos;
	ifstream inFile(filename.c_str());

	if (inFile.fail())   // check for successful open
	{
    cout << "\nThe file was not successfully opened"
      << "\n Please check that the file currently exists"
      << endl;
    exit(1);
	}
	  
	inFile.seekg(0L,ios::end);   // move to the end of the file
	pos = inFile.tellg();
	inFile.close();

	return pos;
}

