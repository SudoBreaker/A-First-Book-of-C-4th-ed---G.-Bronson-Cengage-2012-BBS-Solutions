// File: pgm9-2ex11b.cpp
// Description: 9.2 Exercise 11b
// Programmer: G. Bronson
// Date: 9/4/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>   // needed for exit()
#include <string>
using namespace std;

int main()
{
  string filename  = "numbers.dat"; 
  int i, num, count;
  double avg = 0;
  ifstream inFile;

  inFile.open(filename.c_str());

  if (inFile.fail())  // check for successful open
  {
    cout << "\nThe file was not successfully opened"
	     << "\n Please check that the file currently exists."
	     << endl;
    exit(1);
  }

  inFile >> num;
  while(inFile.good())
  {
	  cout << "The number of elements in this group is " << num << endl;
	  cout << "The data in this group is: ";
	  count = num;

	  for(i = 0, avg = 0; i < count; i++)
	  {
		  inFile >> num;
		  cout << " " << num;
		  avg = avg + num;
	  }
	  cout << endl;
	  avg = avg / count;
	  cout << "Average = " << avg << endl;
	  cout << endl;
	  inFile >> num;
  }
  inFile.close(); 

  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;


}