// File: pgm1-3ex4c.cpp
// Description: 1.3 Exercise 4c
// Programmer: G. Bronson
// Date: 8/20/2010   


#include "stdafx.h"     // needed for MS C++ Express users
  
#include <iostream> 	 
using namespace std;

int main()
{
	cout <<  "PART NO.	  PRICE\n";
	cout <<  "T1267             $6.34\n";
	cout <<  "T1300             $8.92\n";
	cout <<  "T2401            $65.40\n";
	cout <<  "T4482            $36.99\n";

	cin.ignore();  // needed for MS C++ Express users

	return 0;
}
