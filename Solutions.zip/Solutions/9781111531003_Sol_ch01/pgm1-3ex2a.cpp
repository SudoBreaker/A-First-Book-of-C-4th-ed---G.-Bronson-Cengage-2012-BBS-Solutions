// File: pgm1-3ex2a.cpp
// Description: 1.3 Exercise 2a
// Programmer: G. Bronson
// Date: 8/20/2010

#include "stdafx.h"     // needed for MS C++ Express users

#include <iostream> 	 
using namespace std;

int main()
{
	cout << "Sally Jones";
	cout << "\n1000 Main Street";
	cout << "\nSomewhere, New York  00100";

	cin.ignore();  // needed for MS C++ Express users

	return 0;
}
