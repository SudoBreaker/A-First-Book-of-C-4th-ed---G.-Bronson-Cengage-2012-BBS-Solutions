// File: pgm1-3ex1a.cpp
// Description: 1.3 Exercise 1a
// Programmer: G. Bronson
// Date: 8/15/2010

#include "stdafx.h"     // needed for MS C++ Express users

#include <iostream> 	 
using namespace std;

int main()
{
  cout << "Hello there world!";

  cin.ignore(); // needed for MS C++ Express users

  return 0;
}


