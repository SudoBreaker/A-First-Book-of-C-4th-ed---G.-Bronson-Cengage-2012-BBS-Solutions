// File: pgm1-3ex3a.cpp
// Description: 1.3 Exercise 3a
// Programmer: G. Bronson
// Date: 8/20/2010

#include "stdafx.h"     // needed for MS C++ Express users

#include <iostream> 	 
using namespace std;

int main()
{
	cout << "Computers, computers everywhere";
	cout << "\n  as far as I can see";
	cout << "\nI really, really like these things,";
	cout << "\n  Oh joy, Oh joy for me!";

	cin.ignore();  // needed for MS C++ Express users

	return 0;
}
