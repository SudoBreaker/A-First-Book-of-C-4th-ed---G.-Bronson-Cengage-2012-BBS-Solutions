// File: pgm6-1ex9b.cpp
// Description: 6.1 Exercise 9b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int totsec(int, int, int); 

int main()
{
  int hours, minutes, seconds, sec;

  cout << "Enter the number of hours: ";
  cin >> hours;

  cout << "Enter the number of minutes: ";
  cin >> minutes;

  cout << "Enter the number of seconds: ";
  cin >> seconds;

  sec = totsec(hours, minutes, seconds);

  cout << "\nThe total number of seconds is " << sec << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

int totsec(int hours, int minutes, int seconds)
{                
	int sec;

	sec = 3600*hours + 60*minutes + seconds;
	return sec;
}




