// File: pgm6-2ex1.cpp
// Description: 6.2 Exercise 1
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

double findMax(double, double);  // function declaration (prototype)

int main()
{  
  double firstnum, secnum, max;

  cout << "\nEnter a number: ";
  cin  >> firstnum;
  cout << "Great! Please enter a second number: ";
  cin  >> secnum;

  max = findMax(firstnum, secnum);  // the function is called here

  cout << "\nThe maximum of these two values is " << max << endl; 

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

double findMax(double x, double y)
{                    // start of function body
  double maxnum;        // variable declaration

  if (x >= y)        // find the maximum number
    maxnum = x;
  else
    maxnum = y;

  return maxnum;     // return statement
}








