// File: pgm6-1ex5b.cpp
// Description: 6.1 Exercise 5b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

void sqrIt(double);  // function prototype

int main()
{
  double a = 3.8, b = 5.0, c = 23.1;
  sqrIt(a);
  sqrIt(b);
  sqrIt(c);
  
  cin.ignore();  // needed for MS C++ Express 2010 programs

  return 0;
}

void sqrIt(double number)
{ 
	cout << "The square of " << number << " is: " 
	     << (number * number) << endl;
	return;
}
