// File: pgm6-2ex4b.cpp
// Description: 6.2 Exercise 4b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

double findAbs(double);  // function prototype
 
int main()
{
  double a = 5.0, b = -3.2, c = 3.4252, d = -78.6434;

  cout << "The absolute value of " << a
	  << " is: " << findAbs(a) << endl;
  cout << "The absolute value of " << b
	  << " is: " << findAbs(b) << endl;
  cout << "The absolute value of " << c
	  << " is: " << findAbs(c) << endl;
  cout << "The absolute value of " << d
	  << " is: " << findAbs(d) << endl;

  cin.ignore();  // needed for MS C++ Express 2010 programs

  return 0;
}

double findAbs(double number)
{                    
	if(number < 0)
		number = -number;
	return number;
}

