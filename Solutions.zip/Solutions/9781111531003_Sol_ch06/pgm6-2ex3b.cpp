// File: pgm6-2ex3b.cpp
// Description: 6.2 Exercise 3b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

double rightTriangle(double, double);  // function prototype

int main()
{
  int a = 3, b = 5, c = 4;

  cout << "The hypotenuse of a right-triangle with sides: " << endl;
  cout << a << " and " << b << " is: " << RightTriangle(a, b) << endl;
  cout << a << " and " << c << " is: " << RightTriangle(a, c) << endl;

  cin.ignore();  // needed for MS C++ Express 2010 programs

  return 0;
}

double RightTriangle(double a, double b)
{         
  return sqrt((a * a) + (b * b));
}





