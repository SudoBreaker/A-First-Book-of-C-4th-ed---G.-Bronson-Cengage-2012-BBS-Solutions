// File: pgm6-2ex5b.cpp
// Description: 6.2 Exercise 5b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

double cylvol(double, double);

int main()
{
  double rad, len;
  cout << "Enter the radius: ";
  cin >> rad;
  cout << "Enter the length: ";
  cin >> len;

  cout << "The volume is: "
       << cylvol(rad, len) << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

double cylvol(double radius, double length)
{       
  return 3.1416 * radius * radius * length;
}


