// File: pgm6-2ex6b.cpp
// Description: 6.2 Exercise 6b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

double surfarea(double, double);

int main()
{
  double rad;
  double length;

  cout << "Enter the radius: ";
  cin >> rad;

  cout << "Enter the length: ";
  cin >> length; 

  cout << "The side surface area is: "
       << surfarea(rad, length) << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

double surfarea(double radius, double length)
{       
  return 3.1416 * 2 * radius * length;
}


