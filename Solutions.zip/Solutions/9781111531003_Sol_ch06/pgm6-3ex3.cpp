// File: pgm6-5ex3.cpp
// Description: 6.5 Exercise 3
// Programmer: N. Ashton
// Employee: 1/15/2006

#include <iostream>
using namespace std;

void findMax(int, int, int&);  // function declaration (prototype)

int main()
{
  
  int firstnum, secnum, max;

  cout << "\nEnter a number: ";
  cin  >> firstnum;
  cout << "Great! Please enter a second number: ";
  cin  >> secnum;

  findMax(firstnum, secnum, max);

  cout << "\nThe maximum of these two values is "
       << max << endl; // the function is called here

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void findMax(int x, int y, int& max)
{                    // start of function body
  int maxnum;        // variable declaration

  if (x >= y)        // find the maximum number
    maxnum = x;
  else
    maxnum = y;

  max = maxnum;

  return;     // return statement
}
