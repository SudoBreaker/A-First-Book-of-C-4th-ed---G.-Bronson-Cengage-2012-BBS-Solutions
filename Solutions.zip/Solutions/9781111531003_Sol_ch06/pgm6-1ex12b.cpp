// File: pgm6-1ex12b.cpp
// Description: 6.1 Exercise 12b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

void evenOdd(int);  // function prototype

int main()
{
  evenOdd(3);
  evenOdd(14);
  evenOdd(45);

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void evenOdd(int num)
{         
	if(num % 2 == 0)
		cout << num << " is even" << endl;
	else
		cout << num << " is odd"
		     << endl;
  	return;
}
