// File: pgm6-1ex4b.cpp
// Description: 6.1 Exercise 4b
// Programmer: G. Bronson
// Date:  10/26/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

void mult(float, float);  // function prototype

int main()
{
  double a = 5.0, b = -3.2, c = 2.52, d = 7.8;
  mult(a, b);
  mult(b, c);
  mult(c, d);

  cin.ignore();  // needed for MS C++ Express 2010 programs

  return 0;
}

void mult(float num1, float num2)
{                    
	cout << num1 << " * " << num2 << " = " <<  (num1 * num2) << endl;
	return;
}
