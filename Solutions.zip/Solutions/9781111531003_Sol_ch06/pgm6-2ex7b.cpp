// File: pgm6-2ex7b.cpp
// Description: 6.2 Exercise 7b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

double totamt(int, int, int, int);  // function prototype

int main()
{
  double amount;

  amount = totamt(26, 80, 100, 216);

  cout << "The amount is: $" << fixed 
       << setprecision(2) << amount << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}


double totamt(int quarters, int dimes, int nickels, int pennies)
{
	double amount;

	amount = 0.25*quarters + 0.10*dimes + 0.05*nickels + 0.01*pennies;

	return amount;
}







