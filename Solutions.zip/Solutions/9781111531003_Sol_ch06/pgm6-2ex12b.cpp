// File: pgm6-2ex12b.cpp
// Description: 6.2 Exercise 12b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int whole(double);  // function prototype

int main() 
{ 
  double num1;
  
  cout << "Enter any number: ";
  cin >> num1; 

  cout << "The int value of " << num1 << " is: "
       << whole(num1) << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

int whole(double num) // header line 
{
  return int(num);
}

 
