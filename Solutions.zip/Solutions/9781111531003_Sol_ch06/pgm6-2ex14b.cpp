// File: pgm6-2ex14b.cpp
// Description: 6.2 Exercise 14b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int leapyear(int);  // function prototype

int main()
{
  int year;

  cout << "Please enter a year: ";
  cin >> year;

  if (leapyear(year))
	  cout << "This year is a leap year\n";
  else
	  cout << "This year is not a leap year\n";

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

 int leapyear(int year)
 {
   if ( (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0) )
      return 1;
   else
     cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
 } 

