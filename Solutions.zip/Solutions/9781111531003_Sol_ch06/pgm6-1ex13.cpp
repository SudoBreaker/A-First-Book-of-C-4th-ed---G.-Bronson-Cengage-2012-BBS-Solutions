// File: pgm6-1ex13.cpp
// Description: 6.1 Exercise 13
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

void pi();  // function prototype 

int main()
{
   pi();
 
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void pi()
{   
	cout << "The value of Pi is " << (2.0 * asin(1.0)) << endl;
	return;
}







