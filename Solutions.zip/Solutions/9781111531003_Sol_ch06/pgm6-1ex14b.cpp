// File: pgm6-1ex14b.cpp
// Description: 6.1 Exercise 14b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

template <class T> // template prefix 
void display(T value) // header line 
{ 
  cout << "The argument passed is: " << value << endl;
  
  return; 
} 

int main() 
{ 
  char letter = 'E';
  int num1 = -4; 
  float num2 = -4.2f; 
  double num3 = -4.23456; 
  
  display(letter);
  display(num1);
  display(num2);
  display(num3);
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
