// File: pgm6-2ex11.cpp
// Description: 6.2 Exercise 11
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

double triArea(int, int, int);  // function prototype

int main()
{
  int a, b, c;
  double area;

  cout << "Enter a value for a: ";
  cin >> a;
  cout << "Enter a value for b: ";
  cin >> b;
  cout << "Enter a value for c: ";
  cin >> c;

  area = triArea(a, b, c);

  if(area == -1)
	cout << "The lengths specified do not form a triangle" << endl;
  else
	cout << "The area of the triangle is: " << area << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

double triArea(int a, int b, int c)
{       
  double s, sq;

  s = (a + b + c)/2;
  sq = s * (s - a) * (s - b) * (s - c);

  if(sq < 0)
	  return -1;
  else
	  return sqrt(sq);
}

