// File: pgm6-3ex4b.cpp
// Description: 6.3 Exercise 4b
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

void change(int, int&, int&, int&, int&, int&, int&);  // function prototype

int main()
{
	int amount, hundreds, fifties, twenties;
	int tens, fives, ones;
	
	cout << "Enter a dollar amount (no cents):  ";
	cin  >> amount;

	change(amount, hundreds, fifties, twenties, tens, fives, ones);

	cout << amount << " dollars consists of:\n"
	     << hundreds << " hundred dollar billss\n" << fifties << " fifty dollar billes\n"
	     << twenties << " twenty dollar bills\n" << tens << " ten dollar bills\n"
		 << fives << " five dollar bills, and\n" << ones << " one dollar bills\n";

	 cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
    
void change(int amount, int& hundreds, int& fifties, int&  twenties, int& tens, int& fives, int& ones)
{
  int newAmount;

  hundreds = amount / 100;
  newAmount = amount - hundreds * 100;

  fifties = newAmount / 50;
  newAmount = newAmount - fifties * 50;

  twenties = newAmount / 20;
  newAmount = newAmount - twenties * 20;

  tens = newAmount / 10;
  newAmount = newAmount - tens * 10;

  fives = newAmount/5;
  newAmount = newAmount - fives * 5;

  ones = newAmount;

  return;
}
