// File: pgm6-1ex6b.cpp
// Description: 6.1 Exercise 6b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

void powfun(int, int);  // function prototype

int main()
{
  int a = 3, b = 2, c = 4;
  powfun(a, b);
  powfun(b, c);
  powfun(c, a);

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void powfun(int number, int pow)
{         
	long result = 1;
	int i;

	for(i=0; i < pow; i++)
	{
		result = result * number;
	}
	cout << number << " raised to the " << pow << " power is: "
	     << result << endl;
      return;
}
