// File: pgm6-1ex2b.cpp
// Description: 6.1 Exercise 2b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 program

#include <iostream>
using namespace std;

void check(int, double, double);  // function prototype

int main()
{
  int a = 2, b = 4;
  double c = 4.23, d = 5.43;
  double e = 3.4252, f = 78.6434;

  check(a, c, e);
  check(b, d, f);

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void check(int num1, double num2, double num3)
{                    
	cout << "\nIn check()\n";
	cout << "The value of num1 is " << num1 << endl;
	cout << "The value of num2 is " << num2 << endl;
	cout << "The value of num3 is " << num3 << endl;
	return;
}
