/// File: pgm6-2ex15b.cpp
// Description: 6.2 Exercise 15b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

double polyTwo(double, double, double, double);  // function prototype

int main()
{
  double a = 2.0, b = 3.0, c= 4.0;
  double x = 2;

  cout << "The polynomial value is " << polyTwo(a, b, c, x) << endl;
  

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

double polyTwo(double a, double b, double c, double x)
{                    
   return (a * x * x + b * x + c);
}
