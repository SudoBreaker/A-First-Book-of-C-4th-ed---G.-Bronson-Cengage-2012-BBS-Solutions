// File: pgm6-2ex10b.cpp
// Description: 6.2 Exercise 10b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <conio.h>
using namespace std;

int readOneChar();  // function prototype

int main()
{
  int ch;
  
  ch = readOneChar();

  cout << "\nThe integer value of the key entered was: " 
       << ch << endl;

   cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

int readOneChar()
{
  int key;

  cout << "Press a key: ";
  key = getch();           

  return key;
}