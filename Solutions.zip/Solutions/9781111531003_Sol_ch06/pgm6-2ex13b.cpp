// File: pgm6-2ex13b.cpp
// Description: 6.2 Exercise 13b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

double fracpart(double);  // function prototype
int whole(double);  // function prototype

int main() 
{ 
  double num; 
  cout << "Enter a number: ";
  cin >> num;
  cout << "\nThe fraction part of " << num << " is: "
       << fracpart(num) << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

double fracpart(double x)
{
	return (x - whole(x));
}

int whole(double num) // header line 
{ 
	int val;
	val = num;
	return val;
}
 
