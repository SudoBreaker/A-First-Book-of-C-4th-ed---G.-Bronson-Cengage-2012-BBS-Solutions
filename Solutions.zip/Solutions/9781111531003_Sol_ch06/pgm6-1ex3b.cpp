// File: pgm6-1ex3b.cpp
// Description: 6.1 Exercise 3b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs



#include <iostream>
using namespace std;

void findAbs(double);    // function prototype

int main()
{
  double a = 5.0, b = -3.2, c = 3.4252, d = -78.6434;
  findAbs(a);
  findAbs(b);
  findAbs(c);
  findAbs(d);

  cin.ignore();  // needed for MS C++ Express 2010 programs

  return 0;
}

void findAbs(double number)
{  
	cout << "The absolute value of " << number << " is: ";
	if(number < 0)
		number = -number;
	cout << number << endl;
	return;
}
