// File: pgm6-2ex8b.cpp
// Description: 6.2 Exercise 8b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int daycount(int, int, int);  // function prototype

int main()
{
  
  int month, day, year;

  cout << "Enter a number representing the month: ";
  cin >> month;

  cout << "Enter a number representing the day: ";
  cin >> day;

  cout << "Enter the 4-digit year: ";
  cin >> year;

  cout << "The number of days that passed is: "
	   << daycount(month, day, year);

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

int daycount(int month, int day, int year)
{                
	return ((year-2000) * 365) + (month-1) * 30 + day;
}




