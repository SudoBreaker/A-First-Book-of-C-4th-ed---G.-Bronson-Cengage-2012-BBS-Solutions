// File: pgm6-1ex7b.cpp
// Description: 6.1 Exercise 7b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

void  displaySquaresAndCubes();  // function prototype 

int main()
{
  displaySquaresAndCubes();
  
  cin.ignore();  // needed for MS C++ Express 2010 programs

  return 0;
}

void  displaySquaresAndCubes()
{         
int num;

cout << "NUMBER    SQUARE    CUBE\n"
     << "------    ------    ----\n";

num = 1;
while (num < 11)
{
  cout << setw(3) << num << "        "
	    << setw(3) << num * num      << "      "
	    << setw(4) << num * num * num <<endl;
   num++;         // increment num
 }
  
 return;
}
