// File: pgm6-2ex9b.cpp
// Description: 6.2 Exercise 9b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int convertdays(int, int, int);  // function prototype

int main()
{
  char slash;  // to allow for the day being entered as MM/DD/YY
  int month, day, year;

  cout << "Enter a date in the format MM/DD/YY (such as 2/28/88): ";
  cin >> month >> slash >> day >> slash >> year;

  cout << "The date converted is: "
	   << convertdays(month, day, year);

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

int convertdays(int month, int day, int year)
{   
  return (year * 10000 + month * 100 + day);
}




