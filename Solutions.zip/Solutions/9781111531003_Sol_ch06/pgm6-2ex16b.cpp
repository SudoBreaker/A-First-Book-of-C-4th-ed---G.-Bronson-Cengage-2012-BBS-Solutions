// File: pgm6-2ex16b.cpp
// Description: 6.2 Exercise 16b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

void round(double, int);  // function prototype

int main()
{
  double num = 78.374625;
  int n = 2;
  round(num, n);

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void round(double num, int n)
{
	double newNum;
	int intPart;
	newNum = num * (pow(10.0,n));
	newNum = newNum + 0.5;
	intPart = int(newNum);
	newNum = double(intPart) / (pow(10.0,n));

	cout << num << " rounded to " << n << " decimal places is: "
         << newNum << endl;
	return;
}
