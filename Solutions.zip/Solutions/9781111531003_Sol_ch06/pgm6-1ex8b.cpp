// File: pgm6-1ex8b.cpp
// Description: 6.1 Exercise 8b
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

void selTab(int, int, int = 1);  // function prototype 

int main()
{
  selTab(6, 5, 2);
  selTab(6, 5);
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void selTab(int start, int num, int increment)
{         
	int i;

  	cout << "NUMBER    SQUARE    CUBE\n"
       		<< "------    ------    ----\n";

  	for(i = 0; i < num; i++, start+=increment)
  	{
    	cout << setw(3) << start << "        "
	   		<< setw(3) << start * start      << "      "
	   		<< setw(4) << start * start * start <<"\n";       
  	}
  
  	return;

}






