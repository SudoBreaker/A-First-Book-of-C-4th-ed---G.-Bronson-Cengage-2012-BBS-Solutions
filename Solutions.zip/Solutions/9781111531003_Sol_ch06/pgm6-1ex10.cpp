// File: pgm6-1ex10.cpp
// Description: 6.1 Exercise 10
// Programmer: G. Bronson
// Date: 8/26/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

void spherevol(double);  // function prototype

int main()
{
  double volume, radius;
  
  cout << "Enter the sphere's radius: ";
  cin >> radius;
 
  spherevol(radius);

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void spherevol(double radius)
{    
  double volume;

  volume = 4 * 3.1416 * pow(radius,3)/3;
      
  cout << "The sphere's volume is " << volume << endl;

  return;
}


