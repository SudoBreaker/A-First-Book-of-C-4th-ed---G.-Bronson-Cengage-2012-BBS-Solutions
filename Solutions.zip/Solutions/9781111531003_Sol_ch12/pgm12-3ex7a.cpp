// File: pgm12-3ex8a.cpp
// Description: 12.3 Exercise 8a
// Programmer: G. Bronson
// Date: 9/25/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <ctime>
#include <cmath>
using namespace std;

// Coin class
// pre-condition: 
//     srand() must be called once before the flip()method is called

class Coin

// class declarations section
{
  private:
    static int totalHeads;
    static int totalTails;
  public:
    Coin() {};   
    ~Coin() {};     
    void flip();
    static void percentages();
};

// static member definition
int Coin::totalHeads = 0;
int Coin::totalTails = 0;

// class implementations section
void Coin::flip()
{
  if( double(rand())/RAND_MAX < 0.5)
  {
    ++totalTails;
   // cout << "\nThe coin flip came up tails";
  }
   else
  {
    ++totalHeads;
    // cout << "\nThe coin flip came up heads";
  }
  return;
}

void Coin::percentages() // this method calculates the percentages of 
{                            // heads and tails and displays the result
  int tosses = totalHeads + totalTails;

  cout << "\nNumber of coin tosses: " << tosses;
  cout << "\n   " << totalHeads << " Heads      " 
       << totalTails << " Tails\n";
  
  cout << "\nHeads came up " << 100.0 * double(totalHeads)/tosses 
       << " percent of the time.";
  cout << "\nTails came up " << 100.0 * double(totalTails)/tosses  
       << " percent of the time.";
  return;
}  
  
int main()
{
  Coin *anewCoin;  // declare a pointer to an object of type Checkout 
  int i, howMany;          
    
  cout << "Enter the number of flips: ";
  cin >> howMany;

  srand(time(NULL));

 anewCoin = new Coin; // create a new object of type Coin  

 // flip the same coin howmany times
 for(i = 1; i <= howMany; i++)
  {      
    anewCoin->flip();    // flip the coin 
  }

  delete anewCoin;     // delete the object
  Coin::percentages();   // call the static member method

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
