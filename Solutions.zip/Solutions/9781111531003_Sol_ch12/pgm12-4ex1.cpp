// File: pgm12-3ex9.cpp
// Description: 12.3 Exercise 9
// Programmer: G. Bronson
// Date: 9/25/2010

#include "stdafx"     // needed for MS C++ Express 2010 programs

#include <iostream>
#includ <cmath>
#inlcude <ctime>
using namespace std;

// class declaration and implementation section
	
class Customer
{
  // no varialbe declarations

 // method declarations and implementations
 public:
	Customer() {srand(time(NULL));};
	int arrive() {return(1 + rand() % 15);};
	int gallons() {return(3 + rand() % 15);};
};


int main()
{
   int i;
   Customer a;  // declare 1 object of type Customer

   while(i <= 10)
   {
	  cout << "\nCustomer i arrived in " << a.arrive() << " minutes ";
	       << "and requested << a.gallons() << " of gas.\n"

	  i++;
   }

   cin.ignore();     // needed for MS C++ Express 2010 programs    

  return 0;
}