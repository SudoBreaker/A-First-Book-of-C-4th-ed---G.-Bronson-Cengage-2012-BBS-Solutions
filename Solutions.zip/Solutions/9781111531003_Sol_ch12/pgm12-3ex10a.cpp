// File: pgm12-3ex9a.cpp
// Description: 12.3 Exercise 9a
// Programmer: G. Bronson
// Date: 9/25/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs


#include <cmath>
#include <ctime>
#include <iostream>
using namespace std;

// class declaration and implementation section
	
class Customer
{
  // no varialbe declarations

 // method declarations and implementations
 public:
	Customer() {srand(time(NULL));};
	int arrive() {return(1 + rand() % 15);};
	int gallons() {return(3 + rand() % 15);};
	int grade() {return(1 + rand() % 3);};
};

#include <string>
using namespace std;

int main()
{
   int i = 1;
   string type;
   Customer a;  // declare 1 object of type Customer

   while(i <= 10)
   {
     switch(a.grade())
     {
	    case 1: type = "87 octane";
		         break;
	    case 2: type = "93 octane";
		         break;
	    case 3: type = "97 octane";
		         break;
     };

	  cout << "Customer " << i << "  arrived in " << a.arrive() << " minutes "
	       << "and requested " << a.gallons() << " gallons of " << type << " gas.\n";

	  i++;
   }

   cin.ignore();     // needed for MS C++ Express 2010 programs    

  return 0;
}