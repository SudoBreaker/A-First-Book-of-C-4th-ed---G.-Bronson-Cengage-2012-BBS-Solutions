// File: pgm12-1ex4a.cpp
// Description: 12.1 Exercise 4a
// Programmer: G. Bronson
// Date: 9/25/2010

#include "stdafx"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

const double PI = 2.0 * asin(1.0);

class Circle
{
  // data declaration section  
  protected:
    double radius;
  // methods declaration section
  public:
    Circle(double = 1.0);  // constructor
    double calcval();
};

// methods implementation section for Circle

Circle::Circle(double r)  // constructor
{
  radius = r;
}

// calculate the area of a Circle
double Circle::calcval(void)
{
  return(PI * radius * radius);
}

// the Cylinder class is derived from Circle
class Cylinder : public Circle
{
  //data declaration section  
  protected:
    double length;  // add one additional data member 
  // methods declaration section
  public:           // two additional member methods
    Cylinder(double r = 1.0, double l = 1.0) : Circle(r), length(l) {}
    double calcval();
};

// methods implementation section for Cylinder

double Cylinder::calcval(void)   // this calculates a volume
{
  return (length * Circle::calcval()); // note the base function call
}

// the Sphere class is derived from Circle
class Sphere : public Circle  // Sphere is derived from Circle
{
  public:           // two additional function members
    Sphere(double r = 1.0) : Circle(r) {} // base member initialization
    double calcval();
};

double Sphere::calcval(void)   // this calculates a volume for a sphere
{
  return (4.0/3.0 * radius * Circle::calcval()); // note the base function call
}
 
int main()
{
  Circle circle_1, circle_2(2);  // create two Circle objects
  Cylinder cylinder_1(3,4);      // create one Cylinder object
  Sphere sphere_1(4);            // create one Sphere object

  cout << "The area of circle_1 is " << circle_1.calcval() << endl;
  cout << "The area of circle_2 is " << circle_2.calcval() << endl;
  cout << "The volume of cylinder_1 is " << cylinder_1.calcval() << endl;
  cout << "The volume of sphere_1 is " << sphere_1.calcval() << endl;
  circle_1 = sphere_1;  // assign a Sphere to a Circle

  cout << "\nThe area of circle_1 is now " << circle_1.calcval() << endl;

  cin.ignore();     // needed for MS C++ Express 2010 programs
  
  return 0;
}            


