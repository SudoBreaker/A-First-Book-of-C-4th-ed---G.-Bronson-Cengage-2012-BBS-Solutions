// File: pgm12-1ex5b.cpp
// Description: 12.1 Exercise 5b
// Programmer: G. Bronson
// Date: 9/25/2010

#include "stdafx"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

const double PI = 2.0 * asin(1.0);

// class declaration
class Point
{
  protected:
    double x;
    double y;
  public:
    Point(double = 0.0, double = 0.0);  //constructor
    double distance(Point&);
	double area();
};

// implementation section
Point::Point(double xval, double yval)
{
  x = xval;
  y = yval;
}

double Point::distance(Point& b)
{
  return (sqrt(pow((x-b.x),2) + pow((y-b.y),2)));
}

double Point::area()
{
  return 0;
}

// class declaration for the derived Circle class
class Circle : public Point
{
  protected:
    double radius; // add an additional data member
  public:
    Circle(double = 0.0, double = 0.0, double = 1.0);  // constructor
    double distance(Circle&);
    double area();
};
 
// implementation section for Circle
Circle::Circle(double centerx, double centery, double r)  // constructor
{
  x = centerx;
  y = centery;
  radius = r;
}

double Circle::distance(Circle& b)
{
   return (Point::distance(b)); // note the base function call
}

double Circle::area()   // this calculates an area
{
  return (PI * pow(radius,2));
}

int main()
{
  Point a, b(4,4);
  Circle circ1, circ2(3,3,2);

  cout << "The distance between points is " << a.distance(b) << endl;
  cout << "The area of point a is " << a.area() << endl;
  cout << "The area of circ1 is " << circ1.area() << endl;
  cout << "The area of circ2 is " << circ2.area() << endl;
  cout << "The distance between circle centers is " << circ1.distance(circ2) << endl;

  cin.ignore();     // needed for MS C++ Express 2010 programs   
  
  return 0;
}            


