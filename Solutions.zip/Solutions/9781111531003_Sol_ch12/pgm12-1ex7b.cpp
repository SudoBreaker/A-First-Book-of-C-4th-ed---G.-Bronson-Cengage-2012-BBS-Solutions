// File: pgm12-14e78b.cpp
// Description: 12.1 Exercise 7b
// Programmer: G. Bronson
// Date: 9/25/2010

#include "stdafx"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

class Rectangle
{
protected:
	int length;
	int width;
 
public:
	Rectangle(int l = 1, int w = 0);
	int area();
};

Rectangle::Rectangle(int l, int w)
{
	length = l;
	width = w;
}

int Rectangle::area()
{
	return length * width;
}

class Box : public Rectangle
{
protected:
	int depth;

public:
	Box(int l = 1, int w = 1, int d = 1);
	int area();
	int volume();
};

Box::Box (int l, int w, int d)
{
	length = l;
	width = w;
	depth = d;
}

int Box::area()
{
	return (2 * (length * width)) + (2 * (length * depth)) + (2 * (width * depth));
}

int Box::volume()
{
	return length * width * depth;
}


int main()
{
  Rectangle r1, r2(4,4);
  Box b1, b2(3,3,2);

  cout << "The area of rectangle r1 is " << r1.area() << endl;
  cout << "The area of rectangle r2 is " << r2.area() << endl;
  cout << "The surface area of box b1 is " << b1.area() << endl;
  cout << "The surface area of box b2 is " << b2.area() << endl;
  cout << "The volume of box b1 is " << b1.volume() << endl;
  cout << "The volume of box b2 is " << b2.volume() << endl;

  cin.ignore();     // needed for MS C++ Express 2010 programs     
  
  return 0;
}            


