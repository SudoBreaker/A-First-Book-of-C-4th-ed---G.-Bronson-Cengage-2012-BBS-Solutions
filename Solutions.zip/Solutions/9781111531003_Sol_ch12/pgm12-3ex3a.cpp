// File: pgm12-3ex3a.cpp
// Description: 12.3 Exercise 3a
// Programmer: G. Bronson
// Date: 9/25/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

class Checkout

// class declarations section
{
  private:
    int numItems;
    double arrivalTime;

  public:
    Checkout();    // the constructor
    // the following is an inline destructor
    ~Checkout() {cout << "!!!! This Customer object has been deleted !!!!\n";};       
    void showObject();    
    void getItems(){return;};  // inline do-nothing methods 
    void getTime() {return;};  // will be used in Program 12.5
};

// class implementations section

Checkout::Checkout() // constructor
{
  cout << "\n**** A new Customer object has been created ****\n";
  numItems = 5;
  arrivalTime = 2.5;
}

void Checkout::showObject()
{
   cout << "     For this object:\n";
   cout << "    numItems = " << numItems 
        << "    arrivalTime = " << arrivalTime << endl;
   return;
}

int main()
{
  Checkout *anotherTrans;  // pointer to a Checkout object
  int i, howMany;
  
  cout << "Enter the number of transactions to be created: ";
  cin >> howMany;

  for(i = 1; i <= howMany; i++)  
  {    
    anotherTrans = new Checkout; // create a new object of type Checkout    
    
    // display the address of the created object
    cout << "The memory address of this object is: " << anotherTrans << endl;     
    
    anotherTrans->showObject();  // display the contents this object
      
    //delete anotherTrans; // delete the object
	cout << "  ";
  }

  cin.ignore(); cin.ignore();  // needed for MS C++ Express 2010 programs

  return 0;
}