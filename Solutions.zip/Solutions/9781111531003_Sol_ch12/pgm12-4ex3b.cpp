// File: pgm12-4ex3b.cpp
// Description: 12.4 Exercise 3b
// Programmer: G. Bronson
// Date: 9/25/2010

#include "stdafx"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

class Car
{
  private:
    double engineSize;
	char bodyStyle;
	int colorCode;
	char *vinPtr;
  public:
    Car(double = 0.0, char = 'X', int = 0, char * = NULL);  //constructor
	void operator=(Car&);
	void showData(void);
};

// class implementation

Car::Car(double eng, char style, int cd, char *pt)
{
  engineSize = eng;
  bodyStyle = style;
  colorCode = cd;
  if(pt)
  {
	vinPtr = new char[strlen(pt) + 1];
	strcpy(vinPtr, pt);
  }
  else
	  vinPtr = NULL;
  
}

void Car::showData()
{
	cout << "\nThe values for this object are: " << endl
	     << "     Engine size: " << engineSize << endl
		 << "     Body style: " << bodyStyle << endl
		 << "     Color code: " << colorCode << endl;
	if(vinPtr)
		cout << "     VIN: " << vinPtr << endl;
	else
		cout << "     VIN: NULL" << endl;

  return;
}

void Car::operator=(Car& oldCar)
{
  engineSize = oldCar.engineSize;
  bodyStyle = oldCar.bodyStyle;
  colorCode = oldCar.colorCode;
  if(vinPtr != NULL)  // check that it exists
    delete(vinPtr);           // release existing memory
  vinPtr = new char[strlen(oldCar.vinPtr) + 1];  // allocate new memory
  strcpy(vinPtr, oldCar.vinPtr);  // copy the title
}


int main()
{
  Car car1(250.0, 'S', 52, "ABC567YYY"), car2;

  car1.showData();
  car2.showData();
  car2 = car1;
  car2.showData();

  cin.ignore();     // needed for MS C++ Express 2010 programs   

  return 0;
}