// File: pgm12-2ex1b.cpp
// Description: 12.2 Exercise 1b
// Programmer: G. Bronson
// Date: 9/25/2010

#include "stdafx"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

// this is the base class
class One
{
  protected:
    double a;
  public:
    One(double = 2.0);   // constructor
    virtual double f1(double);   // a member method
    double f2(double);   // another member method
};

// methods implementation section for class One
One::One(double val)   // constructor
{
  a = val;
}

double One::f1(double num)  // a member method
{
  return(num/2);
}

double One::f2(double num)  // another member method
{
  return( pow(f1(num),2) );  // square the result of f1()
}


// this is the derived class
class Two : public One
{
  public:
    virtual double f1(double);    // this overrides class One's f1()
};

// methods implementation for class Two
double Two::f1(double num)
{
  return(num/3);
}

int main()
{
  One object_1;  // object_1 is an object of the base class
  Two object_2;  // object_2 is an object of the derived class

     // call f2() using a base class object call
  cout << "The computed value using a base class object call is "
       << object_1.f2(12) << endl;

    // call f2() using a derived class object call
  cout << "The computed value using a derived class object call is "
       << object_2.f2(12) << endl;

  cin.ignore();     // needed for MS C++ Express 2010 programs    
  
  return 0;
}            


