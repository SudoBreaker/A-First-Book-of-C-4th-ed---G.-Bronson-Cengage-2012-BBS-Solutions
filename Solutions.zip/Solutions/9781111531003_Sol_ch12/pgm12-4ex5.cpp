// File: pgm12-4ex5.cpp
// Description: 12.4 Exercise 5
// Programmer: G. Bronson
// Date: 9/25/2010

#include "stdafx"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

class Book
{
  private:
    char *title;   // a pointer to a book title
  public:
    Book(char * = '\0');  // constructor
	Book(Book&);  // constructor
    void showtitle();   // display the title
	void setTitle(char *);
	void operator=(Book&);
};

// class implementation

Book::Book(char *strng)
{
  if(strng)
  {
	title = new char[strlen(strng)+1];  // allocate memory
	strcpy(title,strng);                // store the string
  }
  else
	  title = NULL;
}

Book::Book(Book& oldbook)
{
  title = new char[strlen(oldbook.title) + 1];  // allocate new memory
  strcpy(title, oldbook.title);  // copy the title
}


void Book::showtitle()
{
  cout << title << endl;

  return;
}

void Book::setTitle(char *strng)
{
  title = new char[strlen(strng)+1];  // allocate memory
  strcpy(title,strng);                // store the string

  return;
}

void Book::operator=(Book& oldbook)
{
  if(title != NULL)  // check that it exists
    delete(title);           // release existing memory
  title = new char[strlen(oldbook.title) + 1];  // allocate new memory
  strcpy(title, oldbook.title);  // copy the title
}


int main()
{
  const int MAXCHARS = 100;

  Book books[5];
  char title[MAXCHARS];
  int i;

  for(i = 0; i < 5; i++)
  {
	  cout << "Enter a title for book " << i+1 << " : ";
	  cin.getline(title, MAXCHARS);
	  books[i].setTitle(title);
  }

  for(i = 0; i < 5; i++)
  {
	  books[i].showtitle();
  }

  cin.ignore();     // needed for MS C++ Express 2010 programs     

  return 0;
}