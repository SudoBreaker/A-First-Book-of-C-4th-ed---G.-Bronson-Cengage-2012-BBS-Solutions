
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{	
	double num1, num2, num3, num4, avg;
	cout << "Enter a number: ";
	cin >> num1;
	cout << "Enter a second number: ";
	cin >> num2;
	cout << "Enter a third number: ";
	cin >> num3;
	cout << "Enter a fourth number: ";
	cin >> num4;
	avg = (num1 + num2 + num3 + num4)/4;	
	cout << "The average is: " 
             << avg << endl;
	
	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
