     
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	double speed = 58.0, dist = 183.67, time;
	time = dist/speed;
	cout << "The elapsed time for the trip is " << time 
		 << " hours." << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
