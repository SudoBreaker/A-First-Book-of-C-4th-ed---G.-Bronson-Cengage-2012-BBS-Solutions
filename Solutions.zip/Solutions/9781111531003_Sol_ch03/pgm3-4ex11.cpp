
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  double num, root;

  cout << "Please enter a number ";
  cin >> num;
  root = pow(num, (1.0/4.0));
  cout << "\nThe fourth root of the number is " 
       << root << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}    
