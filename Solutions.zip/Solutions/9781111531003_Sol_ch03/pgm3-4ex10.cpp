#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	double number, root;
	cout << "Enter a number: ";
	cin >> number;
	root = sqrt(number);
	cout << "The square root of the number is: "
             << root << endl; 
	 
	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
