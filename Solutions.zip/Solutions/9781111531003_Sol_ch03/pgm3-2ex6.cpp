#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  double x1 = 3.0, y1 = 7.0;
  double x2 = 8.0, y2 = 12.0;
  double xmid, ymid;

  xmid = (x1 + x2)/2;
  ymid = (y1 + y2)/2;
  cout << setiosflags(ios::fixed) << setprecision(2);
  cout << "The x coordinate of the midpoint is " << setw(6)
       << xmid << endl;
  cout << "The y coordinate of the midpoint is " << setw(6)
       << ymid << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
