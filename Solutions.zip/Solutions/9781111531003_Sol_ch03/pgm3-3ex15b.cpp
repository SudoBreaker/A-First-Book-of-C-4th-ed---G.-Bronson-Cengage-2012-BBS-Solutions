
#include <iomanip>
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;
int main()
{
  double a, b, c;

  a = 1.674;
  b = 1.322;
  cout << setiosflags(ios::fixed) << setprecision(2); 
  cout << a << endl;
  cout << b << endl;
  cout << "----\n";
  c = int(a*100)/100.0 + int(b*100)/100.0;
  cout << c << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

