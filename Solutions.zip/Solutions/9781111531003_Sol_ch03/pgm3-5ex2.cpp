
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;
    
int main()
{
    double fahren, celsius;
    const double FACTOR = 5.0/9.0;

    cout << "Enter a temperature in degrees Fahrenheit: ";
    cin >> fahren;
    celsius = FACTOR * (fahren - 32.0);
    cout << "\nThe equivalent Celsius temperature is "
         << celsius << endl;                       
   
    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
