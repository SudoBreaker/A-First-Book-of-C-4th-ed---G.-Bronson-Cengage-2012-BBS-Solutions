     
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	double total;
	total = 12 * .50 + 20 * .25 + 32 * .10 + 45 * .05 + 27 * .01;
	cout << "The total amount is $"  << total << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
