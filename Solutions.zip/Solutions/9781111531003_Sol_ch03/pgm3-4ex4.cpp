#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	double radius, area;

	cout << "Enter the radius of a circle: ";
	cin >> radius;
	area = 3.1416 * pow(radius,2);
	cout << "The area of the circle is: " 
             << area << endl;  
	
	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
