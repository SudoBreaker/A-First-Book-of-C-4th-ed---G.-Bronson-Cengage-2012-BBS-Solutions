#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{

  int dollars, q, d, n, p;
  double check = 6.07;
  double paid = 10.00;
  double change;

  change = paid - check;
  // determine the number of pennies in the change
  change = (paid - check) * 100;
  // determine the number of dollars in the change
  dollars = (int) (change/100);
  change = change - 100 * dollars;  // subtract out the dollar bills
  q = change / 25;  // determine the number of quarters
  change = change - 25 * q;  // subtract out the quarters
  d = change / 10;  // determine the number of dimes
  change = change - 10 * d; // subtract out the dimes
  n = change / 5;   // determine the number of nickels
  p = change - 5 * n;  //subtract out the nickels

  
  cout <<  setiosflags(ios::fixed) << setprecision(2); 
  cout << "For a check of $" << check << endl;
  cout << "Paid with $" << paid << endl;
  cout << "The change is\n";
  cout << dollars << " dollar bills\n"
	   << q << " quarters\n"
	   << d << " dimes\n"
	   << n << " nickels\n"
	   << p << " pennies\n";
	  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
