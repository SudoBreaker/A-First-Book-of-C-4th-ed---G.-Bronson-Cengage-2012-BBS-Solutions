
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	const double HEATFACTOR = 5.6697e-8;
      double emissivity, temp;

	
	cout << "Please enter the average surface temperature (in degrees Celsius): ";
	cin >> temp;
	cout << "The heat radiated by the object is ";
	cout << HEATFACTOR*pow(temp,4) 
           << " watts/squared meters\n";

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}

