#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main() 
{	
	double num1, num2, num3;

	cout << "Please type in a number: ";
	cin >> num1;
	cout << "Please type in another number: ";
	cin >> num2;
	cout << "Before swapping: " << num1 << " and " << num2 << "\n";
	num3 = num1;
	num1 = num2;
	num2 = num3;
	cout << "After swapping: " << num1 << " and " << num2 << "\n";

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
