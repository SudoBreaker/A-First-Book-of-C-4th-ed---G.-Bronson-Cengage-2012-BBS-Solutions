
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	cout << "The estimated world population in the year 2012 is "
             << 7.5 * exp(0.02*(2012-2010)) << " billion" << endl;
   	cout << "The estimated world population in the year 2020 is "
             << 7.5 * exp(0.02*(2020-2010)) << " billion" << endl;
        	
     cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
