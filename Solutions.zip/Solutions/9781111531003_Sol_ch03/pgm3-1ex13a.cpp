     
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	double distance;
	double miles = 2.36;
	distance = miles * 5280;
	cout << "\nThe distance is " << distance << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;

}
