
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	cout << "The 20 foot ladder touches the building at "
	     << 20 * sin(85 * (3.1416/180))
           << " feet" << endl;   //need to convert degrees to radians
	cout << "The 25 foot ladder touches the building at "
             << 25 * sin(85 * (3.1416/180))
             << " feet" << endl;   //need to convert degrees to radians                

     cin.ignore();   // needed for MS C++ Express 2010 programs

     return 0;

}
