
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;
const double PI = 3.14159;

int main()
{
   double radius, distance, volume;

   cout << "\nEnter radius: ";
   cin >> radius;
   cout << "\nEnter distance: ";
   cin >> distance;

   volume = PI * radius* radius * ( 200 - distance );

   cout << "\nFor a radius of: " << radius;
   cout << "\nAnd a distance from the top of the oil: " << distance;
   cout << "\nThe volume of oil is: " << volume;

   cin.ignore();   // needed for MS C++ Express 2010 programs

   return 0;
}
