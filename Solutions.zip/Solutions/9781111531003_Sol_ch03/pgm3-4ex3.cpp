     
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>  
using namespace std;

int main()
{
	double length = 0, width = 0, depth = 0;

	cout << "\nEnter the length of the swimming pool:  ";
	cin >> length;
	cout << "\nEnter the width of the swimming pool:  ";
	cin >> width;
	cout << "\nEner the average depth of the swimming pool:  ";
	cin >> depth;
	cout << "\nThe volume of the pool is " 
           << length * width * depth << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;

}

	
