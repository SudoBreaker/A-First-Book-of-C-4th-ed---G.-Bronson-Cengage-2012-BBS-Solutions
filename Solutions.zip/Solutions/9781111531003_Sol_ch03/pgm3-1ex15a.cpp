     
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	int sum = 0;
	int terms = 100;
	int startnum = 1;
	int difference = 1;
	sum = (terms/2) * (2 * startnum + (terms-1) * difference);
	cout << "\nThe sum of he numbers from 1 to 100 is " << sum << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
