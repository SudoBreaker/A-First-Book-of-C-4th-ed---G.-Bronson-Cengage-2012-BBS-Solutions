#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  double a;
  double b;
  double area;
  a = 2.5;
  b = 6.4;

  area = 3.1416 * a * b;
  cout << "The area of an ellipse with a minor axis of "
       << a << " and a major axis of " << b << " is: " << area << endl;  
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
