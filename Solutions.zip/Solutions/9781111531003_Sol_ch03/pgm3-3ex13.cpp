
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
  double half, k;
  k = 0.00012;
  half = log(2.0) / k;
  cout << fixed << setprecision(5);  cout << "\nThe half-life with k = " << k << " is "
       << half << endl;
  k = 0.00026;
  half = log(2.0) / k;
  cout << fixed << setprecision(5);
  cout << "\nThe half-life with k = " << k << " is "
       << half << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
