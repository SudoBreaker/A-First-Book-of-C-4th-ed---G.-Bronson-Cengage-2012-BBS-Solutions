
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  double x = 1.2;
  double w = 13;
  double len = 11.21;
  double m;
  m = x * w * (len - x) / len;
  cout << "The maximum bending moment is " << setw(9)
       << fixed << setprecision(4) << m << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
