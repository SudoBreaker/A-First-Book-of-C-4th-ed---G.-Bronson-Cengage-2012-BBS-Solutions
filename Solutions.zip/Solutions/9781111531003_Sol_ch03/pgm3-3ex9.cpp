
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{  
  double height, velocity, theta, mph, angle;
  mph = 5.0;
  angle = 60.0;
  
  velocity = mph * 1609.0 / 3600.0;
  theta = angle * 3.1416 / 180.0;
  height = 0.5 * pow(velocity, 2.0) * pow(sin(theta), 2.0) / 9.8;
 
  cout << fixed << setprecision(2);
  cout << "For a speed of " << mph 
       << " miles per hour and an angle of " 
       << angle << " degrees" << endl;
  cout << "The maximum height reached is " 
       << height << " meters" << endl;
  
  mph = 7.0;
  angle = 45.0;
  velocity = mph * 1609.0 / 3600.0;
  theta = angle * 3.1416 / 180.0;
  height = 0.5 * pow(velocity, 2.0) * pow(sin(theta), 2.0) / 9.8;
  
  cout << fixed << setprecision(2);
  cout << "For a speed of " << mph 
       << " miles per hour and an angle of " 
       << angle << " degrees " << endl;
  cout << "The maximum height reached is " 
       << height << " meters" << endl;
   
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
