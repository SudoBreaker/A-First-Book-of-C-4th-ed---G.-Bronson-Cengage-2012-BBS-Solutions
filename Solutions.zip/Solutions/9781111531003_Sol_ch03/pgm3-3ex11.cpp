#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main() 
{
	double x,y, distance;

	cout << "Enter the number of miles East: ";
	cin >> x;
	cout << "Enter the number of miles North: ";
	cin >> y;

	distance = sqrt(x*x + y*y);
	
     cout << "The shortest distance to drive across the fields"
		 << " to Joe's farm is " << setiosflags(ios::fixed)
		 << setprecision(2) << distance << " miles\n";

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
