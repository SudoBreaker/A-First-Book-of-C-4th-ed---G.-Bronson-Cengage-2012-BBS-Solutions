
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int main()
{
	double miles, gas, mpg;

	cout << "Enter the miles driven: ";
	cin >> miles;
	cout << "Enter the gallons of gas used: ";
	cin >> gas;
	mpg = miles / gas;
	cout << "The miles per gallon is: " 
	     << setprecision(2) << fixed << mpg << endl; 
	double liters, km, kml;

	// 1 gallon = 3.7854 liters 
	// 1 mile = 1.6093 kilometers

	km = miles * 1.6093;
	liters = gas * 3.7854;
	kml = km / liters;
	cout << "Kilometers driven: " << setprecision(2) 
           << fixed <<   km << endl;
	cout << "Liters of gas used: " << setprecision(2) 
           << fixed << liters << endl;
	cout << "Km/L: " << setprecision(2) << fixed << kml << endl;
 
	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
