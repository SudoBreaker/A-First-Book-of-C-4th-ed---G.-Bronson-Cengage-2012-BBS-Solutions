
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
  double remaining, orig, n;
  n = 1000;
  orig = 100;
  remaining = orig * exp(-0.00012 * n);
  cout << fixed << setprecision(2);
  cout << "\nThe amount of radioactive material remaining after "
       << n << " years is " << remaining << endl;
  n = 275;
  orig = 250;
  remaining = orig * exp(-0.00012 * n);
  cout << fixed << setprecision(2);
  cout << "\nThe amount of radioactive material remaining after "
       << n << " years is " << remaining << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
