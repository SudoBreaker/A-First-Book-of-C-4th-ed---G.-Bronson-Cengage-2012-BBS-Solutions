
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	cout << "The fourth root of 81.0 is: " 
           << sqrt(sqrt(81.0))<< endl;
	cout << "The fourth root of 1,728.8964 is: " 
           << sqrt(sqrt(1728.8964)) << endl;
  	
    	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
