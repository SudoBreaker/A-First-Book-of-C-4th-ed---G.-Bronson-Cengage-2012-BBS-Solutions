#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  cout << "The distance between (7,12) and (3,9) is: ";
  double run = 7 - 3;
  double rise = 12 - 9;
  cout << sqrt(pow(run,2) + pow(rise,2))<< endl;
  cout << "The distance between (-12,-15) and (22,5) is: ";
  run = -12 - 22;
  rise = -15 - 5;
  cout << sqrt(pow(run,2) + pow(rise,2)) << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
