
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
	double num;

	cout << "Please type in a number: ";
	cin >> num;
      cout << "This is your number: " << num << "\n";

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
