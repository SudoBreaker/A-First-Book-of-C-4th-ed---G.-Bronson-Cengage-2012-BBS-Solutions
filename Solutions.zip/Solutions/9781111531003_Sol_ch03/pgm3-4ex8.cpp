
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
   double length, width, lplusw, ltimesw, depth, peri, vol, area;

   cout << "\nEnter the length: ";
   cin >> length;
   cout << "\nEnter the width: ";
   cin >> width;
   lplusw = length + width;
   ltimesw = length * width;
   
   cout << "\nEnter the average depth: ";
   cin >> depth;
   peri = 2 * lplusw;
   vol = ltimesw * depth;
   area = peri * depth + ltimesw;
   cout << "\n\nThe perimeter is " << peri << endl;
   cout << "The volume is " << vol << endl;
   cout << "The underground surface area is " << area << endl;
   
   cin.ignore();   // needed for MS C++ Express 2010 programs

   return 0;
}
