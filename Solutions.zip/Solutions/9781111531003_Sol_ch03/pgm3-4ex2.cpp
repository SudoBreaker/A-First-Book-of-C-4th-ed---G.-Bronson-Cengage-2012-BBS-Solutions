     
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>  
using namespace std;

int main()
{
	double length = 0, width = 0;
	cout << "\nEnter the length of the room:  ";
	cin >> length;
	cout << "\nEnter the width of the room:  ";
	cin >> width;
	cout << "\nThe area of the room is " << length * width << endl;

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}

	
