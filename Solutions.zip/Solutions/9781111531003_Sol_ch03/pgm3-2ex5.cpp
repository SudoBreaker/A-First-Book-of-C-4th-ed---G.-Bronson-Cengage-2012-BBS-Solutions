
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  double x1 = 3;
  double y1 = 7;
  double x2 = 8;
  double y2 = 12;
  double slope;
  slope = (y2 - y1) / (x2 - x1);
  cout << "The value of the slope is " 
       << setw(6) << fixed << setprecision(2) << slope << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
