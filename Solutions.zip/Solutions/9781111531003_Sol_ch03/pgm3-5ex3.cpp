
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const double PRIME = 0.04;  // prime interes rate
  double prime, amount, interest;
  
  cout << "Enter the amount: ";
  cin  >> amount;
  interest = PRIME * amount;
  cout << "The interest earned is "
       << interest << " dollars" << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
