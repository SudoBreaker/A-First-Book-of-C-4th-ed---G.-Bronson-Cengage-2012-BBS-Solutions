#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	double celsius, temp;

	cout << "Enter the temperature in degrees Celsius: ";
	cin >> celsius;
	temp = (9.0 / 5.0) * celsius + 32.0;
	cout << "The temperature converted to Fahrenheit is: " 
             << temp << endl;  
        
	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
