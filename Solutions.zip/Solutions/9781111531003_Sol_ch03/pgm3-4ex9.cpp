
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	double a, b, c, x, value;

	cout << "This program will compute the value of ax^2 + bx + c\n";
	cout << "Enter the coefficient of the x squared term: ";
	cin >> a;
	cout << "Enter the coefficient of the x term: ";
	cin >> b;
	cout << "Enter the coefficient of the last term: ";
	cin >> c;
	cout << "Enter the value of x: ";
	cin >> x;
	value = pow(x,2)*a + b*x + c;
	cout << "The value of the polynomial is: " 
             << value << endl;   
	
	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
