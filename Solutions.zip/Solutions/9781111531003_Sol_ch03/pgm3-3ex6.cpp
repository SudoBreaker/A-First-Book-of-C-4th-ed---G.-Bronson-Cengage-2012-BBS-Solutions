
#include "stdafh.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main() 
{
	const double PI = 3.1416;
	double a = 2.5, b = 6.4;
	cout 	<< "The circumference of an ellipse with minor radius " 
		<< a << " and major radius " << b << " is " 
		<< PI*sqrt(pow((a+b),2)) << "\n"; 

	cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
