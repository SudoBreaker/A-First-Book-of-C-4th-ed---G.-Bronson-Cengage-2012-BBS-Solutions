/// File: pgm16-3ex5b.cpp
// Description: 16.3 Exercise 5b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <iomanip>
using namespace std;

struct Date
{
	int month;
	int day;
	int year;
};

long days(Date);

int main()
{
  Date current;
  long num;

  cout << "Enter the current month: ";
  cin >> current.month;

  cout << "\nEnter the current day: ";
  cin >> current.day;

  cout << "\nEnter the current 4-digit year: ";
  cin >> current.year;

  num = days(current);

  cout << "\nThe number of days since the turn of the"
	  << " century is: " << num;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

  return 0;
}

long days(Date temp)
{
	long actDays;
	int daycount[12] = {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};
	int leapcount, testyear;
	bool isLeap = false;

	// determine how many leap years there were
	// prior to the last year

	leapcount = 0;
	for(testyear = 1900; testyear < temp.year; testyear++)
	{
	   if(testyear % 4 == 0 && testyear % 100 !=0)
		 isLeap = true;
	   else if(testyear % 400 == 0)
		 isLeap = true;
	   if(isLeap) leapcount++; 
	    isLeap = false; // reset the flag
	}
	
	// check the last year
	if(temp.year % 4 == 0 && temp.year % 100 != 0)
	  isLeap = true;
	else if (temp.year % 400 == 0)
	  isLeap = true;
	if(isLeap && temp.month > 2 ) ++leapcount;
	
	actDays = (temp.day-1) + daycount[temp.month - 1] + 365*(temp.year-1900) + leapcount;
	return actDays;
}
