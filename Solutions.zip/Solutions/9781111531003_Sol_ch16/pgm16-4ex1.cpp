// File: pgm16-4ex1.cpp
// Description: 16.4 Exercise 1
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

const int MAXNAME = 30;
const int MAXTEL = 16;

struct TeleType
{
	char name[MAXNAME];
	char phoneNo[MAXTEL];
};

void populate(TeleType *);
void dispOne(TeleType *);

int main()
{
  char key;
  TeleType *recPoint;

  cout << "Do you wish to create a new record (respond with y or n): ";
  key = cin.get();

  if(key == 'y')
  {
	  key = cin.get();
	  recPoint = new TeleType;
	  if (recPoint == NULL)
	  {
		 cout << "There is not sufficiet memory to allocate a record\n";
		 exit(1);
	  }
	  else
	  {
	    populate(recPoint);
	    dispOne(recPoint);
	  }
  }
  else
	  cout << "\nNo record has been created.";

  cin.ignore(); // needed for MS C++ Express 2010 users

  return 0;
}

void populate(TeleType *record)
{
	cout << "Enter a name: ";
	cin.getline(record->name, MAXNAME);
	cout << "Enter the phone number: ";
	cin.getline(record->phoneNo, MAXTEL);

	return;
}

void dispOne(TeleType *contents)
{
	cout << "\nThe contents of the record just created is: "
		<< "\nName: " << contents->name
		<< "\nPhone Number: " << contents->phoneNo << endl;

	return;
}

