/// File: pgm16-4ex3.cpp
// Description: 16.4 Exercise 3
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <string>
using namespace std;

struct TeleType
{
  string name;
  string phoneNo;
  TeleType *link;  // a pointer to a TeleType structure
};

void dispOne(TeleType *);  // pass an address to a TeleType structure
void insert(TeleType *);
void populate(TeleType *);
int main()
{

  TeleType *head;   // a pointer to a TeleType structure
  TeleType *addr; // another poiner to a TeleType structure

  // create three structures
  TeleType t1 = {"Acme, Sam", "(555) 898- 2392"};
  TeleType t2 = {"Dolan, Edith", "(555) 682- 3104"};
  TeleType t3 = {"Lanfrank, John", "(555) 718- 4581"};

   // link all the objects
   head =&t1;  // have the head link point to the first record;
   t1.link = &t2;
   t2.link = &t3;
 
   // retrieve each object with the link from the previous object
   cout << "The original list is:";
   addr = &t1;  // set the first address
   while(addr != NULL)
   {
	   dispOne(addr);
	   addr = addr->link;
   }
   
   insert(&t2);   // insert a new structure after the 2nd one
 
  
   cout << "\nThe new list is:";
   addr = &t1;  // set the first address
   while(addr != NULL)
   {
	   dispOne(addr);
	   addr = addr->link;
   }
   
   cin.ignore();   // needed for MS C++ Express 2010 users

   return 0;
}

void insert(TeleType *current)
{
	TeleType *record;  // a pointer to a structure of type TeleType

	record = new TeleType;   // create a new structure
	cout << "\n\n";
	populate(record);
	record->link = current->link;  // set the new structure's link to the following structure
	current->link = record;        // set the prior structure's link to the new structure

	return;
}

void populate(TeleType *record)
{
    cout << "Enter a name for the new structure: ";
	getline(cin,record->name);
	cout << "Enter the phone number for the new structure: ";
	getline(cin,record->phoneNo);

	return;
}

void dispOne(TeleType *contents)
{
	cout << "\n     Name: " << contents->name
		<<  "\n     Phone Number: " << contents->phoneNo;

	return;
}