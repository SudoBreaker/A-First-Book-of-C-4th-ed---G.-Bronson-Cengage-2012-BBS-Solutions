// File: pgm16-3ex4b.cpp
// Description: 16.3 Exercise 4b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <iomanip>
using namespace std;

struct Date
{
	int month;
	int day;
	int year;
};

Date larger(Date date1, Date date2);

int main()
{
  Date a = {10, 9, 2006};
  Date b = {11, 3, 2006};

  cout << "Date a: " << a.month << '/';
  cout << a.day << '/' << a.year << endl << endl;

  cout << "Date b: " << b.month << '/';
  cout << b.day << '/' << b.year << endl << endl;

  Date c = larger(a, b);

  cout << "The larger of these two Dates is " << c.month << '/';
  cout << c.day << '/' << c.year << endl << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

  return 0;
}

Date larger(Date date1, Date date2)
{
	// Assume that all months have 30 days and all years have 365 days
	long d1 = date1.day + 30*date1.month + 365*date1.year;
	long d2 = date2.day + 30*date2.month + 365*date2.year;

	if (d1 > d2)
		return date1;
	else
		return date2;
}

