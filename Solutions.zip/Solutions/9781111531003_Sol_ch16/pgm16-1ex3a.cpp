// File: pgm16-1ex3a.cpp
// Description: 16.1 Exercise 3a
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
using namespace std;

int main()
{
  struct Date
  {
	  int month;
	  int day;
	  int year;
  };

  Date current;

  cout << "Enter the current month: ";
  cin >> current.month;

  cout << "\nEnter the current day: ";
  cin >> current.day;

  cout << "\nEnter the current year: ";
  cin >> current.year;

  cout << "\nThe date entered is: " << current.month
	   << "/" << current.day << "/" << current.year;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

  return 0;
}

