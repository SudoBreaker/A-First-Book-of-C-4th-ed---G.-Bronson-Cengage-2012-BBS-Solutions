// File: pgm16-4ex2.cpp
// Description: 16.4 Exercise 2
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <string>
using namespace std;

struct TeleType
{
  string name;
  string phoneNo;
};

void populate(TeleType *);
void dispOne(TeleType *);
void modify(TeleType *);

int main()
{
  char key;
  TeleType *recPoint;

  cout << "Do you wish to create a new record (respond with y or n): ";
  key = cin.get();
  cin.ignore();  // ignore the Enterkey

  if(key == 'y')
  {
	  recPoint = new TeleType;
	  if(recPoint == NULL)   // insufficient storage
	  {
		  cout << "Insufficient storage available!" << endl;
		  exit(0);
	  }
	  populate(recPoint);
	  
	  cout << "\nThe contents of the record just created is:"; 
	  dispOne(recPoint);
  }
  else
  {
	  cout << "\nNo record has been created.";
	  cin.ignore();
	  exit(1);
  }
  cout << "\nDo you wish to modify this record (respond with y or n): ";
  key = cin.get();
  cin.ignore();  // ignore the Enterkey

  if(key == 'y')
    modify(recPoint);
  
  cin.ignore();  // needed for MS C++ Express 2010 users

  return 0;
}

void modify(TeleType *addr)
{
  cout << "\nThe current structure members are: ";
  dispOne(addr);
  cout << endl;
  populate(addr);
  cout << "\nThe structure members are now: ";
  dispOne(addr);

  return;
}

void populate(TeleType *record)
{
	cout << "Enter a name: ";
	getline(cin,record->name);
	cout << "Enter the phone number: ";
	getline(cin,record->phoneNo);

	return;
}

void dispOne(TeleType *contents)
{
	cout << "\nName: " << contents->name
		<< "\nPhone Number: " << contents->phoneNo << endl;

	return;
}

