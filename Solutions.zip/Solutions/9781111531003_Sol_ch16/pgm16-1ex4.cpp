// File: pgm16-1ex4.cpp
// Description: 16.1 Exercise 4
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <iomanip>
using namespace std;

const int MAXCHARS = 10;
const int STOCKS = 5;
int main()
{

	struct StockData
	{
		char name[MAXCHARS];
		double earn;
		double ratio;
	};

	StockData stock;    // define a structure variable named stock
	int count;

	for(count = 1; count <= STOCKS; ++count)
	{
		cout << "\nEnter stock name: ";
		cin.getline(stock.name, MAXCHARS);
		cout << "Enter estimated earnings per share: ";
		cin  >> stock.earn;
		cout << "Enter price to earnings ratio: ";
		cin  >> stock.ratio;
		cout << "The anticipated price for " << stock.name
			 << " is $" << setiosflags(ios::showpoint|ios::fixed)
		     << setw(4) << setprecision(2)
		     << (stock.earn * stock.ratio) << endl;
	}  

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

  return 0;
}

