// File: pgm16-2ex3.cpp
// Description: 16.2 Exercise 3
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
using namespace std;

const int MAXCHARS = 10;
const int MONTHS = 12;

struct MonthDays
{
	char name[MAXCHARS];
	int days;
};

int main()
{
	MonthDays convert[MONTHS] = { "January", 31, "February", 28,"March", 31,
								  "April", 30, "May", 31, "June", 30,
								  "July", 31, "August", 31, "September", 30,
								  "October", 31, "November", 30, "December", 31 };
    int i;

	cout << "Enter the number of a month: ";
	cin >> i;
    cout << '\n' << convert[i-1].name << " has "
		<< convert[i-1].days << " days";
    cout << endl;

    cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

    return 0;
}

