// File: pgm16-2ex5b.cpp
// Description: 16.2 Exercise 5b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <iomanip>
using namespace std;

const int MAXCHARS = 15;
const int NUMCARS = 5;

struct CarRec
{
	int num;
	int miles;
	int gallons;
};

int main()
{
   CarRec cars[NUMCARS];
   int i;

   for(i = 0; i < NUMCARS; ++i)
   {
     cout << "\nEnter car number: ";
     cin  >> cars[i].num;

     cout << "Enter car miles: ";
     cin  >> cars[i].miles;

     cout << "Enter car gallons: ";
     cin  >> cars[i].gallons;
   }

   cout << "\n\n  Number        MPG\n";
   cout << "---------------------\n";

   for( i = 0; i < NUMCARS; ++i)
	   cout << setiosflags(ios::right)
			<< setw(6) << cars[i].num
			<< setiosflags(ios::showpoint | ios::fixed) << "     "
			<< setw(8) << setprecision(2)
			<< (cars[i].miles * cars[i].gallons) << endl;  

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

  return 0;
}

