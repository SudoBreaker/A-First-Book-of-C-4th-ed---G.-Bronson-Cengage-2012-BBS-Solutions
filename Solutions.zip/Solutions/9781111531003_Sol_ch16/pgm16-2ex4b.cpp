// File: pgm16-2ex4b.cpp
// Description: 16.2 Exercise 4b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <iomanip>
using namespace std;

const int MAXCHARS = 15;
const int NUMEMPS = 6;

struct EmpRec
{
	long num;
	char name[MAXCHARS];
	double rate;
	double hours;
};

int main()
{
   EmpRec payroll[NUMEMPS];
   int i;

   for(i = 0; i < NUMEMPS; ++i)
   {
     cout << "\nEnter employee number: ";
     cin  >> payroll[i].num;

     cout << "Enter employee name: ";
     cin  >> payroll[i].name;

     cout << "Enter employee rate: ";
     cin  >> payroll[i].rate;

     cout << "Enter employee hours worked: ";
     cin  >> payroll[i].hours;
   }

   cout << "\n\nName          Number     Gross Pay\n";
   cout << "-------------------------------------\n";

   for( i = 0; i < NUMEMPS; ++i)
	   cout << setiosflags(ios::left) << setw(12) << payroll[i].name
			<< setiosflags(ios::right)
			<< setw(6) << payroll[i].num
			<< setiosflags(ios::showpoint | ios::fixed) << "     "
			<< setw(8) << setprecision(2)
			<< (payroll[i].rate * payroll[i].hours) << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

  return 0;
}

