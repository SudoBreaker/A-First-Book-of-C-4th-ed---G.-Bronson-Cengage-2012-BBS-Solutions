// File: pgm16-1ex3b.cpp
// Description: 16.1 Exercise 3b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  struct Time
  {
	  int hours;
	  int minutes;
	  int seconds;
  };

  Time current;

  cout << "Enter the current hour: ";
  cin >> current.hours;

  cout << "\nEnter the current minutes: ";
  cin >> current.minutes;

  cout << "\nEnter the current seconds: ";
  cin >> current.seconds;

  cout << "\nThe time entered is: "
	   << setw(2) << setfill('0') << current.hours
	  << ":" << setw(2) << current.minutes << ":" 
	  << setw(2) << current.seconds;
 
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

  return 0;
}

