// File: pgm16-3ex2.cpp
// Description: 16.3 Exercise 2
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <iomanip>
using namespace std;

struct Date
{
	int month;
	int day;
	int year;
};
 
long difDays(Date,  Date);  // function prototype
long days(Date);             // function prototype 

int main()
{
  char ch;
  Date first, second;
  long days;

  cout << "Enter the first date as mm/dd/yyyy: ";
  cin  >> first.month >> ch >> first.day >> ch >> first.year;

  cout << "Enter the second date as mm/dd/yyyy: ";
  cin  >> second.month >> ch >> second.day >> ch >> second.year;

  days = difDays(first,second);

  cout << "The number of days between these two dates is "
       << days << endl;  

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

  return 0;
}

long difDays(Date date1,  Date date2)
{
  return (days(date2) - days(date1));
}

long days(Date temp)
{
	return ((temp.day-1) + 30*(temp.month - 1) + 360*(temp.year-1900));
}

