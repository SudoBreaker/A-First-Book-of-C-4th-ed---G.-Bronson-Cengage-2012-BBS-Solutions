// File: pgm16-1ex6b.cpp
// Description: 16.1 Exercise 6b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  struct Date
  {
	  int month;
	  int day;
	  int year;
  };

  Date current;

  cout << "Enter the current month: ";
  cin >> current.month;

  cout << "\nEnter the current day: ";
  cin >> current.day;

  cout << "\nEnter the current year: ";
  cin >> current.year;

  if(current.day == 28 && current.month == 2)  // not accounting for leap years
  {
	  current.day = 1;
	  ++current.month;
  }
  else if(current.day == 30 && (current.month == 9 || current.month == 4
			|| current.month == 6 || current.month == 11))
  {
	  current.day = 1;
	  ++current.month;
  }
  else if(current.day == 31 && (current.month == 1 || current.month == 3
			|| current.month == 5 || current.month == 7
			|| current.month == 8 || current.month == 10
			|| current.month == 12))
  {
      current.day = 1;
      if(current.month != 12)
		  ++current.month;
      else
      {
		  current.month = 1;
		  if(current.year != 99)
			  ++current.year;
		  else
			  current.year = 00;
      }
  }
  else
	  ++current.day;

  cout << "\n\nThe next day's date is " << setfill('0') << setw(2) << current.month << '/'
		 << setw(2) << current.day << '/' << setw(2) << current.year << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

  return 0;
}

