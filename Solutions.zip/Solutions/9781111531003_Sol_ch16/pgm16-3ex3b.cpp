// File: pgm16-3ex3b.cpp
// Description: 16.3 Exercise 3b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <iomanip>
using namespace std;

struct Date
{
	int month;
	int day;
	int year;
};

long days(Date *);

int main()
{
  Date current;
  long num;

  cout << "Enter the current month: ";
  cin >> current.month;

  cout << "\nEnter the current day: ";
  cin >> current.day;

  cout << "\nEnter the current 4-digit year: ";
  cin >> current.year;

  num = days(&current);

  cout << "\nThe number of days since the turn of the"
	  << " century is: " << num;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

  return 0;
}

long days(Date *temp)
{
	return ((temp->day-1) + 30*(temp->month - 1) + 360*(temp->year-1900));
}

