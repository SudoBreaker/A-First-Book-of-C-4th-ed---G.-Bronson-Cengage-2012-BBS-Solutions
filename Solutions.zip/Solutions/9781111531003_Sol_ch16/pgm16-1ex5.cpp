// File: pgm16-1ex4.cpp
// Description: 16.1 Exercise 4
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 users

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  struct Time
  {
	  int hours;
	  int minutes;
  };

  Time current;

  cout << "Enter the current hour: ";
  cin >> current.hours;

  cout << "\nEnter the current minutes: ";
  cin >> current.minutes;

  if(current.minutes == 59)
  {
	  current.minutes = 0;
	  if(current.hours == 12)
		  current.hours = 1;
	  else
		  current.hours += 1;
  }
  else
	  current.minutes += 1;

  cout << "\nThe time in one minute will be: "
	   << setw(2) << setfill('0') << current.hours
	  << ":" << setw(2) << current.minutes;
       
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 users

  return 0;
}

