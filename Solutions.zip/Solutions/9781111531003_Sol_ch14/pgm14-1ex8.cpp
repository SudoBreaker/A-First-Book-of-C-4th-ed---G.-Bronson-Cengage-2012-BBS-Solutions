// File: pgm14-1ex8.cpp
// Description: 14.1 Exercise 8
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

int main()
{
  string str = "This cannot be";
  int i, numChars;

  cout << "The original string is: " << str << endl
       << "  and has " << str.length() << " characters." << endl;

  // insert characters
  str.insert(4," I know");
  cout << "The string, after insertion is : " << str << endl
	   << "  and has " << str.length() << " characters." << endl;

  // replace characters
  str.replace(12, 6, "to");
  cout << "The string, after replacement is: " << str << endl
	   << "  and has " << str.length() << " characters." << endl;

  // append characters
  str = str + " correct";
  cout << "The string, after appending is: " << str << endl
	   << "  and has " << str.length() << " characters." << endl;
    
   cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
