// File: pgm14-8ex6c.cpp
// Description: 14.8 Exercise 6c
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

namespace myFunctions
{

	double fracpart(double number)
	{
		int whole(int);

		return (number - whole(number));
	}

	int whole(int number)
	{
	return number;
	}

}  // end of myFunctions namespace

