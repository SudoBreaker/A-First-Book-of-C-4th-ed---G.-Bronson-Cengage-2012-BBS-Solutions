// File: pgm14-2ex5b.cpp
// Description: 14.2 Exercise 5b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

stingr Reverse(string);

int main()
{
   
  string str;
  
  cout << "Enter a string: ";
  getline(cin, str);

  cout << "The string in reverse: ";
    
  

   
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}


string Reverse(string str)
{
  int i, length;
  string str_reverse;

  length = str.length();
  for (i = 0; i < numChars; i++)
  {
	str_reverse.at(i) = str.at(numChars-i);
  }

  return str_reverse;
}