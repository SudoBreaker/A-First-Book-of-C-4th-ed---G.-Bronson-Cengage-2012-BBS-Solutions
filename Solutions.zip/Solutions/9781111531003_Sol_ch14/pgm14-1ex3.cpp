// File: pgm14-1ex3.cpp
// Description: 14.1 Exercise 3
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

int main()
{
   
  string str = "Counting the number of vowels";
  int i, numChars;
  int vowelCount = 0;
 
  cout << "The string: \"" <<  str << "\"";
    
  numChars = str.length();
  for (i = 0; i < numChars; i++)
  {
    switch(str.at(i))   // here is where a character is retrieved
    {
      case 'a': 
      case 'e': 
      case 'i': 
      case 'o': 
      case 'u':
        vowelCount++;   
    }
  }
  cout << " contains " <<  vowelCount <<  " vowels." << endl;
      
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}