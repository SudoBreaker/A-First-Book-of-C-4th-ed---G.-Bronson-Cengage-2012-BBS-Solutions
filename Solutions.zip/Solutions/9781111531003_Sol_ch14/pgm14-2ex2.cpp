// File: pgm14-2ex2.cpp
// Description: 14.2 Exercise 2
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

int main()
{
  int i;
  string str;
  
  cout << "Type in any sequence of characters: ";
  getline(cin,str);
 
  // cycle through all elements of the string
  for (i = 0; i < str.length(); i++)
    str[i] = toupper(str[i]);

  cout << "The characters just entered, in uppercase, are: "
       << str << endl;

     
    cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
       }
