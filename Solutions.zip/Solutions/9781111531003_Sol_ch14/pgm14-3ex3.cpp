// File: pgm14-3ex3.cpp
// Description: 14.3 Exercise 3
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
	int numerator, denominator;

  try
  {
    cout << "Enter the numerator (whole number only): ";
    cin  >> numerator;
    cout << "Enter the denominator(whole number only): ";
    cin  >> denominator;
	if (denominator == 0) 
	  throw denominator;  // an integer value is thrown
    else
	  cout << numerator <<'/' << denominator 
	     << " = " << numerator/denominator << endl;
  }
  catch(int e)
  {
    cout << "A denominator value of " << e << " is invalid." << endl;
    exit (1);
  }        

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}