// File: pgm14-1ex7.cpp
// Description: 14.1 Exercise 7
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

int main()
{
   
  string str;
  int i, numChars, index = 0, count = 0;
  char ch;
 
  cout << "Enter a string: ";
  getline(cin, str);

  cout << "Enter a character: ";
  cin >> ch;

  cout << "The character: " << ch << endl;
    
  numChars = str.length();
  i=0;
  index = str.find(ch, i);
  while (index != -1)
  {
	count++;
	i = index+1;
	index = str.find(ch,i);
    if(index == i-1)  // no more matches are found
		index = -1;
  }

  cout << "was found " << count << " times" << endl;

     
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}