// File: pgm14-2ex3.cpp
// Description: 14.2 Exercise 3
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
#include <cctype>
using namespace std;

int main()
{
  int i, count = 0;
  string str;
  
  cout << "Type in a string (that doesn't begin or end w/a space): ";
  getline(cin,str);

  // cycle through all elements of the string
  for (i = 0; i < str.length(); i++)
  {
	  if(isspace(str[i]) && !isspace(str[i+1]) && str[i-1])
		  count++;
  }

  count++;  // there will be one more word than spaces
  
  cout << "The number of words in that string are: "
       << count << endl;

     
    cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
