// File: pgm14-2ex6b.cpp
// Description: 14.2 Exercise 6b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
#include <cctype>
using namespace std;

 int countlets(string);
 
int main()
{
 
  string str;

  cout << "Enter a string: ";
  getline(cin, str);

  cout << "\nThere are " << countlets(str) 
	   << " letters in this string" << endl;
  
   
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

int countlets(string str)
{
	int i = 0, letters = 0;
	int length;

	length = str.length();

	while(i < length)
	{
		if(isalpha(str.at(i)))
			letters++;
		i++;
	}

	return letters;
}