// File: pgm14-5ex11a.cpp
// Description: 14.5 Exercise 11a
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
#include <cctype>  
using namespace std;

bool isvaldiReal();  // function declaration (prototype)

int main()
{
  
  string value;

  cout << "Enter a number with a decimal point: ";
  value = getanInt();
  
  getline(cin, value);

  if (!isvalidInt(value))
    cout << "The number you entered is not a valid integer.";
  else
  {
      number = atof(value.c_str());
    cout << "The real number you entered is " << number;
  }

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

 bool isvalidReal(string str)
{
	string str2;
	int start = 0, end = 0;
	int i, len = 0;
	bool valid = true;   // assume a valid
	bool sign = false;   // assume no sign
	bool decimal = false;  // assume no decimal

	
	// check for an empty string
	if (str.length() == 0) valid = false;

	// check for a leading sign
	if (str.at(0) == '-' || str.at(0) == '+')
	{
		sign = true;
		start = 1;   // start checking for digits after sign
	}

	// check that there is at least one character after the sign
	if(sign && str.length() == 1) valid = false;

	// now check the string, which we know has at least one non-sign char
	i = start;
	while(valid && i < str.length())
	{
		if(str.at(i) == '.' && !decimal)   // allows one decimal point
			decimal = true;
		else if (!isdigit(str.at(i))) valid = false;  
		i++;
	}

	return valid;
}


