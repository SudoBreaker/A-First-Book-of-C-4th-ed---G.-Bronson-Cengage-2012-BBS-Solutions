// File: pgm14-1ex6.cpp
// Description: 14.1 Exercise 6
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

int main()
{
   
  string str;
  int i, numChars;
 

  cout << "Enter a string: ";
  getline(cin, str);

  cout << "The string in reverse: ";
    
  numChars = str.length();
  for (i = 0; i < numChars; i++)
  {
	cout << str.at(numChars-1-i);
  }

   
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}