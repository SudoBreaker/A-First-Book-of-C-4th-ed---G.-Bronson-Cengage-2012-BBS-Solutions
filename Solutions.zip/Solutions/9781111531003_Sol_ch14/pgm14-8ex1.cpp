// File: pgm14-8ex1.cpp
// Description: 14.8 Exercise 1
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <c:\\mylibrary\\dataChecks.cpp>
using namespace dataChecks;

int main()
{
  int value;

  cout << "Enter an integer value: ";
  value = getanInt();
  cout << "The integer entered is: " << value << endl;

      

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}