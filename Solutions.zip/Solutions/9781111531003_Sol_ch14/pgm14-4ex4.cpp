// File: pgm14-4ex4.cpp
// Description: 14.4 Exercise 4
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <fstream>
#include <cstdlib>   // needed for exit()
#include <string>
using namespace std;

int main()
{
  string filename = "prices.dat";  // put the filename up front
  string descrip;
  double price;
  
  ifstream inFile;

  try  // this block tries to open the file, read, and display the file's data
  {
    inFile.open(filename.c_str());

    if (inFile.fail()) throw filename; // this is the exception being checked 
    
    // read and display the file's contents
    inFile >> descrip >> price;
	while (inFile.good()) // check next character
    {
       cout << descrip << ' ' << price << endl;
       inFile >> descrip >> price;
    }
      inFile.close();

	  cin.ignore();  // needed for MS C++ Express 2010 programs
      
      return 0;  
  }
  catch (string file)
  {
     cout << "\nThe file "<< file << " was not successfully opened"
          << "\n Please check that the file currently exists."
	       << endl;
	  cin.ignore();  // needed for MS C++ Express 2010 programs
      exit(1);
  }
}
