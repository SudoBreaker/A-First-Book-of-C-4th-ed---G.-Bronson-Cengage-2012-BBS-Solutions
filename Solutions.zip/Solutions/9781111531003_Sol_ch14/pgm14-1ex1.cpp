// File: pgm14-1ex1.cpp
// Description: 14.1 Exercise 1
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

int main()
{
  string message;     // declare a string object

  cout << "Enter a string:\n";

  getline(cin, message);

  cout << "The string just entered is:\n"
       << message << endl;
   
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
