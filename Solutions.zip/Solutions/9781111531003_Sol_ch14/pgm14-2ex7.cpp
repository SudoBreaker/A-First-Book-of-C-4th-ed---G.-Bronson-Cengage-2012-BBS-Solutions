// File: pgm14-2ex7.cpp
// Description: 14.2 Exercise 7
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
  string str;
  int i = 0;
  int length;

  cout << "Enter a string: ";
  getline(cin, str);

  cout << "\nThe hexadecimal equivalent of each character is: " << endl;

 length = str.length();
 while(i < length)
  {
	  cout << showbase << hex << (int)str[i] << endl;
	  i++;
  }
  
   
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}