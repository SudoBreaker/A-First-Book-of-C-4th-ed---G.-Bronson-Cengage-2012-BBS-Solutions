// File: pgm14-3ex5.cpp
// Description: 14.3 Exercise 5
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
	int numerator, denominator;
	bool needDenominator = true;

	cout << "Enter the numerator (whole number only): ";
    cin  >> numerator;

    cout << "Enter the denominator (whole number only): ";
	while(needDenominator)
	{
		cin  >> denominator;
		try
		{
			if (denominator == 0) 
				throw denominator;  // an integer value is thrown
		}
		catch(int e)
		{
			cout << "A denominator value of " << e << " is invalid." << endl;
			cout << "Please enter the denominator (whole number only): ";
			continue;  // this send control back to the while statement
		}
		cout << numerator << '/' << denominator
			 << " = " << double(numerator)/double(denominator) << endl;
		needDenominator = false;
	}   

    cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}