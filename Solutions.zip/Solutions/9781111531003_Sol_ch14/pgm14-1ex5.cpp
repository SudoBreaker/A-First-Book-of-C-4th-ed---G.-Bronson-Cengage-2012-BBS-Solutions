// File: pgm14-1ex5.cpp
// Description: 14.1 Exercise 5
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

int main()
{
   
  string str;
  int i, numChars, vowelCount;
  int aCount = 0, eCount = 0, iCount = 0, oCount = 0, uCount = 0;
 

  cout << "Enter a lowercase string: ";
  getline(cin, str);

  cout << "The string: \"" <<  str << "\"";
    
  numChars = str.length();
  for (i = 0; i < numChars; i++)
  {
    switch(str.at(i))   // here is where a character is retrieved
    {
      case 'a': 
		  aCount++;
		  break;
      case 'e': 
		  eCount++;
		  break;
      case 'i': 
		  iCount++;
		  break;
      case 'o': 
		  oCount++;
		  break;
      case 'u':
        uCount++; 
		break;
    }
  }
  vowelCount = aCount + eCount + iCount + oCount + uCount;
  cout << " contains " <<  vowelCount <<  " vowels." << endl;
  cout << "\nThere are: " << endl;
  cout << aCount << " a's" << endl;
  cout << eCount << " e's" << endl;
  cout << iCount << " i's" << endl;
  cout << oCount << " o's" << endl;
  cout << uCount << " u's" << endl;

      
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
