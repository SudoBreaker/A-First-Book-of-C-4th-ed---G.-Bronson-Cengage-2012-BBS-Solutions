// File: pgm14-2ex5b.cpp
// Description: 14.2 Exercise 5b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <string>
using namespace std;

string Reverse(string);

int main()
{
   
  string str;
  
  cout << "Enter a string: ";
  getline(cin, str);

  cout << "The string in reverse is: " << Reverse(str) << endl;
   
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}


string Reverse(string str)
{
  int i, length;
  string str_reverse = str; // set the correct lenth for the second string

  length = str.length();
  for (i = 0; i < length; i++)
  {
	str_reverse.at(i) = str.at(length-1-i);
	
  }
    return str_reverse;
}