// File: pgm14-3ex4.cpp
// Description: 14.3 Exercise 4
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
	int numerator, denominator;

  try
  {
    cout << "Enter the numerator (whole number only): ";
    cin  >> numerator;
    cout << "Enter the denominator(whole number only): ";
    cin  >> denominator;
	if (denominator == 0) 
	  throw "***Invalid input - A denominator value of zero is not permitted***"; 
    else
	  cout << numerator <<'/' << denominator 
	       << " = " << double(numerator)/ double(denominator) << endl;
  }
  catch(char e[])
  {
    cout << e << endl;
    exit (1);
  }   

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}