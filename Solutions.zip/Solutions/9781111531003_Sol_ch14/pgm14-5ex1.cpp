// File: pgm14-5ex1.cpp
// Description: 14.5 Exercise 1
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int num;

  cout << "Enter a integer: ";
  cin >> num;

  cout << "The character entered was: " << num << endl;

    
  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
