// File: pgm14-8ex5b.cpp
// Description: 14.8 Exercise 5b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int whole(int);  // function prototype
  int a = 8;
  double b = -9.8;
  double c = 12.42324;  

  cout << a << " whole: " << whole(a) << endl;
  cout << b << " whole: " << whole(b) << endl;
  cout << c << " whole: " << whole(c) << endl;

   

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

int whole(int number)
{
  return number;
}

