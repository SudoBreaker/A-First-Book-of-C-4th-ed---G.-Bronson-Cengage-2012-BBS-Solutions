// File: pgm7-2ex2.cpp
// Description: 7.2 Exercise 2
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{   
  const int SIZE = 8;
  double prices[SIZE]={16.24,18.98,23.75,16.29,19.54,14.22,11.13,15.39};
  int i;

  for (i = 0; i < SIZE; i++)
    cout << "  " << prices[i] << endl;

  
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

