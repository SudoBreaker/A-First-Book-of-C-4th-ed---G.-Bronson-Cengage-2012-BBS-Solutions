// File: pgm7-4ex4.cpp
// Description: 7.4 Exercise 4
// Programmer: G. Bronson
// Date: 9/1/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const int ROWS = 2;
  const int COLS = 3;
      
  int i, j; 
  int first[ROWS][COLS] = {16,18,23,54,91,11};
  int second[ROWS][COLS] = {24,52,77,16,19,59};
  int element[ROWS][COLS];

  cout << "First Array\n";
  for (i = 0; i < ROWS; ++i)
  {
    cout << endl;
    for (j = 0; j < COLS; ++j)
    { 
      cout << first[i][j] << "   ";
    }	
  }
 
  cout << "\n\nSecond Array\n";
  for (i = 0; i < ROWS; ++i)
  {
    cout << endl;
    for (j = 0; j < COLS; ++j)
    { 
      cout << second[i][j] << "   ";
    }	
  }

  cout << "\n\nSum of the above arrays - element-by-element\n";
  for (i = 0; i < ROWS; ++i)
  {
    cout << endl;
    for (j = 0; j < COLS; ++j)
    { 
      element[i][j] = first[i][j] + second[i][j];
      cout << element[i][j] << "  ";
    }
  }
	
  cout << "\n\n"; 

  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}
