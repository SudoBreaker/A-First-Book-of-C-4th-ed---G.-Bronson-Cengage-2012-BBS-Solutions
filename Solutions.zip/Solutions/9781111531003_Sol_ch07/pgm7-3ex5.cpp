// File: pgm7-3ex5.cpp
// Description: 7.3 Exercise 5
// Programmer: G. Bronson
// Date: 9/1/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

void show(double []);       // function prototype
const int NUMVALS = 9;
 
 int main()
{
 
  double rates[NUMVALS] = {6.5, 7.2, 7.5, 8.3, 8.6, 9.4, 9.6, 9.8, 10.0};

  show(rates);

  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

// show the values
void show(double vals[])
{
  int i;

  for (i = 0; i < NUMVALS; i++)
    cout << vals[i] << endl;

  return;
}

