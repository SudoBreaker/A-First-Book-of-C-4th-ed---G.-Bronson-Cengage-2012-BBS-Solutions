// File: pgm7-2ex4.cpp
// Description: 7.2 Exercise 4
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{   
  const int SIZE = 5;
  double prices[SIZE] = {9.92, 6.32, 12.63, 5.95, 10.29};
  double units[SIZE], amounts[SIZE];
  double total = 0;
  int i;

  for (i = 0; i < SIZE; i++)
  {
	  cout << "Enter the units: ";
	  cin >> units[i];
	  amounts[i] = units[i] * prices[i];
	  total = total + amounts[i];
  }

  cout << "\nPrice    Units   Amount" << endl;
  cout << "-----    -----   ------" << endl;
  for (i = 0; i < SIZE; i++)
  {
	  cout << setiosflags(ios::fixed) << setiosflags(ios::showpoint)
		   << setprecision(2) << setw(5) << prices[i] << "    " 
		   << units[i]  << "    " 
		   << amounts[i] << endl;
  }

  cout << "                 -----" << endl;
  cout << "Total:          " << total << endl;
    
  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

