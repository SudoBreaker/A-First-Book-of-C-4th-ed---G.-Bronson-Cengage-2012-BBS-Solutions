// File: pgm7-1ex6b.cpp
// Description: 7.1 Exercise 6b
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iomanip>
#include <iostream>
using namespace std;

int main()
{
  const int MAXPRICES = 9;
  double prices[MAXPRICES];
  int i;

  prices[0] = 10.95;
  prices[1] = 16.32;
  prices[2] = 12.15;
  prices[3] = 8.22;
  prices[4] = 15.98;
  prices[5] = 26.22;
  prices[6] = 13.54;
  prices[7] = 6.45;
  prices[8] = 17.59;

  for (i = 0; i < MAXPRICES; i = i +3)    // Display the prices
	  cout << setw(6) << prices[i] << setw(6) << prices[i+1]
           << setw(6) << prices[i+2] <<  endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}
