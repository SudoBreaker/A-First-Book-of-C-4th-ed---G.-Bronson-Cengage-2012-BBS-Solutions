// File: pgm7-2ex8c.cpp
// Description: 7.2 Exercise 8c
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{   
  char strtest[] = "This is a test";   

  cout << strtest;
 
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

