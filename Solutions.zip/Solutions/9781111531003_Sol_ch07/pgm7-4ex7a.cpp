// File: pgm7-4ex7a.cpp
// Description: 7.4 Exercise 7a
// Programmer: G. Bronson
// Date: 9/1/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const int ROWS = 3;
  const int COLS = 5;
      
  int i, j, less60 = 0, less70 = 0;
  int less80 = 0, less90 = 0, great90 = 0;
  double grades[ROWS][COLS];
  
  for (i = 0; i < ROWS; ++i)
  {
	for (j = 0; j < COLS; ++j)
	{
		cout << "Enter a grade: ";
		cin >> grades[i][j];
		if(grades[i][j] < 60)
			less60++;
		else if(grades[i][j] >= 60 && grades[i][j] < 70)
			less70++;
		else if(grades[i][j] >= 70 && grades[i][j] < 80)
			less80++;
		else if(grades[i][j] >= 80 && grades[i][j] < 90)
			less90++;
		else if(grades[i][j] >= 90)
			great90++;
	}
  }

  cout << "There are " << less60 
	   << " grades less than 60" << endl;
  cout << "There are " << less70 
	   << " grades greater than or equal to 60 and less than 70" << endl;
  cout << "There are " << less80 
	    << " grades greater than or equal to 70 and less than 80" << endl;
  cout << "There are " << less90 
	   << " grades greater than or equal to 80 and less than 90" << endl;
  cout << "There are " << great90 
       << " grades greater than or equal to 90" << endl;

  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}
