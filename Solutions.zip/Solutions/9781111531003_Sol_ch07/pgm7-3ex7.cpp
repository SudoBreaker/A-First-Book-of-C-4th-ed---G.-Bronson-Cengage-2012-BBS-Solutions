// File: pgm7-3ex7.cpp
// Description: 7.3 Exercise 7
// Programmer: G. Bronson
// Date: 9/1/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

void extend(double [], double [], double []);   // function prototype
const int SIZE = 10;

int main()
{
  double price[SIZE] 
	  = {0.62,14.89,13.21,16.55,18.62,9.47,6.58,18.32,12.15,3.98};
  double quantity[SIZE] = {4, 8.5, 6, 7.35, 9, 15.3, 3, 5.4, 2.9, 4.8};
  double amount[SIZE];
  int i;
 
  extend(price, quantity, amount);

  cout << "Price     Quantity    Amount" << endl;
  cout << "-----     --------    ------" << endl;
  for(i=0; i<SIZE; i++)
  {
	  cout << setiosflags(ios::fixed) << setiosflags(ios::showpoint)
		   << setprecision(2) << setw(5)
	       << price[i] << "      " << setw(7) << quantity[i]
	       << "   " << setw(7) << amount[i] << endl;
  }
 
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

void extend(double pr[], double quan[], double amt[])
{
  int i;

  for(i=0; i<SIZE; i++)
    amt[i] = pr[i] * quan[i];

  return;
}


