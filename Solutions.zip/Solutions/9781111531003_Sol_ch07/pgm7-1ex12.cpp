// File: pgm7-1ex12.cpp
// Description: 7.1 Exercise 12
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const int SIZE = 50;   // Specified in exercise
  int peopleTypes[SIZE];
  int i=0, infant=0, child=0, teen=0, adult=0;

  do
  {
	  cout << "Enter a type: ";
	  cin >> peopleTypes[i];
	  if(peopleTypes[i] == 1)
		  infant++;
	  else if(peopleTypes[i] == 2)
		  child++;
	  else if(peopleTypes[i] == 3)
		  teen++;
	  else if(peopleTypes[i] == 4)
		  adult++;
	  else
		  cout << "Invalid entry!" << endl;
	  i++;
  }while(peopleTypes[i-1]>0);

  cout << "\nThere were: " << endl;
  cout << infant << " infants" << endl;
  cout << child << " children" << endl;
  cout << teen << " teenagers" << endl;
  cout << adult << " adults" << endl;

  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

