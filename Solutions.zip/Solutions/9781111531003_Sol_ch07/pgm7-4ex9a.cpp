// File: pgm7-4ex9a.cpp// File: pgm7-4ex9a.cpp
// Description: 7.4 Exercise 9a
// Programmer: G. Bronson
// Date: 9/1/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  const int ROWS = 5;
  const int COLS = 7;  // first col for student #, next four for grades,
			     // and final 2 for the final computed grades
      
  int i, j; 
  double total, grades[ROWS][COLS];
  
  //max = vals[0][0];

  for (i = 0; i < ROWS; ++i)
  {
	  total = 0;  // to reset for each student
    for (j = 0; j < (COLS-2); ++j)
	{
		if(j == 0)
		{
			cout << "\nEnter the student number: ";
			cin >> grades[i][j];
		}
		else
		{
			cout << "Enter the " << j << " grade: ";
			cin >> grades[i][j];
			total = total + grades[i][j];
		}
	}
	grades[i][j] = total/(COLS-3);   // should be saved in 5th col
	grades[i][j+1] = 0.2 * grades[i][1] + 0.3 * grades[i][2] 
					+ 0.3 * grades[i][3] + 0.2 * grades[i][4];
  }

 
  cout 
<< "\nStudent  Grade 1   Grade 2    Grade 3   Grade 4      Avg   Wt. Avg" << endl;
  cout 
<< "--------------------------------------------------------------------" << endl;

  for (i = 0; i < ROWS; ++i)
  {
	for (j = 0; j < COLS; ++j)
	{
		cout << setw(5) << grades[i][j] << "     ";
	}
	cout << endl;
  }

  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}
