// File: pgm7-4ex3a.cpp
// Description: 7.4 Exercise 3a
// Programmer: G. Bronson
// Date: 9/1/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const int ROWS = 3;
  const int COLS = 4;
      
  int i, j, val[ROWS][COLS] = {8,16,9,52,3,15,27,6,14,25,2,10};
  int total = 0;

  for (i = 0; i < 3; ++i)
  {
    cout << endl;
    for (j = 0; j < 4; ++j)
    {
      cout << val[i][j] << "  ";
	total += val[i][j];
    }
  }
  cout << "\n\nThe total of all elements is: " << total << endl;
	
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}
