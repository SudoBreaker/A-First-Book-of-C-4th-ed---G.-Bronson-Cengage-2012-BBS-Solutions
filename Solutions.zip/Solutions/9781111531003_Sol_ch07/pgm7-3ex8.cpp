// File: pgm7-3ex8.cpp
// Description: 7.3 Exercise 7
// Programmer: G. Bronson
// Date: 9/1/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

double calcAverage(int []);
double variance(int [], double);

const int SIZE = 14;

int main()
{ 
  int testvals[] = {89,95,72,83,99,54,86,75,92,73,79,75,82,73};
  double average;

  average = calcAverage(testvals);

  cout << "The average is: " << average << endl;
  cout << "The variance is: " << variance(testvals, average) << endl;
 
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

double calcAverage(int vals[])
{
  int i;
  double avg = 0;

  for(i=0; i<SIZE; i++)
  {
	avg = avg + vals[i];
  }

  avg = avg/SIZE;

  return avg;
}

double variance(int vals[], double avg)
{
  int i;
  double var = 0;

  for(i=0; i<SIZE; i++)
  {
	var = pow((vals[i]- avg), 2) + var;
  }

  var = var/SIZE;

  return var;
}

