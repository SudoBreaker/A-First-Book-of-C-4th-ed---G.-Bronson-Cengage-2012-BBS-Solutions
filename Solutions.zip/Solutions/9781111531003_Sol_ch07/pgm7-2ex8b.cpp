// File: pgm7-2ex8b.cpp
// Description: 7.2 Exercise 8b
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{   
	const int NUMDISPLAY = 14;
	char strtest[] = "This is a test";   
	int i;

	for(i=10; i < NUMDISPLAY; i++)
		cout << strtest[i];
  
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

