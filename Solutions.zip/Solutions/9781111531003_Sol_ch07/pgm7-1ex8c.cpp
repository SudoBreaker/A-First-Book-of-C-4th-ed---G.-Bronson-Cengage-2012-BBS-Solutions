// File: pgm7-1ex8c.cpp
// Description: 7.1 Exercise 8c
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const int SIZE = 10;
  int fmin[SIZE], index, min, i = 0;

  do
  {
	  cout << "Enter a number: ";
	  cin >> fmin[i];
	  if(i==0)
	  {
		  min = fmin[i];
		  index = i;
	  }
	  if(fmin[i] < min)
	  {
		  min = fmin[i];
		  index = i;
	  }
	  i++;
  }while(i<SIZE);

  cout << "\nThe minimum value is: " << min << endl;
  cout << "This is element number " << index 
	   << " in the list of numbers." << endl;
  
  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

