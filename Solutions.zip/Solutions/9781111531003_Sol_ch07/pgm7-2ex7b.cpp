// File: pgm7-2ex7b.cpp
// Description: 7.2 Exercise 7b
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{   
	char message1[] = "Input the Following Data";   
	char message2[] = "------------------------";
	char message3[] = "Enter the Date: ";
	char message4[] = "Enter the Account Number: ";

  cout << message1 << endl;
  cout << message2 << endl;
  cout << message3 << endl;
  cout << message4 << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

