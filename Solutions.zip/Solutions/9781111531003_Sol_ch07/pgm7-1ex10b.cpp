// File: pgm7-1ex10b.cpp
// Description: 7.1 Exercise 10b
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
  const int SIZE = 14;
  int grade[SIZE]= {89,95,72,83,99,54,86,75,92,73,79,75,82,73};
  int i, total = 0;
  double deviation[SIZE], average, totdev = 0, variance;

  for(i=0; i < SIZE; i++)          	 
	  total = total + grade[i];

  average = total/SIZE;

  cout << "\nThe average is: " << average << endl;
  
  for(i=0; i < SIZE; i++)
  {
	  deviation[i] = grade[i] - average;
	  totdev = totdev + pow(deviation[i], 2);
  }

  variance = totdev/SIZE;
  cout << "The variance is " << totdev << endl;
  
  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}




