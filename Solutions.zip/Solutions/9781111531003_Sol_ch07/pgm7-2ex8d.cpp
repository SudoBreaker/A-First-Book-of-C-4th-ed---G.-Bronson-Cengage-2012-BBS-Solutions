// File: pgm7-2ex8d.cpp
// Description: 7.2 Exercise 8d
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{   
  char strtest[] = "This is a test";   
  int i = 0;

  while(strtest[i] != '\0')
  {
    cout << strtest[i];
    i++;
  }
  
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

