// File: pgm7-4ex8a.cpp
// Description: 7.4 Exercise 8a
// Programmer: G. Bronson
// Date: 9/1/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

const int ROWS = 100;  
const int COLS = 2;   // since only the part # and quantity
                      // of each part needs to be saved

int main()
{
  void sort(int [ROWS][COLS], int);

  int i, j, numParts; 
  int parts[ROWS][COLS];

  cout << "\nEnter how many parts: ";
  cin >> numParts;
  
  for (i = 0; i < numParts; ++i)
  {
	  cout << "Enter a part no. and a quantity: ";
	  cin >> parts[i][0] >> parts[i][1];
  }

  cout << "\nThe entered data is: " << endl;
  cout << "\nPart No.   Quanitity" << endl;
  cout << "--------------------" << endl;

  for(i = 0; i < numParts; i++)
  {
	  cout << setw(4) << parts[i][0] << setw(12) << parts[i][1];
	  cout << endl;
  }

  sort(parts, numParts);

  cout << "\nThe data in decreasing quantity order is: " << endl;
  cout << "\nPart No.   Quanitity" << endl;
  cout << "--------------------" << endl;

  for(i = 0; i < numParts; i++)
  {
	  cout << setw(4) << parts[i][0] << setw(12) << parts[i][1];
	  cout << endl;
  }

  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}


void sort(int num[ROWS][COLS], int numel)
{
  int i, j, max, maxidx, temp, part;

  for ( i = 0; i < (numel-1); i++)
  {
    max = num[i][1];  // assume maximum is first quantity
    part = num[i][0]; // save the corresponding part no.
    maxidx = i;     // index of maximum element
    for(j = i + 1; j < numel; j++)
    {
      if (num[j][1] > max)   // if we've located a higher value
      {                      // capture it
       max = num[j][1];
       maxidx = j;
       part = num[j][0];
      }
    }
    if (max > num[i][1])  // check if we have a new minimum
    {                     // and if we do, swap values
      temp = num[i][1];   // swap quantities
 
      num[i][1] = max;
      num[maxidx][1] = temp;
      temp = num[i][0];   // swap part numbers
      num[i][0] = part;
      num[maxidx][0] = temp;
    }
  }

  return;
}
