// File: pgm7-1ex15a.cpp
// Description: 7.1 Exercise 15a
// Programmer: N. Ashton
// Date: 1/15/2006

#include <iostream>
using namespace std;

int main()
{
  const int SIZE = 10;
  int i, j, index = 0;
  double raw[SIZE], sorted[SIZE], min = 999999;

  for(i=0; i < SIZE; i++)         
  {                               
	  cout << "Enter a numer: ";
	  cin >> raw[i];
  }

  for(i=0; i < SIZE; i++)
  {	
	  for(j=0; j < SIZE; j++)
	  {
		if(raw[j] < min)
		{
			min = raw[j];
			index = j;
		}
	  }
	  sorted[i] = min;
	  min = 999999;
	  raw[index] = 9999999;

  }

  for(i=0; i<SIZE; i++)
	  cout << "The numbers sorted are: " << sorted[i] << endl;
  
  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

