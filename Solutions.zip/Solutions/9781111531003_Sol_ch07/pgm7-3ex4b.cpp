// File: pgm7-3ex4b.cpp
// Description: 7.3 Exercise 4b
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int findMin(int []);       // function prototype
const int MINELS = 5;

int main()
{
  int nums[MINELS] = {2, 18, 1, 27, 16};

  cout << "The minimum value is " << findMin(nums) << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

// find the minimum value
int findMin(int vals[MINELS])
{
  int i, min = vals[0];

  for (i = 1; i < MINELS; i++)
    if (min > vals[i]) min = vals[i];

  return min;
}

