// File: pgm7-1ex13a.cpp
// Description: 7.1 Exercise 13a
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const int SIZE = 100;  // the max number of grades to be entered
                         // could be any #
  double grade[SIZE], sum = 0, average;
  int count, i = 0;

  do
  {
	  cout << "Enter a grade: ";
	  cin >> grade[i];
	  sum = sum + grade[i];
	  i++;
  }while(grade[i-1]>0);

  sum = sum - grade[i-1];
  count = i-1;
  average = sum/count;

  cout << "\nThe sum is: " << sum << endl;
  cout << "The average is: " << average << endl;
  cout << "\nNumerical"
	   << "\n  Grade"
	   << "\n---------\n";
  
  for(i=0; i<count; i++)
  { 
	  if(grade[i] < average)
		  cout << "*";
	  cout << grade[i] << endl;
  }
  
  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}
