// File: pgm7-2ex8a.cpp
// Description: 7.2 Exercise 8a
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{   
	const int NUMDISPLAY = 14;
	char strtest[] = "This is a test";   
	int i;

	for(i=0; i < NUMDISPLAY; i++)
		cout << strtest[i];
 
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

