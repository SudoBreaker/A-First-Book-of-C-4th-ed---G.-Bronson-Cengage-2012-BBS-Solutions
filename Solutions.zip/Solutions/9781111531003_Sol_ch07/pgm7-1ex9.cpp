// File: pgm7-1ex9.cpp
// Description: 7.1 Exercise 9
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
 void showRev(int, int []);       // function prototype
 
  const int SIZE = 5;   // could be any size
  int vals[] = {1, 2, 3, 4, 5};  // could be any array

  showRev(SIZE, vals);
  
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

// show the values
void showRev(int numvals, int vals[])
{
  int i;

  for (i = (numvals-1); i >= 0; i--)
    cout << vals[i] << endl;

  return;
}

