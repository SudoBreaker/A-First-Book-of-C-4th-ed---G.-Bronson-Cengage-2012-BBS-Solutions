// File: pgm7-2ex5.cpp
// Description: 7.2 Exercise 5
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  
  const int SIZE = 20;   
  int nums[] = {12,4,76,-3,-6,9,0,-21,
                234,675,98,87,45,-34,82,68,17,-2,-1,-6};
  int positive[SIZE], negative[SIZE];  // each array could possibly 
                                       // hold all the numbers
  int i, posCnt, negCnt;

  cout << "\nThe original list of numbers is: " << endl;
  for(i=0; i<SIZE; i++)
	  cout << nums[i] << "    ";

  // sort the no's into postive and negative
  for ( i = 0; i < SIZE; i++)
  {
	if(nums[i] >= 0)
	{
		positive[posCnt] = nums[i];
		posCnt++;
	}
	else
	{
		negative[negCnt] = nums[i];
		negCnt++;
	}
	
 }
 // display the values
 cout << "\n\nThe positive numbers are: " << endl;
	
 for(i = 0; i < posCnt; i++)
	cout << positive[i] << "    ";

 cout << "\n\nThe negative numbers are: " << endl;
 for(i = 0; i < (SIZE - posCnt); i++)
	cout << negative[i] << "    ";
		i++;
	
  cout << "\n\n";

  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}
 
