// File: pgm7-1ex11.cpp
// Description: 7.1 Exercise 11b
// Programmer: G. Bronson
// Date: 8/31/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{   
  const int SIZE = 10;
  double price[SIZE], amount[SIZE], total[SIZE];
  int i;

  for (i = 0; i < SIZE; i++)
  {
	cout << "Enter the price and amount: ";
	cin >> price[i] >> amount[i];
    total[i] = price[i] * amount[i];
  }
    cout << "\ntotal     price     amount";
    cout << "\n-----     -----     ------" << endl;

  for (i = 0; i < SIZE; i++)
	cout << setw(5) << total[i] 
	     << setw(10) << price[i] 
	     << setw(11) << amount[i] << endl;

  cin.ignore(); cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

