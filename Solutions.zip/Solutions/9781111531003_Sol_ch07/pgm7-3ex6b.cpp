// File: pgm7-3ex6b.cpp
// Description: 7.3 Exercise 6b
// Programmer: G. Bronson
// Date: 9/1/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  void display(char []);       // function prototype
  
 char message[] = "Vacation is near";

  display(message);

  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

void display(char strng[])
{
  int i;

  for(i=0; i < 8; i++)
	cout << strng[i];

  return;
}

