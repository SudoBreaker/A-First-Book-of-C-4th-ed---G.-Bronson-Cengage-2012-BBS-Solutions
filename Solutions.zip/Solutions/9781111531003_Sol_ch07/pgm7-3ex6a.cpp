// File: pgm7-3ex6a.cpp
// Description: 7.3 Exercise 6a
// Programmer: G. Bronson
// Date: 9/1/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

void display(char []);       // function prototype

int main()
{
  
 char message[] = "Vacation is near";

  display(message);

  
  cin.ignore();   // needed for MS C++ Express 2010 programs
  
  return 0;
}

void display(char strng[])
{
  cout << strng << endl;

  return;
}

