// File: pgm15-2ex2b.cpp
// Description: 15.2 Exercise 2b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

void convert(char *strng);
char ToUpper(char letter);

int main(void)
{
	char *s, ch;
	char string[80];
	int i = 0;
	s = string;
	cout << "\nEnter a string:  ";
	while (i < 80 && (ch = cin.get()) != '\n')
	{
		string[i] = ch;
		i++;
	}
	string[i] = '\0';
	convert(s);
	cout << s << endl;  

	cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
char ToUpper(char letter)
{
	if((letter>='a') && (letter <= 'z'))
		return (letter - 'a' + 'A');
	else
		return(letter);
}

void convert(char *strng)
{
	while (*strng != '\0')
	{
		*strng++ = ToUpper(*strng);
	}
	return;
}
