// File: pgm15-1ex11.cpp
// Description: 15.1 Exercise 11
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const int MAXCHARS = 81;
  char strng[MAXCHARS];  
  int i = 0, count = 1;

  cout << "Enter a string: ";
  cin.getline(strng,MAXCHARS);        // get the string

  if(strng[i] == ' ' || strng[i] == '\0')
	  count--;
  while(strng[i] !='\0')
  {
	  if(strng[i] == ' ' && (strng[i + 1] != ' ' && strng[i + 1] != '\0'))
		  count++;
	  i++;
  }
  cout << "\nThe number of words in the string entered is: " << count << endl;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
