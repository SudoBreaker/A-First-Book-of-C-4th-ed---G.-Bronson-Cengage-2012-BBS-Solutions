// File: pgm15-1ex9c.cpp
// Description: 15.1 Exercise 9c
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  void toUpper(char [], char []); // function prototype

  const int MAXCHARS = 81;
  char message[MAXCHARS];   
  char newMsg[MAXCHARS];

  cout << "Enter a string: ";
  cin.getline(message,MAXCHARS);        // get the string
  toUpper(message, newMsg);

  cout << "\nThe string converted to uppercase is: " << endl;
  cout << newMsg;
 

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void toUpper(char strng[], char newStrng[])
{
  int i = 0;

  while(strng[i] != '\0')
  {
	  if(strng[i] < 'a' || strng[i] > 'z')
		  newStrng[i] = strng[i];
	  else
		  newStrng[i] = strng[i] - 'a' + 'A';
	  i++;
  }

  newStrng[i] = '\0';

  return;
}

