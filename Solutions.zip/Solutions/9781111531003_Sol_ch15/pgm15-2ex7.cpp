// File: pgm15-2ex7.cpp
// Description: 15.2 Exercise 7
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  void reverse(char *, char *); // function prototype

  const int MAXCHARS = 81;
  char message[MAXCHARS];   
  char newMsg[MAXCHARS];

  cout << "Enter a string: ";
  cin.getline(message,MAXCHARS);        // get the string
  reverse(message, newMsg);

  cout << "\nThe string reversed is: " << endl;
  cout << newMsg;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void reverse(char *strng, char *newStrng)
{
  int i, j;
  int len = 0;   // to get the length

  len = strlen(strng);
  
  for(i = 0, j = len-1; i < len; i++, j--)
	  *(newStrng + i) = *(strng + j);

  *(newStrng + i) = '\0';

  return;
}

