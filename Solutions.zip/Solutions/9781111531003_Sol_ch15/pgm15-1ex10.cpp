// File: pgm15-1ex15.cpp
// Description: 15.1 Exercise 10
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  void toLower(char [], char []); // function prototype

  const int MAXCHARS = 81;
  char message[MAXCHARS];   
  char newMsg[MAXCHARS];

  cout << "Enter a string: ";
  cin.getline(message,MAXCHARS);        // get the string
  toLower(message, newMsg);

  cout << "\nThe string converted to lowercase is: " << endl;
  cout << newMsg;

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void toLower(char strng[], char newStrng[])
{
  int i = 0;

  while(strng[i])
  {
	  if(strng[i] < 'A' || strng[i] > 'Z')
		  newStrng[i] = strng[i];
	  else
		  newStrng[i] = strng[i] - 'A' + 'a';
	  i++;
  }

  newStrng[i] = '\0';

  return;
}

