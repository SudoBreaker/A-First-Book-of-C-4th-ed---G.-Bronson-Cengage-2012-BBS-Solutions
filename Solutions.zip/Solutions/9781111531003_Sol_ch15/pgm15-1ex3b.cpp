// File: pgm15-1ex3b.cpp
// Description: 15.1 Exercise 3b
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int length(char []); // function prototype

  const int MAXCHARS = 81;
  char message[MAXCHARS];      
  int i, len;

  cout << "Enter a string: ";
  cin.getline(message,MAXCHARS);        // get the string
  len = length(message);
  cout << "\nThe length of the string is:\n"
       << len << endl;

      

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

int length(char string1[])   
{
  int count = 0;    

  while (string1[count])
	  count++;

  return count;
}
