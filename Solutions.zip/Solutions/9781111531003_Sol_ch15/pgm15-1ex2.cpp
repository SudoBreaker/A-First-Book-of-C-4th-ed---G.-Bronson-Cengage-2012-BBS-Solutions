// File: pgm15-1ex2.cpp
// Description: 15.1 Exercise 2
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  void vowels(char []); // function prototype

  const int MAXCHARS = 81;
  char message[MAXCHARS];      

  cout << "Enter a string: ";
  cin.getline(message,MAXCHARS);        // get the string
  vowels(message);
 
      

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void vowels(char strng[])
{
  int i = 0, aCnt = 0, eCnt = 0, iCnt = 0, oCnt = 0, uCnt = 0;
  char c;
  while ((c = strng[i++]) != '\0')
    switch(c)
    {
       case 'a': 
		   aCnt++;
		   cout << c;
		   break;
       case 'e':
		   eCnt++;
		   cout << c;
		   break;
       case 'i': 
		   iCnt++;
		   cout << c;
		   break;
       case 'o': 
		   oCnt++;
		   cout << c;
		   break;
       case 'u':
		   uCnt++;
		   cout << c;
		   break;
    } // end of switch  
	cout << "\nTotals:" << endl;
    cout << "a = " << aCnt << endl;
	cout << "e = " << eCnt << endl;
	cout << "i = " << iCnt << endl;
	cout << "o = " << oCnt << endl;
	cout << "u = " << uCnt << endl;
    cout << endl;

  return;
}

