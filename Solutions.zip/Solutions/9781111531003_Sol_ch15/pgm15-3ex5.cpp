// File: pgm15-3ex5.cpp
// Description: 15.3 Exercise 5
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

char* dayofweek(int);

int main()
{
	int num;

	cout << endl<<"Enter a number from 1 to 7: ";
	cin>>num;
	
	cout << dayofweek(num);

    cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}

char* dayofweek(int choice)
{
	char *day[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
	--choice;
	return *(day + choice);
}
