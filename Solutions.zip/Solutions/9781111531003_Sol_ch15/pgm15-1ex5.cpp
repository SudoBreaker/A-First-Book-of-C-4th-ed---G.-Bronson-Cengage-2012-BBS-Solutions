// File: pgm15-1ex5.cpp
// Description: 15.1 Exercise 5
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const int MAXCHARS = 81;
  char message[MAXCHARS];  
  int i = 0;

  cout << "Enter a string: ";
  cin.getline(message,MAXCHARS);        // get the string

  i = 0;
  while(message[i])
  {
	  if(message[i] == ' ')
		  cout << endl;
	  else
		  cout << message[i];
	  i++;
  }
 
      

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
