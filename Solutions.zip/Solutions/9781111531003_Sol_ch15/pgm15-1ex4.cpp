// File: pgm15-1ex4.cpp
// Description: 15.1 Exercise 4
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  const int MAXCHARS = 81;
  char message[MAXCHARS]; 
  int i;

  cout << "Enter a string: ";
  cin.getline(message,MAXCHARS);        // get the string
     
  cout << "\nThe hexadecimal equivalent of each character is: " << endl;

  i = 0;
  while(message[i])
  {
	  cout << showbase << hex << (int)message[i] << endl;
	  i++;
  }
 
      

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
