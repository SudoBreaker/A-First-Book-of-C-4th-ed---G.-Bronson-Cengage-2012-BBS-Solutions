// File: pgm15-1ex1a.cpp
// Description: 15.1 Exercise 1a
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  void vowels(char []); // function prototype

  const int MAXCHARS = 81;
  char message[MAXCHARS];      

  cout << "Enter a string: ";
  cin.getline(message,MAXCHARS);        // get the string
  vowels(message);
 
      

  cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}

void vowels(char strng[])
{
  int i = 0;
  char c;
  while ((c = strng[i++]) != '\0')
    switch(c)
    {
       case 'a': 
       case 'e':
       case 'i': 
       case 'o': 
       case 'u':
         cout << c;
    } // end of switch  
    cout << endl;

  return;
}

