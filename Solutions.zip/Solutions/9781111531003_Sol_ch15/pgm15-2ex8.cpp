// File: pgm15-2ex8.cpp
// Description: 15.2 Exercise 8
// Programmer: G. Bronson
// Date: 9/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
	char c;

	cout << "Start entering characters followed by the ENTER key: " << endl;
	cout << "  (press 1 to quit) " << endl;
	c=cin.get();
	while(c!='1')
	{
		c=toupper(c);
		cout<<c;
		c=cin.get();
	}

    cin.ignore();  cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
