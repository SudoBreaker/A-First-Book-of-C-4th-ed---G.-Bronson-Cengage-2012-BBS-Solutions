// File: pgm5-2ex12a.cpp
// Description: 5.2 Exercise 12a
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>	 
using namespace std;

int main()
{
  int id, inven, income, outgo, bal, count;

  count = 1;
  while (count <= 3)
  {
    cout << "\nEnter book ID:  ";
    cin >> id;
    cout << "\nEnter inventory at beginning of month:  ";
    cin >> inven;
    cout << "\nEnter number of copies received during the month:  ";
    cin >> income;
    cout << "\nEnter number of copies sold during the month:  ";
    cin >> outgo;
    bal = inven + income - outgo;
    cout << "\n\nBook No. " << id 
          << " new balance is " << bal << endl;
    count++;
  }
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
