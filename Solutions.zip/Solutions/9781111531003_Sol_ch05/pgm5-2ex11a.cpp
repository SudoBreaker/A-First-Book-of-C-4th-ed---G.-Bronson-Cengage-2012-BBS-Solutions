// File: pgm5-2ex11a.cpp
// Description: 5.2 Exercise 11a
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  double start;  //starting mileage
  double miles = 22495;  //current miles - start out w/miles at beginning of trip
  double gallons;
  double mpg;

  cout << setiosflags(ios::fixed) << setprecision(3);

  cout << "Enter 999 miles to exit program" << endl;

  while (miles != 999)
  {
		 start = miles;   //start gets previous value of miles
         cout << "\nEnter the current miles: ";
         cin  >> miles;
		 if(miles == 999)
			 break;
		 cout << "Enter the number of gallons: ";
		 cin >> gallons;
		 mpg = (miles - start) / gallons;
		 cout << "\nMiles Per Gallon: " << mpg << endl;		 
  }
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}



