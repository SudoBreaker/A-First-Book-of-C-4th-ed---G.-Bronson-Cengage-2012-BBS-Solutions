// File: pgm5-1ex1.cpp
// Description: 5.1 Exercise 1
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs


#include <iostream>
using namespace std;

int main()
{
  int count;
  count = 2;

  // initialize count
  while (count <= 10)
  {
    cout << count << "  ";
    count+=2;    // increment count
  }
 
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
