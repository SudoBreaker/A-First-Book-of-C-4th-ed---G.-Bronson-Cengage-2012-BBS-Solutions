// File: pgm5-3ex16.cpp
// Description: 5.3 Exercise 16
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int i, j, results;
  double num, total;
  double average;

  for (i = 1; i < 5; i++)    //for the 4 experiments
  {
	  total = 0;   //clear the total for this experiment
	  cout << "\nExperiment " << i << endl;
	  cout << "Enter the number of test results: ";
	  cin >> results;

	  for(j = 1; j <= results; j++) 
	  {
	     cout << "Enter test result " << j << ": ";
	     cin >> num;
	     total = num + total;
	  }
	  average = total / (j-1);
	  cout << "Experiment " << i << " average: " << average << endl;
  }
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
