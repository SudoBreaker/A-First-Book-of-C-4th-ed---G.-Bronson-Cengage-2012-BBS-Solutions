// File: pgm5-2ex8.cpp
// Description: 5.2 Exercise 8
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <iomanip>	 
using namespace std;

int main()
{
	double cels, fahr, end, incr;

	cout << "Enter the starting temperature in degrees Celsius:  ";
	cin >> cels;
	cout << "\nEnter the ending temperature in degrees Celsius: ";
	cin >> end;
	cout << "\nNow enter the increment between conversions  ";
	cout << "in degrees Celsius:  ";
	cin >> incr;
	cout << "\n\n\n";
	cout << "Celsius          Fahrenheit\n";
	cout << "----------------------------------\n";

	while (cels <= end)
	{
		fahr = (9.0/5.0) * cels + 32.0;
		cout << setiosflags(ios::showpoint) << setw(7) 
			<< setprecision(2)  << setiosflags(ios::fixed) << cels
			<< setiosflags (ios::showpoint) << setw(15)
			<< setprecision(2) << setiosflags(ios::fixed) << fahr << '\n';
		cels = cels + incr;
	}

    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
