// File: pgm5-2ex2.cpp
// Description: 5.2 Exercise 2
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 user

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
  int maxNums;
  int count;
  double num, total;

  cout << "Please type in the total number of data values to be added: ";
  cin >> maxNums;
  cout << "\nThis program will ask you to enter "
       << maxNums << " numbers.\n";
  count = 1;
  total = 0;

  cout << setiosflags(ios::fixed) << setprecision(3);

  while (count <= maxNums)
  {
    cout << "\nEnter a number: ";
    cin  >> num;
    total = total + num;
    cout << "The total is now " << total;
    count++;
  }
  cout << "\n\nThe final total is " << total << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
