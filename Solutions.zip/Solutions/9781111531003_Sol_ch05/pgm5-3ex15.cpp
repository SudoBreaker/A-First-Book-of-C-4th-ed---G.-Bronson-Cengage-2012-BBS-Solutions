// File: pgm5-3ex15.cpp
// Description: 5.3 Exercise 15
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int i, j;
  double num, total;
  double average;

  for (i = 1; i < 5; i++)    //for the 4 experiments
  {
	  total = 0;   //clear the total for this experiment
	  cout << "\nExperiment " << i << endl;
	  for(j = 1; j < 7; j++)   //for the 6 test results
	  {
	     cout << "Enter test result " << j << ": ";
	     cin >> num;
	     total = num + total;
	  }
	  average = total / (j-1);
	  cout << "Experiment " << i << " average: " << average << endl;
  }

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
