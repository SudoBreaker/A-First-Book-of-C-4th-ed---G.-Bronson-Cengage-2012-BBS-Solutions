// File: pgm5-3ex9b.cpp
// Description: 5.3 Exercise 9b
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>  // needed for formatting=
using namespace std;

// a program to convert Celsius to Fahrenheit

int main()
{
  const int MAX_CELSIUS = 60;
  const int START_VAL = -10;
  const int STEP_SIZE = 10;

  int celsius;
  double fahren;
  cout << "DEGREES   DEGREES\n"
       << "CELSIUS  FAHRENHEIT\n"
       << "                   \n";

  celsius = START_VAL;

  // set output formats for floating point numbers only
  cout << setiosflags(ios::showpoint)
       << setprecision(2);
  while (celsius <= MAX_CELSIUS)
  {
    fahren = (9.0/5.0) * celsius + 32.0;
    cout << setw(4)  << celsius
	 << setw(13) << fahren << endl;
    celsius = celsius + STEP_SIZE;
  }
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}