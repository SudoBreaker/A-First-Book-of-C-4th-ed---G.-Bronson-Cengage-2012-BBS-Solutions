// File: pgm5-2ex13.cpp
// Description: 5.2 Exercise 13
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>	 
using namespace std;

int main()
{
  int id, inven, income, outgo, bal;

  id = 0;

  while (id != 999)
  {
    cout << "\nEnter book ID (enter 999 to quit):  ";
    cin >> id;
    if (id == 999)
	break;
    cout << "\nEnter inventory at beginning of month:  ";
    cin >> inven;
    cout << "\nEnter number of copies received during the month:  ";
    cin >> income;
    cout << "\nEnter number of copies sold during the month:  ";
    cin >> outgo;
    bal = inven + income - outgo;
    cout << "\n\nBook No. " << id << " new balance is " << bal << endl;
  }

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
