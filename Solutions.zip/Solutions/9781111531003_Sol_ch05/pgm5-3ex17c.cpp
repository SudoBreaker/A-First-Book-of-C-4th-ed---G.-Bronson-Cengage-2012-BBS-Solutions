// File: pgm5-3ex17c.cpp
// Description: 5.3 Exercise 17c
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>	 
using namespace std;

int main()
{
	int bowler;
	double score1, score2, score3, playertot, playeravg;
	
	for (bowler = 1; bowler <= 5; bowler++)
	{
		cout << endl;
		cout << "Enter three scores for bowler " << bowler
			<< " : ";
		cin >> score1 >> score2 >> score3;
		
		playertot = score1 + score2 + score3;
		playeravg = playertot / 3;
		cout << "  The average for bowler "  << bowler << " is "
			<< setiosflags(ios::showpoint) << setw(5)
			<< setprecision(2) << setiosflags(ios::fixed) 
			<< playeravg << '\n';
	}

    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
