// File: pgm5-2ex10.cpp
// Description: 5.2 Exercise 103
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
  int a = 1;
  double r = 0.5;
  int n = 1;
  double term;
  double sum = 0;

  cout << " n         Term          Sum\n"
       << "---        ----          ---" << endl;

  while (n <= 10)
  {
       term = a * pow(r, (n-1));
       sum = sum + term;
       cout << setw(3) << n << "     "
            << setw(12) << term
            << "     " << sum << endl;
       n++;
  }
 
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
