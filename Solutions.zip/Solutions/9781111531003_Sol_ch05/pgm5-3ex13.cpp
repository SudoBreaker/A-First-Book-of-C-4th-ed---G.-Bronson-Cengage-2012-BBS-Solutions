// File: pgm5-3ex13.cpp
// Description: 5.3 Exercise 13
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{

  const int STEP = 20;
  const int startYear = 1626;
  const int endYear = 2006;
  const double RATE = 0.04;
  const double PRINCIPAL = 24.0;
  int year, count = 0;
  double amount;

  cout << "Year     Balance" << endl;
  cout << "---      --------" << endl;
  cout << fixed << setprecision(2) << endl;
  cout << startYear << "      " << PRINCIPAL << endl;

  for(year = (startYear + STEP); year <= endYear; year += STEP)
  {
     count = count + STEP;
	 amount = PRINCIPAL + (PRINCIPAL * RATE * count);
	 cout << year << "      " << amount << endl;
  }
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}


