// File: pgm5-3ex12a.cpp
// Description: 5.3 Exercise 12a
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs
     
#include <iostream>
#include <iomanip>	 
using namespace std;

int main()
{
	int yr;
	double amount = 1000., total;

	for (total = amount, yr = 1; yr <=10; yr++)
	{
		total = total * 1.03;
		cout << "The balance at the end of " << yr
			<< " years is $" << setiosflags(ios::showpoint)
			<< setiosflags(ios::fixed)
			<< setw(8) << setprecision(2) << total << endl;
	}
		
    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
