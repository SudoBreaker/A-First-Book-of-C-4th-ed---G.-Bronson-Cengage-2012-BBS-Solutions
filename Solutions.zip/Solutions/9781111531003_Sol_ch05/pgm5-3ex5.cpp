// File: pgm5-3ex5.cpp
// Description: 5.3 Exercise 5
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  const int MAXNUMS = 20;
  int num;
  cout << "NUMBER    SQUARE    CUBE\n"
       << "------    ------    ----\n";

  for (num = 0; num <= MAXNUMS; num+=2)
       cout << setw(3) << num << "        "
	        << setw(3) << num * num << "      "
            << setw(4) << num * num * num << endl;
 
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
