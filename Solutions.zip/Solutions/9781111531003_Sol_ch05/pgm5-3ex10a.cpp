// File: pgm5-3ex10a.cpp
// Description: 5.3 Exercise 10a
// Programmer: G. Bronson
// Date: 9/27/2010

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{

  const int MAXDAYS = 64;
  int day, oneMilDay = 1;
  double owed = 0.01;
  double total = 0.0;

  cout << "Day      Amount Owed" << endl;
  cout << "---      -----------" << endl;
  cout << fixed << setprecision(2) << endl;
  cout << " 1        0.01" << endl;

  for(day = 2; day <= MAXDAYS; day++)
  {
     owed = 2 * owed;
	 total = total + owed;
	 if(total > 1000000 && oneMilDay == 0.0)
		oneMilDay = day;
	 cout << setw(2) << day << "        " << owed << endl;
  }
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}