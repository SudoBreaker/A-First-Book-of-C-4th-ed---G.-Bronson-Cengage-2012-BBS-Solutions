// File: pgm5-3ex14.cpp
// Description: 5.3 Exercise 14
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>	 
using namespace std;

int main()
{
	int yr; 
	double sales, profit;
	double tot_sales = 0;
	double tot_profit = 0;


	sales = 10000000.00;
	profit = 1000000.00;
	
	cout << "\n\tSALES AND PROFIT PROJECTION"
		<< "\n\t----------------------------" << endl;
	cout << "\nYEAR\t" << "   EXPECTED SALES\t"
		 << "   PROJECTED PROFIT\n";
	cout << "----\t" << "   --------------\t"
		<< "   ----------------\n\n";

	for (yr = 1; yr <=10; yr++)
	{
		tot_sales = tot_sales + sales;
		tot_profit = tot_profit + profit;
		cout << " " << yr << "\t    $" << setw(11) 
			<< setiosflags(ios::fixed) 
			<< setprecision(2) << sales << "\t   $" 
			<< setw(10) << profit << endl;
		sales -= (sales * .04);
		profit = sales * .10;
	}
	cout << "\n";
	cout << "---------------------------------------------------\n";
	cout << "Totals:" << "\t    $" << setw(11) << tot_sales << "\t   $" 
		<< setw(10) << tot_profit << endl;

    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
