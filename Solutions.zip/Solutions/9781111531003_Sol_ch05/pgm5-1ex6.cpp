// File: pgm5-1ex6.cpp
// Description: 5.1 Exercise 6
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs
     
#include <iostream> 
#include <iomanip>	 
using namespace std;

int main()
{
	int years = 1;
	int depreciation = 4000;
	int start_val = 28000;

	cout << "\n";  
	cout << "                           END-OF-YEAR      ACCUMULATED\n";
	cout << "   YEAR    DEPRECIATION      VALUE         DEPRECIATION\n";
	cout << "   ----    ------------    -----------     ------------\n";
	while (years <= 7)
	{
		cout << setw(5) << years << setw(14)
			<< depreciation << setw(16)
			<< start_val - (depreciation * years) << setw(16) 
			<< (depreciation * years) << '\n';
		years ++;
	}

	
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
