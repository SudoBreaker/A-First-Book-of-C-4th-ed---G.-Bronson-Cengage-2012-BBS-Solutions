// File: pgm5-1ex8b.cpp
// Description: 5.1 Exercise 8b
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>  // needed for formatting

using namespace std;

// a program comparing the approximate and 
// exact calculation of degrees Celsius 
// converted from degrees Fahrenheit

int main()
{
  const int STARTVAL = 0;
  const int STEPSIZE = 2;
  double fahren;
  double approxCelsius;
  double celsius;
  cout << "DEGREES\t\tEXACT DEGREES\tAPPROX DEGREES\n"
       << "FAHRENHEIT\t CELSIUS \tCELSIUS \tDIFFERENCE\n"
       << "                   \n";
  fahren = STARTVAL;
  
  // set output formats for floating pooint numbers only
  cout << setiosflags(ios::fixed)
       << setiosflags(ios::showpoint)
       << setprecision(2);
  approxCelsius = (fahren - 30.0) / 2.0;
  celsius = (5.0 / 9.0) * (fahren - 32.0);

  while ((celsius - approxCelsius) <= 4)
  {
    cout << setw(8)  << fahren
	 << setw(15) << celsius 
         << setw(15) << approxCelsius
         << setw(15) << (celsius - approxCelsius) << endl;
    fahren = fahren + STEPSIZE;
    approxCelsius = (fahren - 30.0) / 2.0;
    celsius = (5.0 / 9.0) * (fahren - 32.0);
  }
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
