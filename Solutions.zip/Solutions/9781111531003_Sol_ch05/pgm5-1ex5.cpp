// File: pgm5-1ex1.cpp
// Description: 5.1 Exercise 1
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>  // needed for formatting

using namespace std;

// a program to convert feet to meters

int main()
{
  const int MAXFEET = 30;
  const int STARTVAL = 3;
  const int STEPSIZE = 3;

  int feet;
  double meters;
  cout << " FEET        METERS\n"
       << "                   \n";
  feet = STARTVAL;

  // set output formats for floating point numbers only
  cout << setiosflags(ios::fixed)
       << setiosflags(ios::showpoint)
       << setprecision(2);

  while (feet <= MAXFEET)
  {
    meters = feet / 3.28;
    cout << setw(4)  << feet
         << setw(13) << meters << endl;
    feet = feet + STEPSIZE;
  }

  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
