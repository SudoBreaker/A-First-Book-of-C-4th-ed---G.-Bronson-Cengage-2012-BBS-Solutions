// File: pgm5-3ex7a.cpp
// Description: 5.3 Exercise 7a
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <iomanip>	 
using namespace std;

int main()
{
	int fahr = 20;

	cout << "Fahrenheit    Celsius\n"
	<< "----------------------\n";

	for (int i = 1; i <= 20; i++)
	{
		cout << setw(3) << fahr << "        "
			 << setw(3) << (5.0/9.0)*(fahr - 32.0) << endl;
	  	fahr+=4;
	}
	
    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
