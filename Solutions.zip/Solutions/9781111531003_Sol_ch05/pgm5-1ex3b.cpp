// File: pgm5-1ex3b.cpp
// Description: 5.1 Exercise 3b
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{ 
  int num = 0;
  while (num <= 20)
  {
    num++;
    cout << num << " ";
  }
  
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
