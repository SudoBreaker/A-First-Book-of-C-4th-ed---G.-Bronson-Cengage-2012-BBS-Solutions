// File: pgm5-3ex11.cpp
// Description: 5.3 Exercise 11
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream> 	 
using namespace std;

int main()
{
	int j;

	for (int i = 1; i < 10; i++)
		cout << i << '\n';

	for (j = 1; j < 5; i++)
		cout << j << endl;

	
    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
