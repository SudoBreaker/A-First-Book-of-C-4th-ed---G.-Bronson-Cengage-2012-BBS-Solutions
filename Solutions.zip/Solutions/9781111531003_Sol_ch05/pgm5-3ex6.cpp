// File: pgm5-3ex6.cpp
// Description: 5.3 Exercise 6
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
  const int MINNUMS = 1;
  int num;

  cout << "NUMBER    SQUARE    CUBE\n"
       << "------    ------    ----\n";

  for (num = 10; num >= MINNUMS; num--)
    cout << setw(3) << num << "        "
	     << setw(3) << num * num << "      "
         << setw(4) << num * num * num << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
