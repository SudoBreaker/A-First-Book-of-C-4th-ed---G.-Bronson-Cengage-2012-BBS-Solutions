// File: pgm5-1ex8a.cpp
// Description: 5.8a Exercise 8a
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

// a program comparing the approximate and exact calculations of temperature conversions from Fahrenheit.

int main()
{
  const int STARTVAL = 0;
  const int STEPSIZE = 1;
  double fahren;
  double approxCelsius;
  double celsius;
  fahren = STARTVAL;

  approxCelsius = (fahren - 30.0) / 2.0;
  celsius = (5.0 / 9.0) * (fahren - 32.0);

  while ((celsius - approxCelsius) <= 4)
  { 
    fahren = fahren + STEPSIZE;
    approxCelsius = (fahren - 30.0) / 2.0;
    celsius = (5.0 / 9.0) * (fahren - 32.0);
  }
  fahren = fahren - STEPSIZE;  // because fahren is increased 
                               // before the last test

  cout << "At " << fahren << " degrees Fahrenheit, the"
       << " approx Celsius and exact Celsius temperatures"
       << " differ by more than 4 degrees." << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
