// File: pgm5-3ex12d.cpp
// Description: 5.3 Exercise 12d
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs
     
#include <iostream>
#include <iomanip>	 
using namespace std;

int main()
{
	int yr = 1, years;
	double amount, interest, total;

	cout << "\nPlease enter initial deposit amount:  ";
	cin  >> amount;
	cout << "\nPlease enter number of years:  ";
	cin  >> years;
	cout << "\nPlease enter interest rate as a decimal value (ex. .03): ";
	cin  >> interest;

	for (total = amount; yr <=years; yr++)
	{
		total = total + (total * interest);
		cout << "The balance at the end of " << yr
			<< " years is $" << setiosflags(ios::showpoint)
			<< setiosflags(ios::fixed)
			<< setw(8) << setprecision(2) << total << endl;
	}

    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
