// File: pgm5-2ex6.cpp
// Description: 5.2 Exercise 6
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>  // needed for formatting

using namespace std;

// a program to convert meters to feet

int main()
{
  double increment = 0;
  double startMeter = 0;
  int numConversion = 0;
  int counter = 0;
  double meter = 0;

  cout << "Enter the starting meter:"<<endl;
  cin >> startMeter;
  cout << "Enter the number of conversions:"<<endl;
  cin >> numConversion;
  cout << "Enter the increment:"<<endl;
  cin >> increment;

  if (numConversion > 10) {
    increment = 10;
  }

  cout << "METERS\tFEET\n"
       << "                   \n";

  // set output formats for floating point numbers only
  cout << setiosflags(ios::fixed)
       << setiosflags(ios::showpoint)
       << setprecision(2);
  meter = startMeter;  
  
  while (counter < numConversion)
  {
    cout << meter << "\t" << setw(2) <<  meter * 3.281 << endl;
    meter += increment;
    counter++;
  }
  cout << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
