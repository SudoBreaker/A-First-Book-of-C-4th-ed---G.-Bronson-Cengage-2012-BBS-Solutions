// File: pgm5-2ex1.cpp
// Description: 5.2 Exercise 2
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  const int MAXNUMS = 8;
  int count;
  double num, total;

  cout << "\nThis program will ask you to enter "
       << MAXNUMS << " numbers.\n";
  
  count = 1;
  total = 0;

  cout << setiosflags(ios::fixed) << setprecision(3);

  while (count <= MAXNUMS)
  {
    cout << "\nEnter a number: ";
    cin  >> num;
    total = total + num;
    cout << "The total is now " << total;
    count++;
  }

  cout << "\n\nThe final total is " << total << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
