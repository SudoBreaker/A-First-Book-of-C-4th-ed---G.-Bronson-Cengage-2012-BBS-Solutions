// File: pgm5-3ex17b.cpp
// Description: 5.3 Exercise 17b
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const int NUMBOWLS = 5;
  const int NUMOUTPUTS = 3;
  int i, j;
  double num, total, totBowl = 0;
  double average;

  for (i = 1; i <= NUMBOWLS; i++)    //for each player
  {
	  total = 0;   //clear the total for this player
	  cout << "\nBowler " << i << endl;
	  for(j = 1; j <= NUMOUTPUTS; j++)   //for each game
	  {
	     cout << "Enter Game " << j << " score: ";
	     cin >> num;
	     total = num + total;
	  }
	  average = total / NUMOUTPUTS;
	  totBowl = totBowl + average;
	  cout << "Bowler " << i << " average: " << average << endl;
  }
 
  average = totBowl/NUMBOWLS;
  cout << "Team average: " << average;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}