// File: pgm5-3ex9a.cpp
// Description: 5.3 Exercise 9a
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <iomanip>	 
using namespace std;

int main()
{
	int count;
	double gallons, liters;

	for (count = 1; count <= 5; ++count)
	{
		cout << "\nEnter a number of gallons:  ";
		cin >> gallons;
		liters = gallons * 3.785;
		cout << "The corresponding number of liters is "
			<< setiosflags(ios::fixed) << setw(5)
			<< setprecision(2) << liters << endl;
	}
	
    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}