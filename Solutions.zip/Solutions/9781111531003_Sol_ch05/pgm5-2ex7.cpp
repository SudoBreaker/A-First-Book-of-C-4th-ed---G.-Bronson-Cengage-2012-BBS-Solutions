// File: pgm5-2ex7.cpp
// Description: 5.2 Exercise 7
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>  // needed for formatting
using namespace std;

// a program to convert meters to feet

int main()
{
  // Initialize variables
  double increment = 0;
  double startMeter = 0;
  double endMeter = 0;
  double counter = 0;
  double meter = 0;

  // Prompt the user for input
  cout << "Enter the starting meter value:"<<endl;
  cin >> startMeter;
  cout << "Enter the ending meter value:"<<endl;
  cin >> endMeter;
  cout << "Enter the increment:"<<endl;
  cin >> increment;

  // Calculate the number of iterations
  int numIterations = int ((endMeter - startMeter) / increment) + 1;

  // If the number of iterations is more than 20, adjust it
  if (numIterations > 20) {
    increment = (endMeter - startMeter)/19;
  }

  // Column headers
  cout << "METERS\tFEET\n"
       << "                   \n";

  // Set output formats for floating point numbers only
  cout << setiosflags(ios::fixed)
       << setiosflags(ios::showpoint)
       << setprecision(2);
  
  // Set meter to the starting value
  meter = startMeter;  

  // Test for the loop terminating condition
  while (meter < endMeter)
  {
    cout << meter << "\t" << setw(2) <<  meter * 3.281 << endl;
    meter += increment; // Increment by the amount given by the user
  }

  // The last iteration is the ending value given by the user
  if (meter >= endMeter) {
    cout << endMeter << "\t" << setw(2) <<  endMeter * 3.281 << endl;
  }

  cout << endl;

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
