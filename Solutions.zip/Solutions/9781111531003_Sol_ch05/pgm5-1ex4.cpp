// File: pgm5-1ex4.cpp
// Description: 5.1 Exercise 4
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>   // needed for formatting

using namespace std;

// a program to convert gallons to liters

int main()
{
  const int MAXGALLONS = 20;
  const int STARTVAL = 10;
  const int STEPSIZE = 1;

  int gallons;
  double liters;

  cout << "GALLONS     LITERS\n"
       << "                   \n";
  gallons = STARTVAL;

  // set output formats for floating point numbers only
  cout << setiosflags(ios::fixed)
       << setiosflags(ios::showpoint)
       << setprecision(2);
  
  while (gallons <= MAXGALLONS)
  {
    liters = 3.785 * gallons;
    cout << setw(4)  << gallons
	 << setw(13) << liters << endl;
    gallons = gallons + STEPSIZE;
  }

  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
