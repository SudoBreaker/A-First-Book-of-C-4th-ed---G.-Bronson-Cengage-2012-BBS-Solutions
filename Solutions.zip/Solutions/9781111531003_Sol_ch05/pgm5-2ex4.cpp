// File: pgm5-2ex4.cpp
// Description: 5.2 Exercise 4
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int maxNums;
  int count;
  double num, total, average;

  cout << "Please type in the total number of data values to be averaged: ";
  cin >> maxNums;

  cout << "\nThis program will ask you to enter "
       << maxNums << " numbers.\n";
  count = 1;
  total = 0;

  cout << setiosflags(ios::fixed) << setprecision(3);  // this line is optional

  while (count <= maxNums)
  {
    cout << "Enter a number: ";
    cin >> num;
    total = total + num;
    count++;
  }

  count--;   
  average = total / count;
  cout << "\nThe average of the numbers is " << average << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}


