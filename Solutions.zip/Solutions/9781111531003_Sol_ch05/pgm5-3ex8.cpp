// File: pgm5-3ex8.cpp
// Description: 5.3 Exercise 
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream> 
#include <iomanip>	 
using namespace std;

int main()
{
	int num;
	double fahr;

	cout << "\nHow many conversions do you want to see?  ";
	cin >> num;
	cout << "\nAt what temperature Fahrenheit to you want to start?  ";
	cin >> fahr;

	cout 	<< "\nFahrenheit    Celsius\n"
		<< "----------------------\n";

	for (int i = 1; i <= num; i++)
	{
		cout << setw(3) << fahr << "        "
			 << setw(3) << (5.0/9.0)*(fahr - 32.0) << endl;
		fahr += 5;
	}
	
    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
