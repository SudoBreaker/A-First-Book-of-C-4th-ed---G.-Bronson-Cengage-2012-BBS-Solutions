// File: pgm5-1ex7.cpp
// Description: 5.1 Exercise 7
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>  // needed for formatting
using namespace std;

// a program to compute the distance a car travels, 
// given a speed and a number of hours

int main()
{
  const int MAXHOURS = 4;
  const double STARTVAL = 0.5;
  const double STEPSIZE = 0.5;
  const int DISTANCE = 55;

  double hours;
  double distance;

  cout << " HOUR        DISTANCE\n"
       << " ----        -------- \n";

  hours = STARTVAL;
  distance = 0;
  cout << setiosflags(ios::fixed) << setiosflags(ios::showpoint)
		<< setprecision(2);

  while (hours <= MAXHOURS)
  {
    distance = DISTANCE * hours;
    cout << setw(5)  << hours
	     << setw(15) << distance << endl;
    hours = hours + STEPSIZE;
  }

  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
