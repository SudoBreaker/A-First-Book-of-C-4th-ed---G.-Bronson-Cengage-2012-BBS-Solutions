// File: pgm5-4ex2a.cpp
// Description: 5.4 Exercise 2a
// Programmer: T. Robbbins
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  double grade;
  double total = 0;
  int count = 0;

  do
  {
	cout << "\nEnter a grade (enter 999 to exit): ";
	cin >> grade;
	if(grade == 999)
	      break;
        else if(grade < 0 || grade > 100)
              cout << "An invalid grade has been entered! " 
                   << "Please reenter a valid grade." << endl;
        else {
              count++;
	      total = total + grade;
        }
  } while (1);

  cout << "\nThe average of the valid grades entered is: " 
       << (total / count) << endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
