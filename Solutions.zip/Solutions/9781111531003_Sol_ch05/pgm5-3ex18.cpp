// File: pgm5-3ex18.cpp
// Description: 5.3 Exercise 18
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>	 
using namespace std;

int main()
{
	int year;
	double percent;
	double total = 1000.00;

	cout << "\n\tINTEREST PROJECTION ON $1000 INVESTMENT"
		<< "\n\t----------------------------------------" << endl;
	cout << "\nPERCENT INTEREST\t" << "    TOTAL AFTER TEN YEARS\n";
	cout << "----------------\t" << "    ----------------------\n\n";

	for (percent = 6; percent <= 12; percent++)
	{
		total = 1000;
		for (year = 1; year <= 10; year++)
		{
			total =  total * ((percent / 100) + 1);
		}
		cout <<'\t' << setw(2) 
                 << setiosflags(ios::fixed) << setprecision(2)
			<<  percent << "\t\t\t" << setw(10) 
			<< setiosflags(ios::fixed) 
			<< setprecision(2) << total <<  endl;
	}

    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
