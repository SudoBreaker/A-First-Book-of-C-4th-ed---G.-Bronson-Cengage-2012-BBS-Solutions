// File: pgm5-3ex12c.cpp
// Description: 5.3 Exercise 12c
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs
     
#include <iostream>
#include <iomanip>	 
using namespace std;

int main()
{
	int yr = 1, years;
	double amount, total;

	cout << "\nPlease enter initial deposit amount:  ";
	cin >> amount;
	cout << "\nPlease enter number of years:  ";
	cin >> years;
	
	for (total = amount; yr <=years; yr++)
	{
		total = total * (1 + 0.03);
		cout << "The balance at the end of " << yr
			<< " years is $" << setiosflags(ios::showpoint)
			<< setiosflags(ios::fixed)
			<< setw(8) << setprecision(2) << total << endl;
	}
	
    cin.ignore();   // needed for MS C++ Express 2010 programs

    return 0;
}
