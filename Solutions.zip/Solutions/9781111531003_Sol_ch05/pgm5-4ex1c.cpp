// File: pgm5-4ex1c.cpp
// Description: 5.4 Exercise 1c
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"   // needed for MS C++ Express 2010 programs
#include <iostream>
using namespace std;

int main()
{
  double grade;
  do
  {
	cout << "\nEnter a grade (enter 999 to exit): ";
	cin >> grade;
	if(grade == 999)
		break;
    else if(grade < 0 || grade > 100)
        cout << "An invalid grade has been entered! "
	         << "Please reenter a valid grade." << endl;
	  else
		break;
  } while (1);

  if(grade != 999) 
	cout << "\nThe grade entered was: " << grade << endl;
	
  return 0;
}