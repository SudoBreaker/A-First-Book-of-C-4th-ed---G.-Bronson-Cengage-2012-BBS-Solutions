// File: pgm5-2ex9.cpp
// Description: 5.2 Exercise 9
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int a = 1;
  int d = 3;
  int n = 1;
  int term;
  int sum = 0;

  cout << " n       Term   Sum\n"
       << "---      ----   ---" << endl;

  while (n <= 100)
  {
       term = a + (n - 1) * d;
       sum = sum + term;
       cout << setw(3) << n << "     "
            << setw(3) << term
            << "     " << sum << endl;
       n++;
  }  
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
