// File: pgm5-3ex17a.cpp
// Description: 5.3 Exercise 17a
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  const int NUMBOWLS = 5;
  const int NUMOUTPUTS = 3;
  int i, j;
  double num, total;
  double average;

  for (i = 1; i <= NUMBOWLS; i++)    //for each player
  {
	  total = 0;   //clear the total for this player
	  cout << "\nBowler " << i << endl;
	  for(j = 1; j <= NUMOUTPUTS; j++)   //for each game
	  {
	     cout << "Enter game " << j << " score: ";
	     cin >> num;
	     total = num + total;
	  }

	  average = total / NUMOUTPUTS;
  	  cout << "Bowler " << i << " average: " << average << endl;
  }  
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
