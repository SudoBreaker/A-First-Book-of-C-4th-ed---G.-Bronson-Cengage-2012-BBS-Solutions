// File: pgm5-4ex3a.cpp
// Description: 5.4 Exercise 3a
// Programmer: T. Robbbins
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
using namespace std;

int main()
{
  int num;
  int units;

  cout << "\nEnter a positive integer number: ";
  cin >> num;
  
  cout<< "The number in reverse order is: ";
  do
  {
	units = num % 10;
	cout << units;
	num = num /10;
  } while (num > 0);
  
  cout <<endl;
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}
