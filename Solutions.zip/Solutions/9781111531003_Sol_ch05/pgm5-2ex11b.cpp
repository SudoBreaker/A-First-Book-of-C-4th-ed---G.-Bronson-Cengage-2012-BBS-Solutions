// File: pgm5-2ex11b.cpp
// Description: 5.2 Exercise 11b
// Programmer: G. Bronson
// Date: 8/27/2010

#include "stdafx.h"     // needed for MS C++ Express 2010 programs

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  double start;  //starting mileage
  double miles = 22495;
  double totMiles = 0;
  double gallons, totGallons = 0;
  double mpg;
  double cumulMpg;


  cout << setiosflags(ios::fixed) << setprecision(3);

  cout << "Enter 999 miles to exit program" << endl;

  while (miles != 999)
  {
		 start = miles;   //start gets previous value of miles
         cout << "\nEnter the current miles: ";
         cin  >> miles;
		 if(miles == 999)
			 break;
		 cout << "Enter the number of gallons: ";
		 cin >> gallons;
		 totMiles = totMiles + (miles - start);
		 totGallons = totGallons + gallons;
		 mpg = (miles - start) / gallons;
		 cumulMpg = totMiles / totGallons;
		 cout << "\nMiles Per Gallon: " << mpg << endl;
		 cout << "Cumulative MPG: " << cumulMpg << endl;		 
  }
  
  cin.ignore();   // needed for MS C++ Express 2010 programs

  return 0;
}


